

#include <wx/bookctrl.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/statbox.h>
#include <wx/checkbox.h>
#include <wx/stattext.h>
#include <wx/spinctrl.h>
#include <wx/button.h>
#include <wx/font.h>
#include <wx/fontdlg.h>
#include <wx/fontutil.h>
#include <wx/fontmap.h>
#include "output_settings_dlg.h"
#include "config_manager.h"


BEGIN_EVENT_TABLE(miOutputSettingsDlg, wxPropertySheetDialog)
    EVT_BUTTON(ID_FontChoose, miOutputSettingsDlg::OnFontChooseBtn)
    EVT_BUTTON(wxID_OK, miOutputSettingsDlg::OnOkBtn)
END_EVENT_TABLE()


miOutputSettingsDlg::miOutputSettingsDlg(wxWindow* parent)
{
    Create(parent);
}

miOutputSettingsDlg::~miOutputSettingsDlg()
{
}

bool miOutputSettingsDlg::Create(wxWindow* parent)
{
    if (!wxPropertySheetDialog::Create(parent, -1, wxT("Editor settings")))
        return false;
    SetSheetStyle(wxPROPSHEET_SHRINKTOFIT | wxPROPSHEET_BUTTONTOOLBOOK);
    SetSheetInnerBorder(0);
    SetSheetOuterBorder(0);

    CreateButtons(wxOK|wxCANCEL);

    wxBookCtrlBase* notebook = GetBookCtrl();
    wxPanel *general_settings = CreateGeneralPage(notebook);
    wxPanel *folding_settings = CreateFoldingPage(notebook);
    wxPanel *highlighting_settings = CreateHighlightingPage(notebook);

    notebook->AddPage(general_settings, wxT("General"));
    notebook->AddPage(folding_settings, wxT("Folding"));
    notebook->AddPage(highlighting_settings, wxT("Highlighting"));

    LayoutDialog();
    return true;
}

wxPanel* miOutputSettingsDlg::CreateGeneralPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);


    // font options
    wxStaticBoxSizer *label_font = new wxStaticBoxSizer(wxVERTICAL, panel, wxT("Font"));
    m_FontSample = new wxStaticText(panel, wxID_ANY, wxT("This is a sample text"));
    #if wxUSE_UNICODE
    m_font.SetNativeFontInfo(ConfigManager::get_manager()->read_str(wxT("/output/font")));
    #else
    m_font.SetNativeFontInfo(ConfigManager::get_manager()->read_str(wxT("/output/font")).To8BitData());
    #endif
    m_FontSample->SetFont(m_font);

    label_font->Add(m_FontSample, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    label_font->Add(new wxButton(panel, ID_FontChoose, wxT("Choose...")), 0, wxALL | wxALIGN_RIGHT, 5);

    // tab options
    wxStaticBoxSizer *label_tab = new wxStaticBoxSizer(wxVERTICAL, panel, wxT("Tab options"));

    use_tab_check = new wxCheckBox(panel, wxID_ANY, wxT("Use TAB character"));
    use_tab_check->SetValue(ConfigManager::get_manager()->read_bool(wxT("/editor/tab_options/use_tab"), false));
    label_tab->Add(use_tab_check, 0, wxALL, 5);
    tab_indent_check = new wxCheckBox(panel, wxID_ANY, wxT("TAB indents"));
    tab_indent_check->SetValue(ConfigManager::get_manager()->read_bool(wxT("/editor/tab_options/tab_indent"), false));
    label_tab->Add(tab_indent_check, 0, wxALL, 5);

    wxBoxSizer *tab_size_sizer = new wxBoxSizer(wxHORIZONTAL);
    tab_size_sizer->Add(new wxStaticText(panel, wxID_ANY, wxT("TAB size in spaces:")), 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    tab_size = new wxSpinCtrl(panel);
    tab_size->SetValue(ConfigManager::get_manager()->read_value(wxT("/editor/tab_options/tab_size"), 4));

    tab_size_sizer->Add(tab_size, 0, wxALL|wxALIGN_CENTER_VERTICAL, 5);

    label_tab->Add(tab_size_sizer);

    //top layout
    top_sizer->Add(label_font, 0, wxALL|wxEXPAND, 5);
    top_sizer->Add(label_tab, 0, wxALL|wxEXPAND, 5);
    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);

    return panel;
}



wxPanel* miOutputSettingsDlg::CreateFoldingPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);

    m_EnableFolding = new wxCheckBox(panel, wxID_ANY, wxT("Enable folding"));
    m_EnableFolding->SetValue(ConfigManager::get_manager()->read_bool(wxT("/editor/folding/enable_folding"), true));

    wxStaticBoxSizer *label_fold_options = new wxStaticBoxSizer(wxVERTICAL, panel, wxT("Fold options"));
    m_FoldComment = new wxCheckBox(panel, wxID_ANY, wxT("Fold comment"));
    m_FoldComment->SetValue(ConfigManager::get_manager()->read_bool(wxT("/editor/folding/fold_comment"), true));
    label_fold_options->Add(m_FoldComment,  0, wxALL, 5);

    top_sizer->Add(m_EnableFolding, 0, wxALL, 5);
    top_sizer->Add(label_fold_options, 0, wxALL|wxEXPAND, 5);
    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);
    return panel;
}


wxPanel* miOutputSettingsDlg::CreateHighlightingPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);

    return panel;
}


void miOutputSettingsDlg::OnFontChooseBtn(wxCommandEvent& event)
{
    wxFontData data;
    data.SetInitialFont(m_font);

	wxFontDialog dlg(this, data);
    if (dlg.ShowModal() == wxID_OK)
    {
    	m_font = dlg.GetFontData().GetChosenFont();
		m_FontSample->SetFont(m_font);
		//ApplyColours();
    }

}


void miOutputSettingsDlg::OnOkBtn(wxCommandEvent& event)
{

    #if wxUSE_UNICODE
    ConfigManager::get_manager()->write_str(wxT("/output/font"), m_font.GetNativeFontInfoDesc());
    #else
    ConfigManager::get_manager()->write_str(wxT("/output/font"), m_font.GetNativeFontInfoDesc().ToUTF8());
    #endif
    event.Skip();
}
