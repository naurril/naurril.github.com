

#if !defined _MPLIDE_CONFIG_MANAGER_H__
#define _MPLIDE_CONFIG_MANAGER_H__

#include <wx/xml/xml.h>
class wxXmlDocument;
class wxXmlNode;

class ConfigManager
{
private:
    ConfigManager();
    ~ConfigManager();
public:
    bool load();
    bool save();

    wxString read(const wxString &name, const wxString &prop_name);
    void write(const wxString &name, const wxString &prop_name, const wxString &value);

    bool read_bool(const wxString &name, bool default_value);
    int read_value(const wxString &name, int default_value);
    wxString read_str(const wxString &name, const wxString &default_value = wxEmptyString);
    wxString read_cdata_str(const wxString &name, const wxString &default_value = wxEmptyString);
    wxString read_cdata_str(wxXmlNode *node, const wxString& default_value);
    wxArrayString read_array_str(const wxString &name);

    void write_bool(const wxString &name, bool value);
    void write_value(const wxString &name, int value);
    void write_str(const wxString &name, const wxString& value);
    void write_cdata_str(const wxString &name, const wxString& value);
    void write_cdata_str(wxXmlNode *node, const wxString& value);
    void write_array_str(const wxString &name, const wxArrayString &as);

    wxString get_cfg_dir() {return config_dir; }

private:
    bool load_default();
    bool load_from_file(const wxString &file);
    wxXmlNode *GetNode(const wxString &name, bool create_if_not_exist, wxXmlNodeType node_type=wxXML_ELEMENT_NODE);
    wxXmlNode *FindChild(wxXmlNode *parent, const wxString &name);
    void write(wxXmlNode* node, const wxString &prop_name, const wxString &value);
    wxString read(wxXmlNode* node, const wxString &prop_name);


    wxString C2U(const char* str)
    {
        return wxString(str, wxConvUTF8);
    }

    // Return multibyte (C string) representation of the string
    const wxWX2MBbuf U2C(const wxString& str)
    {
        return str.mb_str(wxConvUTF8);
    }


private:
    bool fileOK;  //no config file found.
    bool modified;
    wxXmlDocument *doc;
    wxXmlNode *root;

    wxString config_file_path;
    wxString config_dir;
private:
    static ConfigManager* manager;
public:
    static ConfigManager* get_manager();

};

#endif
