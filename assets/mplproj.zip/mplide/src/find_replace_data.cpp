
#include "find_replace_data.h"


void FindReplaceData::AddChoice(const wxString &choice)
{
    // find duplication

    for (int i = 0; i < n_choices; i++)
    {
        if (choice.Cmp(choices[i]) == 0)
        {
            choices[MAX_CHOICES] = choices[i];
            choices[i] = choices[0];
            choices[0] = choices[MAX_CHOICES];
            return;
        }
    }

    for (int i = n_choices; i >= 0; i--)
    {
        choices[i+1] = choices[i];
    }

    choices[0] = choice;

    if (n_choices < MAX_CHOICES)
        n_choices++;
}

void FindReplaceData::AddReplace(const wxString &replace)
{
    // find duplication

    for (int i = 0; i < n_replaces; i++)
    {
        if (replace.Cmp(replaces[i]) == 0)
        {
            replaces[MAX_CHOICES] = replaces[i];
            replaces[i] = replaces[0];
            replaces[0] = replaces[MAX_CHOICES];
            return;
        }
    }

    //make room for new one
    for (int i = n_replaces; i > 0; i--)
    {
        replaces[i+1] = replaces[i];
    }

    replaces[0] = replace;

    if (n_replaces < MAX_CHOICES)
        n_replaces++;
}
