


#if !defined _MPLIDE_RUN_DLG_H__
#define _MPLIDE_RUN_DLG_H__


#include <wx/propdlg.h>
class wxPanel;
class wxCheckBox;
class wxTextCtrl;
class miRunDlg : public wxPropertySheetDialog
{
    enum
    {
        ID_RawStreamFileChoose = wxID_HIGHEST+300,
        ID_MplFileChoose,
        ID_CHOOSE_INPUT,

    };

public:
    miRunDlg(wxWindow* parent);
    ~miRunDlg();
    void set_mpl_file_path(const wxString &path);

    wxString get_mpl_file_path()const {return tc_mpl_file_path->GetLineText(0);}
    wxString get_raw_stream_file_path()const {return tc_raw_stream_file_path->GetLineText(0);}
    int get_raw_stream_text_line_number()const;
    wxString get_raw_stream_text_line(int n)const;
    wxString get_raw_stream_text()const{return tc_raw_stream_text->GetValue();}

    int get_input_option() const {return rb_input_option->GetSelection();}
    wxString get_extra_options()const{return tc_extra_options->GetLineText(0);}
    bool get_clear_prev_result()const{return cb_clear_prev_result->GetValue();}
    bool get_input_hex_no_0x()const{return cb_input_hex_no_0x->GetValue();}
    bool get_show_hex_format()const{return cb_show_hex_format->GetValue();}
    bool get_show_msg_only()const{return cb_show_msg_only->GetValue();}
    bool get_beautify_message()const{return cb_beautify_message->GetValue();}

private:
    bool Create(wxWindow* parent);
    wxPanel* CreateGeneralPage(wxWindow *parent);
    wxPanel* CreateOptionsPage(wxWindow *parent);
    wxPanel* CreateResultPage(wxWindow *parent);

    wxTextCtrl *tc_mpl_file_path;
    wxTextCtrl *tc_raw_stream_file_path;
    wxTextCtrl *tc_raw_stream_text;
    wxTextCtrl *tc_result_text;
    wxTextCtrl *tc_extra_options;
    wxRadioBox *rb_output_option;
    wxRadioBox *rb_input_option;
    wxButton   *bt_raw_stream_file_choose;
    wxCheckBox *cb_clear_prev_result;

    wxCheckBox* cb_show_msg_only;
    wxCheckBox* cb_input_hex_no_0x;
    wxCheckBox* cb_beautify_message;
    wxCheckBox* cb_show_hex_format;





private:
    void OnOkBtn(wxCommandEvent& event);
    void OnRawStreamFileChoose(wxCommandEvent& event);
    void OnInputMannerChoose(wxCommandEvent& event);
    void OnMplFileChoose(wxCommandEvent& event);
    void miRunDlg::UpdateInputMannerUi();

    void load_raw_stream_text();
    void save_raw_stream_text();

DECLARE_EVENT_TABLE()
};

#endif

