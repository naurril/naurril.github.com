#include <wx/bookctrl.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/statbox.h>
#include <wx/checkbox.h>
#include <wx/stattext.h>
#include <wx/button.h>
#include <wx/textctrl.h>
#include <wx/filedlg.h>
#include <wx/dirdlg.h>
//#include <wx/combobox.h>
#include <wx/radiobox.h>
#include <wx/choice.h>
#include <wx/filename.h>
#include <wx/textfile.h>

#include <fstream>

#include "environment_settings_dlg.h"
#include "config_manager.h"
#include "run_dlg.h"

BEGIN_EVENT_TABLE(miRunDlg, wxPropertySheetDialog)
    EVT_BUTTON(wxID_OK, miRunDlg::OnOkBtn)
    EVT_BUTTON(ID_MplFileChoose, miRunDlg::OnMplFileChoose)
    EVT_BUTTON(ID_RawStreamFileChoose, miRunDlg::OnRawStreamFileChoose)
    EVT_RADIOBOX(ID_CHOOSE_INPUT, miRunDlg::OnInputMannerChoose)
END_EVENT_TABLE()


miRunDlg::miRunDlg(wxWindow* parent)
{
    Create(parent);
}

miRunDlg::~miRunDlg()
{
    //save extra options


    //save options
}

bool miRunDlg::Create(wxWindow* parent)
{
    if (!wxPropertySheetDialog::Create(parent, -1, wxT("Run"), wxDefaultPosition, wxDefaultSize,
                wxDEFAULT_DIALOG_STYLE|wxRESIZE_BORDER|wxMAXIMIZE_BOX|wxMINIMIZE_BOX))
        return false;

    SetSheetStyle( wxPROPSHEET_DEFAULT | wxPROPSHEET_BUTTONTOOLBOOK);
    SetSheetInnerBorder(0);
    SetSheetOuterBorder(2);

    CreateButtons(wxOK|wxCANCEL);

    wxBookCtrlBase* notebook = GetBookCtrl();
    wxPanel *general_settings = CreateGeneralPage(notebook);
    wxPanel *options_settings = CreateOptionsPage(notebook);
    //wxPanel *run_result = CreateResultPage(notebook);

    notebook->AddPage(general_settings, wxT("General"));
    notebook->AddPage(options_settings, wxT("Options"));
    //notebook->AddPage(run_result, wxT("Result"));

    LayoutDialog();
    return true;
}

wxPanel* miRunDlg::CreateGeneralPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);

    wxStaticBoxSizer *label_src = new wxStaticBoxSizer(wxHORIZONTAL, panel, wxT("MPL source file"));
    tc_mpl_file_path = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,-1));
    tc_mpl_file_path->AppendText(ConfigManager::get_manager()->read_str(wxT("/run/mpl_file_path")));
    label_src->Add(tc_mpl_file_path, 1, wxALIGN_CENTER, 0);
    label_src->Add(new wxButton(panel, ID_MplFileChoose, wxT("Choose")), 0, wxALIGN_CENTER, 0);
    top_sizer->Add(label_src, 0, wxALL|wxEXPAND, 5);


    // input manner optoins
    wxStaticBoxSizer *label_input = new wxStaticBoxSizer(wxVERTICAL, panel, wxT("Raw stream data input"));

    wxString input_choices[]={wxT("Input raw-stream data"), wxT("Use raw-stream data file"),  wxT("No raw-stream data")};
    rb_input_option = new wxRadioBox(panel, ID_CHOOSE_INPUT, wxT("Choose Input"), wxDefaultPosition, wxDefaultSize, 3, input_choices,1);
    label_input->Add(rb_input_option, 0, wxALL|wxEXPAND, 0);

    //label_input->Add(new wxStaticText(panel, wxID_ANY, wxT("Use raw-stream file:")), 0, wxTOP|wxLEFT|wxALIGN_CENTER_VERTICAL, 0);
    wxBoxSizer *sizer_1 = new wxBoxSizer(wxHORIZONTAL);
    tc_raw_stream_file_path = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,-1));
    tc_raw_stream_file_path->AppendText(ConfigManager::get_manager()->read_str(wxT("/run/raw_stream_file_path")));
    bt_raw_stream_file_choose = new wxButton(panel, ID_RawStreamFileChoose, wxT("Choose"));
    sizer_1->Add(tc_raw_stream_file_path, 1, wxALIGN_CENTER, 0);
    sizer_1->Add(bt_raw_stream_file_choose, 0, wxALIGN_CENTER, 0);
    label_input->Add(sizer_1, 0, wxEXPAND, 0);

    rb_input_option->SetSelection(ConfigManager::get_manager()->read_value(wxT("/run/input_option"), 0));

    //label_input->Hide();

 //   label_input->Add(new wxStaticText(panel, wxID_ANY, "Input raw-stream-data:"), 0, wxALIGN_LEFT, 0);
    tc_raw_stream_text = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,300), wxTE_MULTILINE|wxTE_DONTWRAP|wxTE_AUTO_SCROLL);
    load_raw_stream_text();
    label_input->Add(tc_raw_stream_text, 1, wxEXPAND, 0);
    //tc_raw_stream_text->Hide();

    top_sizer->Add(label_input, 1, wxALL|wxEXPAND, 5);

    wxBoxSizer *sizer_bottom = new wxBoxSizer(wxHORIZONTAL);

    wxString output_choices[2]={wxT("output to new file"), wxT("output to result window")};
    rb_output_option = new wxRadioBox(panel, wxID_ANY, wxT("Output options"), wxDefaultPosition, wxDefaultSize, 2, output_choices,1);
    sizer_bottom->Add(rb_output_option, 1, wxALL|wxEXPAND, 0);

    // misc options
    wxStaticBoxSizer *label_misc = new wxStaticBoxSizer(wxVERTICAL, panel, wxT("Misc options"));
    cb_clear_prev_result = new wxCheckBox(panel, wxID_ANY, wxT("Clear previous result"));
    cb_clear_prev_result->SetValue(ConfigManager::get_manager()->read_bool(wxT("/run/clear_prev_result"), true));
    label_misc->Add(cb_clear_prev_result, 0, wxALL|wxEXPAND, 5);

    sizer_bottom->Add(label_misc, 1, wxALL|wxEXPAND, 0);

    top_sizer->Add(sizer_bottom, 0, wxALL, 5);

    UpdateInputMannerUi();

    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);

    return panel;
}

wxPanel* miRunDlg::CreateOptionsPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);


    wxStaticBoxSizer *box_optons = new wxStaticBoxSizer(wxVERTICAL, panel, wxT("Options"));
    cb_show_msg_only = new wxCheckBox(panel, wxID_ANY, wxT("Show message only"));
    cb_show_msg_only->SetValue(ConfigManager::get_manager()->read_bool(wxT("/run/show_msg_only"), false));
    box_optons->Add(cb_show_msg_only, 0, wxALL|wxEXPAND, 2);

    cb_show_hex_format = new wxCheckBox(panel, wxID_ANY, wxT("Show messages in hex format"));
    cb_show_hex_format->SetValue(ConfigManager::get_manager()->read_bool(wxT("/run/show_hex_format"), false));
    box_optons->Add(cb_show_hex_format, 0, wxALL|wxEXPAND, 2);

    cb_beautify_message = new wxCheckBox(panel, wxID_ANY, wxT("Beautify message"));
    cb_beautify_message->SetValue(ConfigManager::get_manager()->read_bool(wxT("/run/beautify_message"), false));
    box_optons->Add(cb_beautify_message, 0, wxALL|wxEXPAND, 2);


    cb_input_hex_no_0x = new wxCheckBox(panel, wxID_ANY, wxT("Treat input stream as hex number without 0x-header"));
    cb_input_hex_no_0x->SetValue(ConfigManager::get_manager()->read_bool(wxT("/run/input_hex_no_0x"), false));
    box_optons->Add(cb_input_hex_no_0x, 0, wxALL|wxEXPAND, 2);

    top_sizer->Add(box_optons, 0, wxALL|wxEXPAND, 5);

    wxStaticBoxSizer *box_extra_optoins = new wxStaticBoxSizer(wxHORIZONTAL, panel, wxT("Extra options"));
    tc_extra_options = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,-1));
    tc_extra_options->AppendText(ConfigManager::get_manager()->read_str(wxT("/run/extra_options")));
    box_extra_optoins->Add(tc_extra_options, 0, wxALL|wxEXPAND, 0);
    top_sizer->Add(box_extra_optoins, 0, wxALL|wxEXPAND, 5);


    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);
    return panel;
}

wxPanel* miRunDlg::CreateResultPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);

    top_sizer->Add(new wxStaticText(panel, wxID_ANY, wxT("output")), 0, wxTOP | wxALIGN_LEFT, 5);
    tc_result_text = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,300), wxTE_MULTILINE|wxTE_DONTWRAP|wxTE_AUTO_SCROLL);
    top_sizer->Add(tc_result_text, 1, wxEXPAND|wxBOTTOM, 5);


    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);
    return panel;
}

void miRunDlg::UpdateInputMannerUi()
{
    int n = rb_input_option->GetSelection();
    this->Freeze();
    if (n == 0)
    {
        tc_raw_stream_file_path->Disable();
        bt_raw_stream_file_choose->Disable();
        tc_raw_stream_text->Enable();
    }
    else if (n == 1)
    {
        tc_raw_stream_file_path->Enable();
        bt_raw_stream_file_choose->Enable();
        tc_raw_stream_text->Disable();
    }
    else
    {
        tc_raw_stream_file_path->Disable();
        bt_raw_stream_file_choose->Disable();
        tc_raw_stream_text->Disable();
    }

    this->Thaw();
}

void miRunDlg::OnInputMannerChoose(wxCommandEvent& event)
{
    UpdateInputMannerUi();
}


void miRunDlg::OnOkBtn(wxCommandEvent& event)
{
    ConfigManager::get_manager()->write_str(wxT("/run/extra_options"), get_extra_options());
    ConfigManager::get_manager()->write_bool(wxT("/run/clear_prev_result"), get_clear_prev_result());
    ConfigManager::get_manager()->write_value(wxT("/run/input_option"), rb_input_option->GetSelection());
    ConfigManager::get_manager()->write_str(wxT("/run/raw_stream_file_path"), get_raw_stream_file_path());
    ConfigManager::get_manager()->write_str(wxT("/run/mpl_file_path"), get_mpl_file_path());

    ConfigManager::get_manager()->write_bool(wxT("/run/input_hex_no_0x"), get_input_hex_no_0x());
    ConfigManager::get_manager()->write_bool(wxT("/run/show_msg_only"), get_show_msg_only());
    ConfigManager::get_manager()->write_bool(wxT("/run/show_hex_format"), get_show_hex_format());
    ConfigManager::get_manager()->write_bool(wxT("/run/beautify_message"), get_beautify_message());

    save_raw_stream_text();

    event.Skip();
}

void miRunDlg::OnMplFileChoose(wxCommandEvent& event)
{
    wxFileName file(tc_mpl_file_path->GetLineText(0));

	wxFileDialog* dlg = new wxFileDialog(this, wxT("Choose file"),  file.GetPath(), file.GetName());

    if (dlg->ShowModal() == wxID_OK)
    {
        wxString pathname = dlg->GetPath();
        tc_mpl_file_path->Clear();
        tc_mpl_file_path->AppendText(pathname);
    }
    else
    {
    }

    dlg->Destroy();
}
void miRunDlg::OnRawStreamFileChoose(wxCommandEvent& event)
{
    wxFileName file(tc_raw_stream_file_path->GetLineText(0));
    wxFileDialog* dlg = new wxFileDialog(this, wxT("Choose file"), file.GetPath(), file.GetName());

    if (dlg->ShowModal() == wxID_OK)
    {
        wxString pathname = dlg->GetPath();
        tc_raw_stream_file_path->Clear();
        tc_raw_stream_file_path->AppendText(pathname);
    }
    else
    {
    }

    dlg->Destroy();
}

void miRunDlg::set_mpl_file_path(const wxString &path)
{
    tc_mpl_file_path->Clear();
    tc_mpl_file_path->AppendText(path);
}


void miRunDlg::load_raw_stream_text()
{
    if (!tc_raw_stream_text)
        return;


#if 1
    // use file. commented
    wxString file_name = ConfigManager::get_manager()->get_cfg_dir() + wxT("/raw_stream_content.txt");


    wxTextFile tf(file_name);

    if (!tf.Exists())
        return;

    tf.Open();
    if (tf.IsOpened())
    {
        wxString str;
        str = tf.GetFirstLine();

        while (1)
        {
            tc_raw_stream_text->AppendText(str);
            str = tf.GetNextLine();

            if (!tf.Eof())
            {
                tc_raw_stream_text->AppendText(wxT("\n"));
            }
            else
            {
                tc_raw_stream_text->AppendText(str);
                break;
            }
        }
    }


#else // use xml cdata section
    wxString cont = ConfigManager::get_manager()->read_cdata_str(wxT("/run/raw_stream_text"));
    tc_raw_stream_text->AppendText(cont);
    return;

#endif
}


void miRunDlg::save_raw_stream_text()
{
    if (!tc_raw_stream_text)
        return;

    wxString value;

#if 1 // use file

    wxString file_name = ConfigManager::get_manager()->get_cfg_dir() + wxT("/raw_stream_content.txt");

    wxTextFile tf(file_name);

    if (!tf.Exists())
        tf.Create();
    tf.Open();
    tf.Clear();

    if (tf.IsOpened())
    {
        /*
        for (int i = 0; i < tc_raw_stream_text->GetNumberOfLines(); i++)
        {
            tf.AddLine(tc_raw_stream_text->GetLineText(i));
        }
        */
        tf.AddLine(tc_raw_stream_text->GetRange(0,-1));
    }
    tf.Write();
    tf.Close();

#else // use xml cdata section
    {
        for (int i = 0; i < tc_raw_stream_text->GetNumberOfLines(); i++)
        {
           // tf.AddLine(tc_raw_stream_text->GetLineText(i));
            if (i)
                value<<wxT("\n");
            value << tc_raw_stream_text->GetLineText(i);
        }
    }
    //tf.Write();
    ConfigManager::get_manager()->write_cdata_str(wxT("/run/raw_stream_text"), value);
#endif
}

int miRunDlg::get_raw_stream_text_line_number()const
{
    return tc_raw_stream_text->GetNumberOfLines();
}
wxString miRunDlg::get_raw_stream_text_line(int n)const
{

    int lines = tc_raw_stream_text->GetNumberOfLines();
    if (n < lines)
        return tc_raw_stream_text->GetLineText(n);
    else
        return wxT("");
}
