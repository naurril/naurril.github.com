
#include <wx/bookctrl.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/statbox.h>
#include <wx/checkbox.h>
#include <wx/stattext.h>
#include <wx/button.h>
#include <wx/textctrl.h>
#include <wx/filedlg.h>
#include <wx/dirdlg.h>
#include <wx/filename.h>
#include "environment_settings_dlg.h"
#include "config_manager.h"


BEGIN_EVENT_TABLE(miEnvironmentSettingsDlg, wxPropertySheetDialog)
    EVT_BUTTON(wxID_OK, miEnvironmentSettingsDlg::OnOkBtn)
    EVT_BUTTON(ID_MplExeChoose, miEnvironmentSettingsDlg::OnMplExeChoose)
    EVT_BUTTON(ID_MplLibChoose, miEnvironmentSettingsDlg::OnMplLibChoose)
END_EVENT_TABLE()


miEnvironmentSettingsDlg::miEnvironmentSettingsDlg(wxWindow* parent)
{
    Create(parent);
}

miEnvironmentSettingsDlg::~miEnvironmentSettingsDlg()
{
}

bool miEnvironmentSettingsDlg::Create(wxWindow* parent)
{
    if (!wxPropertySheetDialog::Create(parent, -1, wxT("Environment settings")))
        return false;

    SetSheetStyle(wxPROPSHEET_SHRINKTOFIT | wxPROPSHEET_BUTTONTOOLBOOK);
    SetSheetInnerBorder(0);
    SetSheetOuterBorder(2);

    CreateButtons(wxOK|wxCANCEL);

    wxBookCtrlBase* notebook = GetBookCtrl();
    wxPanel *general_settings = CreateGeneralPage(notebook);
    wxPanel *syntax_checking_settings = CreateSyntaxCheckOptionsPage(notebook);
    wxPanel *run_settings = CreateRunOptionsPage(notebook);

    notebook->AddPage(general_settings, wxT("General"));
    notebook->AddPage(syntax_checking_settings, wxT("Syntax checking"));
    notebook->AddPage(run_settings, wxT("Run"));

    LayoutDialog();
    return true;
}

wxPanel* miEnvironmentSettingsDlg::CreateGeneralPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);

    wxBoxSizer *sizer_1 = new wxBoxSizer(wxHORIZONTAL);
    mpl_path = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,-1));
    mpl_path->Clear();
    mpl_path->AppendText(ConfigManager::get_manager()->read_str(wxT("/environment/general/mpl_exe_path")));
    top_sizer->Add(new wxStaticText(panel, wxID_ANY, wxT("mpl executable path:")), 0, wxTOP|wxLEFT|wxALIGN_CENTER_VERTICAL, 5);
    sizer_1->Add(mpl_path, 0, wxRIGHT|wxALIGN_CENTER_VERTICAL| wxALIGN_RIGHT, 0);
    sizer_1->Add(new wxButton(panel, ID_MplExeChoose, wxT("Choose")), 0, wxALL | wxALIGN_RIGHT, 0);
    top_sizer->Add(sizer_1, 0, wxALL, 5);

    wxBoxSizer *sizer_2 = new wxBoxSizer(wxHORIZONTAL);
    mpl_lib_path = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,-1));
    mpl_lib_path->Clear();
    mpl_lib_path->AppendText(ConfigManager::get_manager()->read_str(wxT("/environment/general/mpl_lib_path")));

    top_sizer->Add(new wxStaticText(panel, wxID_ANY, wxT("MPL lib path (optional): ")), 0, wxTOP|wxLEFT|wxALIGN_CENTER_VERTICAL, 5);
    sizer_2->Add(mpl_lib_path, 0, wxRIGHT|wxALIGN_CENTER_VERTICAL| wxALIGN_RIGHT, 0);
    sizer_2->Add(new wxButton(panel, ID_MplLibChoose, wxT("Choose")), 0, wxALL | wxALIGN_RIGHT, 0);
    top_sizer->Add(sizer_2, 0, wxALL, 5);


    wxBoxSizer *sizer_3 = new wxBoxSizer(wxHORIZONTAL);
    wxTextCtrl *search_path = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,300), wxTE_MULTILINE|wxTE_AUTO_SCROLL);
    top_sizer->Add(new wxStaticText(panel, wxID_ANY, wxT("Extra search paths: ")), 0, wxTOP|wxLEFT|wxALIGN_CENTER_VERTICAL, 5);
    sizer_3->Add(search_path, 0, wxRIGHT|wxALIGN_CENTER_VERTICAL| wxALIGN_RIGHT, 0);
    sizer_3->Add(new wxButton(panel, wxID_ANY, wxT("Add")), 0, wxALL | wxALIGN_RIGHT, 0);
    top_sizer->Add(sizer_3, 0, wxALL, 5);


    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);

    return panel;
}

wxPanel* miEnvironmentSettingsDlg::CreateSyntaxCheckOptionsPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);


    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);

    return panel;
}



wxPanel* miEnvironmentSettingsDlg::CreateRunOptionsPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);

    wxStaticBoxSizer *box = new wxStaticBoxSizer(wxHORIZONTAL, panel, wxT("Options"));
    run_options = new wxTextCtrl(panel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(400,-1));
    run_options->AppendText(ConfigManager::get_manager()->read_str(wxT("/environment/run/options")));
    box->Add(run_options, 0, wxALL|wxEXPAND, 0);
    top_sizer->Add(box, 0, wxALL|wxEXPAND, 5);


    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);
    return panel;
}


void miEnvironmentSettingsDlg::OnOkBtn(wxCommandEvent& event)
{

    ConfigManager::get_manager()->write_str(wxT("/environment/general/mpl_exe_path"), mpl_path->GetLineText(0));
    ConfigManager::get_manager()->write_str(wxT("/environment/general/mpl_lib_path"), mpl_lib_path->GetLineText(0));
    ConfigManager::get_manager()->write_str(wxT("/environment/run/options"), run_options->GetLineText(0));
    event.Skip();
}


void miEnvironmentSettingsDlg::OnMplExeChoose(wxCommandEvent& event)
{
    wxFileName file(mpl_path->GetLineText(0));

    wxFileDialog* dlg = new wxFileDialog(this, wxT("Choose file"), file.GetPath(), file.GetName());

    if (dlg->ShowModal() == wxID_OK)
    {
        wxString pathname = dlg->GetPath();
        mpl_path->Clear();
        mpl_path->AppendText(pathname);
    }
    else
    {
    }

    dlg->Destroy();
}

void miEnvironmentSettingsDlg::OnMplLibChoose(wxCommandEvent& event)
{
    wxDirDialog* dlg = new wxDirDialog(this, wxT("Choose directory"), mpl_lib_path->GetLineText(0));

    if (dlg->ShowModal() == wxID_OK)
    {
        wxString pathname = dlg->GetPath();
        mpl_lib_path->Clear();
        mpl_lib_path->AppendText(pathname);
    }
    else
    {
    }

    dlg->Destroy();
}
