
#if !defined __MPLIDE_EDITOR_MANAGER_H__
#define __MPLIDE_EDITOR_MANAGER_H__

class miEditor;
class EditorManager
{
private:
	EditorManager();
	~EditorManager();


public:
	static EditorManager* GetEditorManager()
	{
		if (!manager) manager = new EditorManager;
		return manager;
	}


private:
	static EditorManager *manager;



};


#endif
