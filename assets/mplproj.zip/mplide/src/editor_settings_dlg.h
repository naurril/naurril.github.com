

#if !defined _MPLIDE_EDITOR_SETTINGS_DLG_H__
#define _MPLIDE_EDITOR_SETTINGS_DLG_H__

#include <wx/propdlg.h>
class wxPanel;
class wxCheckBox;
class wxSpinCtrl;
class miEditorSettingsDlg : public wxPropertySheetDialog
{
    enum
    {
        ID_FontChoose = wxID_HIGHEST+100,
    };

public:
    miEditorSettingsDlg(wxWindow* parent);
    ~miEditorSettingsDlg();
private:
    bool Create(wxWindow* parent);
    wxPanel* CreateGeneralPage(wxWindow *parent);
    wxPanel* CreateHighlightingPage(wxWindow *parent);
    wxPanel* CreateFoldingPage(wxWindow *parent);
    wxString m_FontString;
    wxStaticText* m_FontSample;


    wxCheckBox* m_EnableFolding;
    wxCheckBox* m_FoldComment;
    wxCheckBox* use_tab_check ;
    wxCheckBox* tab_indent_check;
    wxSpinCtrl* tab_size;

private:
    void OnFontChooseBtn(wxCommandEvent& event);
    void OnOkBtn(wxCommandEvent& event);


DECLARE_EVENT_TABLE()
};

#endif //_MPLIDE_EDITOR_SETTINGS_DLG_H__
