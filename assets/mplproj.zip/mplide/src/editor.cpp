
#include <wx/splitter.h>
#include <wx/sizer.h>
#include <wx/stc/stc.h>
#include "editor.h"
#include "config_manager.h"

BEGIN_EVENT_TABLE(miEditor, wxPanel)
END_EVENT_TABLE()

miEditor::miEditor(wxWindow* parent, const wxString& filename):wxPanel(parent,-1)
{
    m_pFont = new wxFont(10, wxMODERN, wxNORMAL, wxNORMAL);  //default font

    Freeze();
    m_pSizer = new wxBoxSizer(wxVERTICAL);
    m_pControl = CreateEditor();

    m_pSizer->Add(m_pControl, 1,  wxEXPAND);
    SetSizer(m_pSizer);

    UpdateUI();
    Thaw();
}

miEditor::~miEditor()
{
    delete m_pFont;
}

bool miEditor::GetModified()const
{
	return m_pControl->GetModify();
}

wxStyledTextCtrl* miEditor::CreateEditor()
{

    int m_ID = wxNewId();
    wxStyledTextCtrl* control;
    control = new wxStyledTextCtrl(this,m_ID,
                          wxPoint(0,0), wxSize(150,90),
                          wxNO_BORDER | wxSTC_STYLE_DEFAULT,
                          wxT("helo"));

	// dynamic events
    Connect( m_ID,  -1, wxEVT_STC_MARGINCLICK,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnMarginClick );
    Connect( m_ID,  -1, wxEVT_STC_UPDATEUI,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnEditorUpdateUI );
    Connect( m_ID,  -1, wxEVT_STC_CHANGE,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnEditorChange );
    Connect( m_ID,  -1, wxEVT_STC_CHARADDED,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnEditorCharAdded );
    Connect( m_ID,  -1, wxEVT_STC_DWELLSTART,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnEditorDwellStart );
    Connect( m_ID,  -1, wxEVT_STC_DWELLEND,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnEditorDwellEnd );
    Connect( m_ID,  -1, wxEVT_STC_USERLISTSELECTION,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnUserListSelection );
    Connect( m_ID,  -1, wxEVT_STC_MODIFIED,
                  (wxObjectEventFunction) (wxEventFunction) (wxStyledTextEventFunction)
                  &miEditor::OnEditorModified );

	return control;
}

bool miEditor::SaveFile(const wxString& filename)
{
	if (filename == wxT("")) // save directory
	{
		if (HasFilePath())
			return m_pControl->SaveFile(file_path);
		else
			return false;
	}
	else
	{
		if (true == m_pControl->SaveFile(filename))
		{
			file_path = filename;
			return true;
		}
		else
			return false;
	}
	//ApplyStyle();
}

bool miEditor::LoadFile (const wxString &file, int fileType)
{
    if (false == m_pControl->LoadFile(file))
    {
        return false;
    }

	file_path = file;

	//ApplyStyle();


    return true;
}

void miEditor::UpdateStyleConfig()
{
    #if wxUSE_UNICODE
        wxString font_str = ConfigManager::get_manager()->read_str(wxT("/editor/font"));
    #else
        wxString font_str = ConfigManager::get_manager()->read_str(wxT("/editor/font")).To8BitData();
	#endif


	if (!font_str.IsEmpty())
    {
        m_pFont->SetNativeFontInfo(font_str);
    }

    m_nTabSize = ConfigManager::get_manager()->read_value(wxT("/editor/tab_options/tab_size"), 4);
}

void miEditor::UpdateUI()
{
    UpdateStyleConfig();
    ApplyStyle();
}

void miEditor::ApplyStyle()
{
    //font
    for (int i = 0; i < 36; i++)
    {
        m_pControl->StyleSetFaceName(i, m_pFont->GetFaceName());
        m_pControl->StyleSetSize(i, m_pFont->GetPointSize());
        //m_pControl->StyleSetFont(i, *m_pFont);
    }

	m_pControl->StyleClearAll();

	m_pControl->SetLexer(wxSTC_LEX_PYTHON);

    m_pControl->SetStyleBits(m_pControl->GetStyleBitsNeeded());
    m_pControl->StyleSetForeground(0, wxColour(0x80,0x80,0x80));
    m_pControl->StyleSetForeground(1, wxColour(0,0x7f,0));
    m_pControl->StyleSetForeground(2, wxColour(0,0x7f,0x7f));
    m_pControl->StyleSetForeground(3, wxColour(0x7f,0,0x7f));
    m_pControl->StyleSetForeground(4, wxColour(0x7f,0,0x7f));
    m_pControl->StyleSetForeground(5, wxColour(0,0,0x7f));
    m_pControl->StyleSetForeground(6, wxColour(0x7f,0,0x0));
    m_pControl->StyleSetForeground(7, wxColour(0x7f,0,0x0));
    m_pControl->StyleSetForeground(8, wxColour(0,0,0xff));
    m_pControl->StyleSetForeground(9, wxColour(0,0x7f,0x7f));
    //m_pControl->StyleSetForeground(10, wxColour(0,0,0x7f));
    //m_pControl->StyleSetForeground(11, wxColour(0,0,0x7f));
    m_pControl->StyleSetForeground(12, wxColour(0x7f,0x7f,0x7f));
    m_pControl->StyleSetForeground(13, wxColour(0,0,0));
    m_pControl->StyleSetForeground(14, wxColour(0x40,0x70,0x90));
    m_pControl->StyleSetForeground(15, wxColour(0x80,0x50,0x00));
    m_pControl->StyleSetForeground(34, wxColour(0x00,0x00,0xff));
    m_pControl->StyleSetForeground(35, wxColour(0xff,0x00,0x00));


    //tab size
    m_pControl->SetTabWidth(m_nTabSize);
    //keys

    m_pControl->SetKeyWords(0, wxT("vnldef msgdef funcdef while default or and if else elif try_loop for optional fixed multiple interpret"));
    m_pControl->SetKeyWords(1, wxT("assert check o octets get_octets b bits get_bits"));
    m_pControl->Colourise(0, -1);

    //line number, margin 0
    //m_pControl->StyleClearAll();
    m_pControl->SetMarginWidth(0, 30);
    m_pControl->SetMarginType(0,  wxSTC_MARGIN_NUMBER);
    m_pControl->SetMarginSensitive(0, false);
    //m_pControl->SetMarginMask(0, 255);

    //book marker, margin 1
    m_pControl->SetMarginType(1, wxSTC_MARGIN_SYMBOL);
    m_pControl->SetMarginWidth(1, 12);
    m_pControl->SetMarginSensitive(1, false);


    m_pControl->SetProperty(wxT("fold"), wxT("1"));
    m_pControl->SetFoldFlags(16);
    m_pControl->SetMarginType(2,  wxSTC_MARGIN_SYMBOL);
    m_pControl->SetMarginWidth(2, 10);
    m_pControl->SetMarginMask(2, wxSTC_MASK_FOLDERS);
    m_pControl->SetMarginSensitive(2, true);

	m_pControl->MarkerDefine(wxSTC_MARKNUM_FOLDEROPEN, wxSTC_MARK_BOXMINUS);
	m_pControl->MarkerSetForeground(wxSTC_MARKNUM_FOLDEROPEN, wxColour(0xff, 0xff, 0xff));
	m_pControl->MarkerSetBackground(wxSTC_MARKNUM_FOLDEROPEN, wxColour(0x80, 0x80, 0x80));
	m_pControl->MarkerDefine(wxSTC_MARKNUM_FOLDER, wxSTC_MARK_BOXPLUS);
	m_pControl->MarkerSetForeground(wxSTC_MARKNUM_FOLDER, wxColour(0xff, 0xff, 0xff));
	m_pControl->MarkerSetBackground(wxSTC_MARKNUM_FOLDER, wxColour(0x80, 0x80, 0x80));
	m_pControl->MarkerDefine(wxSTC_MARKNUM_FOLDERSUB, wxSTC_MARK_VLINE);
	m_pControl->MarkerSetForeground(wxSTC_MARKNUM_FOLDERSUB, wxColour(0xff, 0xff, 0xff));
	m_pControl->MarkerSetBackground(wxSTC_MARKNUM_FOLDERSUB, wxColour(0x80, 0x80, 0x80));
	m_pControl->MarkerDefine(wxSTC_MARKNUM_FOLDERTAIL, wxSTC_MARK_LCORNER);
	m_pControl->MarkerSetForeground(wxSTC_MARKNUM_FOLDERTAIL, wxColour(0xff, 0xff, 0xff));
	m_pControl->MarkerSetBackground(wxSTC_MARKNUM_FOLDERTAIL, wxColour(0x80, 0x80, 0x80));
	m_pControl->MarkerDefine(wxSTC_MARKNUM_FOLDEREND, wxSTC_MARK_BOXPLUSCONNECTED);
	m_pControl->MarkerSetForeground(wxSTC_MARKNUM_FOLDEREND, wxColour(0xff, 0xff, 0xff));
	m_pControl->MarkerSetBackground(wxSTC_MARKNUM_FOLDEREND, wxColour(0x80, 0x80, 0x80));
	m_pControl->MarkerDefine(wxSTC_MARKNUM_FOLDEROPENMID, wxSTC_MARK_BOXMINUSCONNECTED);
	m_pControl->MarkerSetForeground(wxSTC_MARKNUM_FOLDEROPENMID, wxColour(0xff, 0xff, 0xff));
	m_pControl->MarkerSetBackground(wxSTC_MARKNUM_FOLDEROPENMID, wxColour(0x80, 0x80, 0x80));
	m_pControl->MarkerDefine(wxSTC_MARKNUM_FOLDERMIDTAIL, wxSTC_MARK_TCORNER);
	m_pControl->MarkerSetForeground(wxSTC_MARKNUM_FOLDERMIDTAIL, wxColour(0xff, 0xff, 0xff));
	m_pControl->MarkerSetBackground(wxSTC_MARKNUM_FOLDERMIDTAIL, wxColour(0x80, 0x80, 0x80));

    m_pControl->Colourise(0, -1);


}


void miEditor::HightLightLine(int lineno)
{
    m_pControl->GotoLine(lineno);
    m_pControl->MarkerAdd(lineno, 1);
}


wxString miEditor::GetLineIndentString(int line)
{
    wxStyledTextCtrl* control = GetControl();
    int currLine = (line == -1)
                    ? control->LineFromPosition(control->GetCurrentPos())
                    : line;
    wxString text = control->GetLine(currLine);
    unsigned int len = text.Length();
    wxString indent;
    for (unsigned int i = 0; i < len; ++i)
    {
        if (text[i] == wxT(' ') || text[i] == wxT('\t'))
            indent << text[i];
        else
            break;
    }
    return indent;
}

/** Get the last non-whitespace character before position */
wxChar miEditor::GetLastNonWhitespaceChar(int position)
{
    wxStyledTextCtrl* control = GetControl();
    if (position == -1)
        position = control->GetCurrentPos();

    int count = 0; // Used to count the number of blank lines
    bool foundlf = false; // For the rare case of CR's without LF's
    while (position)
    {
        wxChar c = control->GetCharAt(--position);
        int style = control->GetStyleAt(position);
        bool inComment = style == wxSTC_C_COMMENT; /* ||   // we have only one comment style in MPL
                        style == wxSTC_C_COMMENTDOC ||
                        style == wxSTC_C_COMMENTDOCKEYWORD ||
                        style == wxSTC_C_COMMENTDOCKEYWORDERROR ||
                        style == wxSTC_C_COMMENTLINE ||
                        style == wxSTC_C_COMMENTLINEDOC; */
        if (c == wxT('\n'))
        {
            count++;
            foundlf = true;
        }
        else if ((c == wxT('\r')) && !foundlf)
            count++;
        else
            foundlf = false;
        if (count > 1) return 0; // Don't over-indent
        if (!inComment && c != wxT(' ') && c != wxT('\t') && c != wxT('\n') && c != wxT('\r'))
            return c;
    }
    return 0;
}

void miEditor::OnMarginClick(wxStyledTextEvent& event)
{
    switch (event.GetMargin())
    {
        case 1: // bookmarks and breakpoints margin
        {
            int lineYpix = event.GetPosition();
            int line = GetControl()->LineFromPosition(lineYpix);

//            ToggleBreakpoint(line);
            break;
        }
        case 2: // folding margin
        {
            int lineYpix = event.GetPosition();
            int line = GetControl()->LineFromPosition(lineYpix);

            GetControl()->ToggleFold(line);
            break;
        }
    }
}

void miEditor::OnEditorUpdateUI(wxStyledTextEvent& event)
{
}

void miEditor::OnEditorChange(wxStyledTextEvent& event)
{

}
void miEditor::OnEditorCharAdded(wxStyledTextEvent& event)
{
    wxStyledTextCtrl *control = GetControl();
    wxChar c = event.GetKey();
    int pos = control->GetCurrentPos();
    wxString indent;
    //smart indent
    if (c == wxT('\n'))
    {
        int currentline = control->LineFromPosition(pos);
        indent = GetLineIndentString(currentline - 1);

        if (wxT(':') == GetLastNonWhitespaceChar(pos))
        {
            indent << wxT('\t');
        }
    }

    control->InsertText(pos, indent);
    control->GotoPos(pos + indent.Length());
}
void miEditor::OnEditorDwellStart(wxStyledTextEvent& event)
{
}
void miEditor::OnEditorDwellEnd(wxStyledTextEvent& event)
{
}
void miEditor::OnEditorModified(wxStyledTextEvent& event)
{

}
void miEditor::OnUserListSelection(wxStyledTextEvent& event)
{
}


void miEditor::OnZoom(wxStyledTextEvent& event)
{
}
void miEditor::OnScintillaEvent(wxStyledTextEvent& event)
{
}
void miEditor::OnClose(wxCloseEvent& event)
{
}

int miEditor::FindText (int minPos, int maxPos, const wxString& text, int flags)
{
	wxStyledTextCtrl *control = GetControl();
	return control->FindText(minPos, maxPos, text, flags);
}

int miEditor::GetLength()const
{
	return GetControl()->GetLength();
}

void  miEditor::ShowPos(int pos)
{

}

void  miEditor::GoToPos(int pos)
{
	int lineno = GetControl()->LineFromPosition(pos);
	m_pControl->GotoLine(lineno);
}


void miEditor::SetSelectioin(int start, int end)
{
	return GetControl()->SetSelection(start, end);
}

int miEditor::GetCurrentPos()const
{
		return GetControl()->GetCurrentPos();
}


wxString miEditor::GuessTextToFind()const
{
    //check if these is selection
    wxStyledTextCtrl* stc = GetControl();

    int sstart = stc->GetSelectionStart();
    int send = stc->GetSelectionEnd();

    if (sstart == send)
    {
        //no selection
        int pos = stc->GetCurrentPos();
        wxString wordAtCursor = stc->GetTextRange(stc->WordStartPosition(pos,true), stc->WordEndPosition(pos,true));
        return wordAtCursor;
    }
    else if (stc->LineFromPosition(sstart) != stc->LineFromPosition(send))
    {
        // multiple lines selected
        //
        return wxEmptyString;
    }
    else //single line selected
    {
        //set default find text target
        return stc->GetSelectedText();
    }
}


