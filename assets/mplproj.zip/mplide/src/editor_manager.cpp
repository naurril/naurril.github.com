
#include "editor_manager.h"

EditorManager* EditorManager::manager = 0;


