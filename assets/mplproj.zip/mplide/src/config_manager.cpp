
#include <wx/xml/xml.h>
#include <wx/stdpaths.h>
#include <wx/filefn.h>
#include "config_manager.h"

ConfigManager* ConfigManager::manager = NULL;

ConfigManager::ConfigManager()
{
    fileOK = false; //
    modified = false;
    doc = NULL;
}

ConfigManager::~ConfigManager()
{

    if (doc)
        delete doc;
}


ConfigManager* ConfigManager::get_manager()
{
    if (!manager)
    {
        manager= new ConfigManager();
        manager->load();
    }


    return manager;
}
bool ConfigManager::save()
{
    return doc->Save(config_file_path);
}

bool ConfigManager::load()
{

    wxString folder = wxStandardPaths::Get().GetUserDataDir();
    if (!wxDirExists(folder))
    {
    	#if (_BSD_SOURCE || _XOPEN_SOURCE >= 500)
    	wxMkDir(folder, 0777);
    	#else
        wxMkDir(folder);
        #endif
    }

    config_dir = folder;
    config_file_path = folder + wxT("/defaultconfig.xml");

    if (wxFileExists(config_file_path) && load_from_file(config_file_path))
    {
        return true;
    }
    else
    {
        return load_default();
    }
}

bool ConfigManager::load_default()
{
    doc = new wxXmlDocument;
    #if wxUSE_UNICODE
    #else
    doc->SetEncoding(wxT("utf-8"));
    #endif
    root = new wxXmlNode(wxXML_ELEMENT_NODE ,wxT("mplide"));
    root->AddProperty(wxT("version"), wxT("0.1.00"));
    doc->SetRoot(root);

    return true;
}

bool ConfigManager::load_from_file(const wxString &file)
{

    doc = new wxXmlDocument;
    doc->Load(file, wxT("utf-8"));
    if (doc->IsOk())
    {
        root = doc->GetRoot();
        return true;
    }

    return false;
}

bool ConfigManager::read_bool(const wxString &name, bool default_value)
{
    wxString ret = read(name, wxT("bool"));
    if (ret.IsEmpty())
        return default_value;

    if (ret == wxT("0"))
        return false;
    else
        return true;
}

int ConfigManager::read_value(const wxString &name, int default_value)
{
    wxString ret = read(name, wxT("int"));
    if (ret.IsEmpty())
        return default_value;

    long val;
    if (ret.ToLong(&val, 10))
        return val;
    else
        return default_value;
}

wxString ConfigManager::read_str(const wxString &name, const wxString &default_value)
{
    wxString ret = read(name, wxT("str"));
    if (ret.IsEmpty())
        return default_value;

    return ret;
}


wxArrayString ConfigManager::read_array_str(const wxString &name)
{
    wxArrayString as;
    wxXmlNode *temp;
    wxXmlNode *node = GetNode(name, true, wxXML_CDATA_SECTION_NODE);

    if (!node)
        return as;

    node = FindChild(node, wxT("arraystr"));

    if (!node)
        return as;

    node = node->GetChildren();
    while (node)
    {
        if (node->GetName() == wxT("s"))
        {
            as.Add(read(node, wxT("str")));
            //as.Add(read_cdata_str(node, wxEmptyString));
        }

        node = node->GetNext();
    }

    return as;

}
wxString ConfigManager::read_cdata_str(wxXmlNode *node, const wxString& default_value)
{
    if (node)
    {
        node = FindChild(node, wxT("str"));
        if (node)
        {
            node = node->GetChildren();
            if (node)
                return node->GetContent();
        }
    }

    return wxEmptyString;
}
wxString ConfigManager::read_cdata_str(const wxString &name, const wxString& default_value)
{
    wxXmlNode *node = GetNode(name, false);
    return read_cdata_str(node, default_value);
}

wxString ConfigManager::read(wxXmlNode* node, const wxString &prop_name)
{
   if (node)
    {
        if (node->HasProp(prop_name))
        {
            wxXmlProperty* prop = node->GetProperties();
            while (prop && prop->GetName() != prop_name)
            {
                prop= prop->GetNext();
            }

            if (prop)
                return prop->GetValue();
        }
    }

    return wxEmptyString;
}

wxString ConfigManager::read(const wxString &name, const wxString &prop_name)
{
    wxXmlNode* node = GetNode(name, false);
    return read(node, prop_name);
}



void ConfigManager::write_bool(const wxString &name, bool value)
{
    write(name, wxT("bool"), value?wxT("1"):wxT("0"));
}

void ConfigManager::write_value(const wxString &name, int value)
{
    wxString str;
    str<<value;
    write(name, wxT("int"), str);
}

void ConfigManager::write_str(const wxString &name, const wxString& value)
{

    write(name, wxT("str"), value);
}

void ConfigManager::write_array_str(const wxString &name, const wxArrayString &as)
{
    wxXmlNode *temp;
    wxXmlNode *node = GetNode(name, true, wxXML_CDATA_SECTION_NODE);

    if (!node)
        return;

    temp = FindChild(node, wxT("arraystr"));

    // remove temp to clean the content
    if (temp)
        node->RemoveChild(temp);

    temp = new wxXmlNode(wxXML_ELEMENT_NODE, wxT("arraystr"));
    node->AddChild(temp);


    node = temp;

    // add array
    for(unsigned int i = 0; i < as.GetCount(); ++i)
    {
        temp = new wxXmlNode(wxXML_ELEMENT_NODE, wxT("s"));
        //temp->SetContent(as[i]);
        node->AddChild(temp);
        write(temp, wxT("str"), as[i]);
        //write_cdata_str(temp, as[i]);
    }
}

void ConfigManager::write_cdata_str(wxXmlNode *node, const wxString& value)
{
    wxXmlNode *temp;

    if (!node)
        return;

    temp = FindChild(node, wxT("str"));

    if (temp == NULL)
    {
        temp = new wxXmlNode(wxXML_ELEMENT_NODE, wxT("str"));
        node->AddChild(temp);
    }

    node = temp;
    temp = node->GetChildren();
    if (!temp)
    {
        temp = new wxXmlNode(wxXML_CDATA_SECTION_NODE, wxT(""));
        node->AddChild(temp);
    }

    //value.mb_str(wxConvUTF8)
    temp->SetContent(value);
}

void ConfigManager::write_cdata_str(const wxString &name, const wxString& value)
{
    wxXmlNode *node = GetNode(name, true, wxXML_CDATA_SECTION_NODE);
    write_cdata_str(node, value);
}

void ConfigManager::write(wxXmlNode* node, const wxString &prop_name, const wxString &value)
{
    if (!node)
        return;
    if (node->HasProp(prop_name))
    {
        wxXmlProperty* prop = node->GetProperties();
        while (prop && prop->GetName() != prop_name)
        {
            prop= prop->GetNext();
        }

        if (prop)
        {
            prop->SetValue(value);
            return;
        }
    }

    node->AddProperty(prop_name, value);
}

void ConfigManager::write(const wxString &name, const wxString &prop_name, const wxString &value)
{
    wxXmlNode* node = GetNode(name, true);
    write(node, prop_name, value);
}

wxXmlNode *ConfigManager::FindChild(wxXmlNode *parent, const wxString &name)
{
    if (!parent)
        return NULL;

    wxXmlNode *node;
    node = parent->GetChildren();
    while (node)
    {
        if (name == node->GetName())
            break;
        node = node->GetNext();
    }

    return node;

}

wxXmlNode* ConfigManager::GetNode(const wxString &name, bool create_if_not_exist,wxXmlNodeType node_type)
{
    wxXmlNode *node=NULL;
    wxXmlNode *p_node;
    node = root;

    if (name[0] != '/')
        return NULL;
    int i = 0;
    while(name[i] && node)
    {
        wxString node_name;
        if (name[i] == '/')
        {
            i++;
            continue;
        }


        while (name[i] && name[i] != '/')
        {
            node_name << name[i];
            i++;
        }

        if (node_name.IsEmpty())
            return NULL;

        p_node = node;
        node = node->GetChildren();
        while (node && node->GetName() != node_name)
        {
            node = node->GetNext();
        }

        if ((node == NULL) && (create_if_not_exist))
        {
            wxXmlNode *temp = new wxXmlNode(wxXML_ELEMENT_NODE, node_name);
            p_node->AddChild(temp);
            node = temp;
        }
    }

    return node;
}
