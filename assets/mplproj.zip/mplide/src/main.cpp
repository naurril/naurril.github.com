
/*
07Sep2009 lie, save n restore "clear previous results" option
*/


#include <wx/wx.h>
#include <wx/grid.h>
#include <wx/treectrl.h>
#include <wx/spinctrl.h>
#include <wx/artprov.h>
#include <wx/clipbrd.h>
#include <wx/image.h>
#include <wx/colordlg.h>
#include <wx/aui/aui.h>
#include <wx/aui/auibook.h>
#include <wx/filedlg.h>
#include <wx/utils.h>
#include <wx/arrstr.h>
#include <wx/txtstrm.h>
#include <wx/filename.h>
#include <wx/stc/stc.h>
#include <wx/docview.h>  //file history
#include <wx/textfile.h>
#include <wx/sstream.h>
#include <wx/stc/stc.h>
#include "editor.h"
#include "main.h"
#include "editor_settings_dlg.h"
#include "environment_settings_dlg.h"
#include "output_settings_dlg.h"
#include "config_manager.h"
#include "run_dlg.h"
#include "pipe_proc.h"
#include "find_dlg.h"

#include <iostream>

class MyApp : public wxApp
{
public:
    bool OnInit();
};

DECLARE_APP(MyApp);
IMPLEMENT_APP(MyApp);

bool MyApp::OnInit()
{
    wxFrame* frame = new MainFrame(NULL,
                                 wxID_ANY,
                                 wxT("mplide"),
                                 wxDefaultPosition,
                                 wxSize(800, 600));
    SetTopWindow(frame);
    frame->Show();

    return true;
}



BEGIN_EVENT_TABLE(MainFrame, wxFrame)
    EVT_MENU(wxID_NEW,   MainFrame::OnFileNew)
    EVT_MENU(wxID_OPEN,  MainFrame::OnFileOpen)
    EVT_MENU(wxID_SAVE,  MainFrame::OnFileSave)
    EVT_MENU(wxID_SAVEAS,  MainFrame::OnFileSaveAs)
    EVT_MENU(wxID_CLOSE,  MainFrame::OnFileClose)
    EVT_MENU_RANGE(wxID_FILE1, wxID_FILE9, MainFrame::OnFileReopen)
    EVT_MENU(ID_View_MsgWin, MainFrame::OnViewMsgWin)
    EVT_MENU(ID_View_Toolbar_Main, MainFrame::OnViewToolbarMain)
    EVT_MENU(ID_View_Toolbar_Build, MainFrame::OnViewToolbarBuild)
    EVT_MENU(ID_Search_Find,  MainFrame::OnSearchFind)
    EVT_MENU(ID_Search_FindNext,  MainFrame::OnSearchFindNext)
    EVT_MENU(ID_Search_FindPrev,  MainFrame::OnSearchFindPrev)
    EVT_MENU(ID_Build_CheckSyntax, MainFrame::OnBuildCheckSyntax)
    EVT_MENU(ID_Build_Run,         MainFrame::OnBuildRun)
    EVT_MENU(ID_Settings_Editor, MainFrame::OnSettingsEditor)
    EVT_MENU(ID_Settings_Environment, MainFrame::OnSettingsEnvironment)
    EVT_MENU(ID_Settings_Output, MainFrame::OnSettingsOutput)
    //EVT_MENU(wxID_CLOSEALL,  MainFrame::OnFileCloseAll)

    EVT_MENU(wxID_EXIT,  MainFrame::OnExit)
    EVT_CLOSE(MainFrame::OnClose)
    EVT_SIZE(MainFrame::OnSize)
    EVT_IDLE(MainFrame::OnIdle)
    EVT_UPDATE_UI_RANGE(ID_View_Toolbar_Main, ID_View_MsgWin, MainFrame::OnUpdateUI)

    //EVT_TIMER(ID_Timer_BuildRunning, MainFrame::OnTimerRunning)
END_EVENT_TABLE()



class wxMyFileDropTarget : public wxFileDropTarget
{
public:
    wxMyFileDropTarget(MainFrame *frame):m_frame(frame){}
    virtual bool OnDropFiles(wxCoord x, wxCoord y, const wxArrayString& filenames)
    {
        if(!m_frame) return false;
        return m_frame->OnDropFiles(x,y,filenames);
    }
private:
    MainFrame* m_frame;
};


MainFrame::MainFrame(wxWindow* parent,
                 wxWindowID id,
                 const wxString& title,
                 const wxPoint& pos,
                 const wxSize& size,
                 long style)
        : wxFrame(parent, id, title, pos, size, style),
        m_mgr(this)//, m_BuildRunningTimer(this, ID_Timer_BuildRunning)
{
    // tell wxFrameManager to manage this frame
    //m_mgr.SetFrame(this);

    // set frame icon
    #ifdef __WXMSW__
    SetIcon(wxIcon(wxT("mondrian"), wxBITMAP_TYPE_ICO_RESOURCE, 16, 16));
    #endif

    m_pRunDlg = 0;
    m_RunningStatus = 0;
    m_pProc = 0;
    m_ProcID = 0;
    m_pFilesHistory = NULL;

    // New: Allow drag and drop of files into the editor
    SetDropTarget(new wxMyFileDropTarget(this));


    CreateStatusBar();
    GetStatusBar()->SetStatusText(_("Ready"));

    // min size for the frame itself isn't completely done.
    // see the end up wxFrameManager::Update() for the test
    // code. For now, just hard code a frame minimum size
    //SetMinSize(wxSize(400,300));

    InstallMenus();
    InstallToolbars();
    InstallAccelerator();
    CreatePanes();

    //load layout
    int width = ConfigManager::get_manager()->read_value(wxT("/layout/size/width"), wxDefaultSize.GetWidth());
    int height = ConfigManager::get_manager()->read_value(wxT("/layout/size/height"), wxDefaultSize.GetWidth());
    int x = ConfigManager::get_manager()->read_value(wxT("/layout/position/x"), wxDefaultPosition.x);
    int y = ConfigManager::get_manager()->read_value(wxT("/layout/position/y"), wxDefaultPosition.y);

    SetPosition(wxPoint(x, y));
    SetSize(width, height);


    // make some default perspectives
    wxString perspective_all = ConfigManager::get_manager()->read_str(wxT("/layout/perspective"));

    if (perspective_all.IsEmpty())
    {
        m_mgr.GetPane(wxT("maintb")).Show();  //tool bar
        m_mgr.GetPane(wxT("buildtb")).Show();
        m_mgr.GetPane(wxT("management_pane")).Show().Left().Layer(0).Row(0).Position(0);
        m_mgr.GetPane(wxT("output_pane")).Show().Bottom().Layer(0).Row(0).Position(0);
        m_mgr.GetPane(wxT("editor_pane")).Show();
    }
    else
    {
        m_mgr.LoadPerspective(perspective_all);
    }



    m_mgr.Update();
}

void MainFrame::CreatePanes()
{
    //create
    /*
    m_pBuildOutput = new wxTextCtrl(this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize,
                                wxTE_READONLY | wxTE_MULTILINE | wxHSCROLL);
    m_pBuildError = new wxTextCtrl(this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize,
                                wxTE_READONLY | wxTE_MULTILINE | wxHSCROLL);
    */
    m_pBuildOutput = new wxStyledTextCtrl(this,wxID_ANY,
                          wxPoint(0,0), wxSize(150,90),
                          wxNO_BORDER | wxSTC_STYLE_DEFAULT,
                          wxT("helo"));
    //m_pBuildOutput->SetReadOnly(true);

    m_pBuildError = new wxStyledTextCtrl(this,wxID_ANY,
                          wxPoint(0,0), wxSize(150,90),
                          wxNO_BORDER | wxSTC_STYLE_DEFAULT,
                          wxT("helo"));
    SetBuildWinStyle();

    m_pBuildError->Connect(wxEVT_LEFT_DCLICK, (wxObjectEventFunction)(wxEventFunction)&MainFrame::OnErrWinLeftDclick,NULL, this);


    m_pNbOutput = new wxAuiNotebook(this, wxID_ANY, wxDefaultPosition, wxSize(400,100),
                                    wxNO_BORDER | wxNO_FULL_REPAINT_ON_RESIZE | wxCLIP_CHILDREN);

    m_pNbOutput->AddPage(m_pBuildOutput, wxT("Info"));
    m_pNbOutput->AddPage(m_pBuildError, wxT("Error"));

    m_mgr.AddPane(m_pNbOutput, wxAuiPaneInfo().Name(wxT("Messages")).Caption(wxT("Messages")).Right().Show().CloseButton(true));


    // create center pane - editor
    m_pNbEditor = new wxAuiNotebook(this, wxID_ANY, wxDefaultPosition, wxDefaultSize,
				wxNO_BORDER|wxNO_FULL_REPAINT_ON_RESIZE | wxCLIP_CHILDREN  | wxAUI_NB_CLOSE_BUTTON | wxAUI_NB_WINDOWLIST_BUTTON | wxAUI_NB_CLOSE_ON_ACTIVE_TAB | wxAUI_NB_SCROLL_BUTTONS);
    m_mgr.AddPane(m_pNbEditor, wxAuiPaneInfo().Name(wxT("editor_pane")).CenterPane());


	m_pNbEditor->Connect(wxID_ANY, wxEVT_COMMAND_AUINOTEBOOK_PAGE_CLOSE,
		(wxObjectEventFunction) (wxEventFunction) (wxAuiNotebookEventFunction)&MainFrame::OnEditorPageClose,
		NULL,
		this);
}


void MainFrame::InstallMenus()
{
    // create menu
    m_main_menu_bar = new wxMenuBar;

    wxMenu* file_menu = new wxMenu;
    file_menu->Append(wxID_NEW, _("New"));
    file_menu->Append(wxID_OPEN, _("&Open..."));
    wxMenu* recent_file_menu = new wxMenu;
    recent_file_menu->Append(ID_File_Open_Recent_File_Clear_History, _("Clear history"));
    file_menu->AppendSubMenu(recent_file_menu, _("Recent files"));

    file_menu->AppendSeparator();
    file_menu->Append(wxID_SAVE, _("&Save\tCtrl+S"));
    file_menu->Append(wxID_SAVEAS, _("S&ave as.."));

    file_menu->AppendSeparator();
    file_menu->Append(wxID_CLOSE, _("&Close"));
    file_menu->Append(wxID_EXIT, _("E&xit"));

    wxMenu* edit_menu = new wxMenu;
    edit_menu->Append(wxID_UNDO, _("Undo"));
    edit_menu->Append(wxID_REDO, _("Redo"));
    edit_menu->Append(wxID_CUT, _("Cut"));
    edit_menu->Append(wxID_COPY, _("Copy"));
    edit_menu->Append(wxID_PASTE, _("Paste"));
    edit_menu->Append(wxID_SELECTALL, _("Select all"));

    wxMenu* view_menu = new wxMenu;
    wxMenu* view_toolbars_menu = new wxMenu;
    view_toolbars_menu->Append(ID_View_Toolbar_Main, _("Main"), _("show/hide main tool bar"), wxITEM_CHECK);
    view_toolbars_menu->Append(ID_View_Toolbar_Build, _("Build"), _("show/hide build tool bar"), wxITEM_CHECK);
    view_menu->AppendSubMenu(view_toolbars_menu, _("Toolbars"));
    view_menu->Append(ID_View_MsgWin, _("&Message window"), _("show/hide message window"), wxITEM_CHECK);

    wxMenu* search_menu = new wxMenu;
    search_menu->Append(ID_Search_Find, _("&Find\tCtrl+F"));
    search_menu->Append(ID_Search_FindNext, _("&Find next\tF3"));
    search_menu->Append(ID_Search_FindPrev, _("&Find Previous\tShift+F3"));


    wxMenu* build_menu = new wxMenu;
    build_menu->Append(ID_Build_CheckSyntax, _("&Check syntex\tF9"));
    build_menu->Append(ID_Build_Run, _("&Run...\tF5"));

    wxMenu* settings_menu = new wxMenu;
    settings_menu->Append(ID_Settings_Environment, _("&Environment..."));
    settings_menu->Append(ID_Settings_Editor, _("E&ditor..."));
    settings_menu->Append(ID_Settings_Output, _("&Output..."));

    wxMenu* help_menu = new wxMenu;
    help_menu->Append(ID_About, _("&About..."));

    m_main_menu_bar->Append(file_menu, _("&File"));
    m_main_menu_bar->Append(edit_menu, _("&Edit"));
    m_main_menu_bar->Append(view_menu, _("&View"));
    m_main_menu_bar->Append(search_menu, _("&Search"));
    m_main_menu_bar->Append(build_menu, _("&Build"));
    m_main_menu_bar->Append(settings_menu, _("&Settings"));
    m_main_menu_bar->Append(help_menu, _("&Help"));

    SetMenuBar(m_main_menu_bar);
    InitializeRecentFilesHistory();
}

// the following two funcs are copied from codeblocks
void MainFrame::InitializeRecentFilesHistory()
{
    //TerminateRecentFilesHistory();

    wxMenuBar* mbar = GetMenuBar();
    if (!mbar)
        return;
    int pos = mbar->FindMenu(_("&File"));
    if (pos != wxNOT_FOUND)
    {
        m_pFilesHistory = new wxFileHistory(9, wxID_FILE1);

        wxMenu* menu = mbar->GetMenu(pos);
        if (!menu)
            return;
        wxMenu* recentFiles = 0;
        wxMenuItem* clear = menu->FindItem(ID_File_Open_Recent_File_Clear_History, &recentFiles);
        if (recentFiles)
        {
            recentFiles->Remove(clear);

            wxArrayString files = ConfigManager::get_manager()->read_array_str(wxT("/editor/recentfiles"));
            for (int i = (int)files.GetCount() - 1; i >= 0; --i)
            {
                if(wxFileExists(files[i]))
                    m_pFilesHistory->AddFileToHistory(files[i]);
            }
            m_pFilesHistory->UseMenu(recentFiles);
            m_pFilesHistory->AddFilesToMenu(recentFiles);
            if (recentFiles->GetMenuItemCount())
                recentFiles->AppendSeparator();
            recentFiles->Append(clear);
        }
    }
}

void MainFrame::AddToRecentFilesHistory(const wxString& FileName)
{
    wxString filename = FileName;
#ifdef __WXMSW__
    // for windows, look for case-insensitive matches
    // if found, don't add it
    wxString low = filename.Lower();
    for (size_t i = 0; i < m_pFilesHistory->GetCount(); ++i)
    {
        if (low == m_pFilesHistory->GetHistoryFile(i).Lower())
        {    // it exists, set filename to the existing name, so it can become
            // the most recent one
            filename = m_pFilesHistory->GetHistoryFile(i);
            break;
        }
    }
#endif

    m_pFilesHistory->AddFileToHistory(filename);

    // because we append "clear history" menu to the end of the list,
    // each time we must add a history item we have to:
    // a) remove "Clear history"
    // b) clear the menu
    // c) fill it with the history items
    // and d) append "Clear history"...
    wxMenuBar* mbar = GetMenuBar();
    if (!mbar)
        return;
    int pos = mbar->FindMenu(_("&File"));
    if (pos == wxNOT_FOUND)
        return;
    wxMenu* menu = mbar->GetMenu(pos);
    if (!menu)
        return;
    wxMenu* recentFiles = 0;
    wxMenuItem* clear = menu->FindItem(ID_File_Open_Recent_File_Clear_History, &recentFiles);
    if (clear && recentFiles)
    {
        // a)
        recentFiles->Remove(clear);
        // b)
        m_pFilesHistory->RemoveMenu(recentFiles);
        while (recentFiles->GetMenuItemCount())
            recentFiles->Delete(recentFiles->GetMenuItems()[0]);
        // c)
        m_pFilesHistory->UseMenu(recentFiles);
        m_pFilesHistory->AddFilesToMenu(recentFiles);
        // d)
        if (recentFiles->GetMenuItemCount())
            recentFiles->AppendSeparator();
        recentFiles->Append(clear);
    }

}

void MainFrame::InstallToolbars()
{
    // create some toolbars
    wxToolBar* maintb = new wxToolBar(this, -1, wxDefaultPosition, wxSize(16, 16),
                                   wxTB_FLAT | wxTB_NODIVIDER);
    maintb->SetToolBitmapSize(wxSize(16,16));
    maintb->AddTool(wxID_NEW, wxT("New"), wxArtProvider::GetBitmap(wxART_NEW));
    maintb->SetToolShortHelp(wxID_NEW, wxT("New file"));
    maintb->SetToolLongHelp(wxID_NEW, wxT("Create a new source file"));

    maintb->AddTool(wxID_OPEN, wxT("Open"), wxArtProvider::GetBitmap(wxART_FILE_OPEN));
    maintb->SetToolShortHelp(wxID_OPEN, wxT("Open"));
    maintb->SetToolLongHelp(wxID_OPEN, wxT("Open an existing file"));

    maintb->AddTool(wxID_SAVE, wxT("Save"), wxArtProvider::GetBitmap(wxART_FILE_SAVE));
    maintb->SetToolShortHelp(wxID_SAVE, wxT("Save"));
    maintb->SetToolLongHelp(wxID_SAVE, wxT("Save current file"));

    maintb->Realize();

    // add the toolbars to the manager
    m_mgr.AddPane(maintb, wxAuiPaneInfo().
                  Name(wxT("maintb")).Caption(wxT("Main Toolbar")).
                  ToolbarPane().Top().
                  LeftDockable(false).RightDockable(false));


    wxToolBar* buildtb = new wxToolBar(this, -1, wxDefaultPosition, wxSize(16, 16),
                                   wxTB_FLAT | wxTB_NODIVIDER);
    buildtb->SetToolBitmapSize(wxSize(16,16));
    buildtb->AddTool(ID_Build_CheckSyntax, wxT("Check"), wxArtProvider::GetBitmap(wxART_REPORT_VIEW));
    buildtb->SetToolShortHelp(ID_Build_CheckSyntax, wxT("Syntax check"));
    buildtb->SetToolLongHelp(ID_Build_CheckSyntax,  wxT("Check syntax of current file"));

    buildtb->AddTool(ID_Build_Run,         wxT("Run"),   wxArtProvider::GetBitmap(wxART_GO_DOWN));
    buildtb->SetToolShortHelp(ID_Build_Run, wxT("Run"));
    buildtb->SetToolLongHelp(ID_Build_Run, wxT("Parse messages"));

    buildtb->Realize();

    m_mgr.AddPane(buildtb, wxAuiPaneInfo().
                  Name(wxT("buildtb")).Caption(wxT("Build Toolbar")).
                  ToolbarPane().Top().
                  LeftDockable(false).RightDockable(false));

}

void MainFrame::InstallAccelerator()
{
    //accelerators
    //wxAcceleratorEntry entries[4];
    //entries[0].Set(wxACCEL_NORMAL, WXK_F5, ID_Run);
    //entries[1].Set(wxACCEL_NORMAL, WXK_F9, ID_CheckSyntax);

    //wxAcceleratorTable accel(2, entries);
    //SetAcceleratorTable(accel);

}

void MainFrame::OnFileNew(wxCommandEvent& event)
{
    static int i = 1;
    wxString file_name = wxT("untitled");
    file_name << i++;

    m_pNbEditor->AddPage(new miEditor(this,file_name), file_name, true);
}

miEditor* MainFrame::OpenFile(const wxString &file_path)
{
    wxFileName file(file_path);

    wxString filename = file.GetFullName();

    // check if its already opened
    int page_count = m_pNbEditor->GetPageCount();
    for (int i = 0; i< page_count; i++)
    {
        miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(i));

        if (ed->GetFilePath() == file_path)
        {
            //found!
            m_pNbEditor->SetSelection(i);
            return ed;
        }
    }

    miEditor *ed = new miEditor(this, filename);
    ed->LoadFile(file_path);
    m_pNbEditor->AddPage(ed, filename, true);
    AddToRecentFilesHistory(file_path);

    return ed;
}

void MainFrame::OnFileOpen(wxCommandEvent& event)
{
    wxString   cur_path = wxEmptyString;

    // get current file path
    if (m_pNbEditor->GetPageCount() != 0)
	{
        int idx = m_pNbEditor->GetSelection();

        miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

        wxFileName filename = ed->GetFilePath();
        cur_path = filename.GetPath();
	}

    wxFileDialog* dlg = new wxFileDialog(this, wxFileSelectorPromptStr, cur_path);

    if (dlg->ShowModal() == wxID_OK)
    {
        OpenFile(dlg->GetPath());
    }
    else
    {
    }

    dlg->Destroy();
}

void MainFrame::OnFileReopen(wxCommandEvent& event)
{
    size_t id = event.GetId() - wxID_FILE1;
    wxString fname = m_pFilesHistory->GetHistoryFile(id);
    if (!OpenFile(fname))
    {
        // ask to remove history?
    }
}

bool MainFrame::DoFileSaveAs()
{
    if (m_pNbEditor->GetPageCount() == 0)
		return true;


	int idx = m_pNbEditor->GetSelection();
	miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

	wxFileDialog* dlg = new wxFileDialog(this, wxT("Save as"), wxT(""), wxT(""), wxT(""), wxFD_SAVE);

    if (dlg->ShowModal() == wxID_OK)
    {
        wxString pathname = dlg->GetPath();
        wxString filename = dlg->GetFilename();

        ed->SaveFile(pathname);

        AddToRecentFilesHistory(pathname);

        m_pNbEditor->SetPageText(idx, filename); //update notebook title
        return true;
    }
    else
    {
        return false;
    }

    dlg->Destroy();
}

bool MainFrame::DoFileSave()
{
    if (m_pNbEditor->GetPageCount() == 0)
		return true;

	int idx = m_pNbEditor->GetSelection();

	miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

	if (ed->HasFilePath())
		return ed->SaveFile();
	else
		return DoFileSaveAs();
}

void MainFrame::OnFileSave(wxCommandEvent& event)
{
	DoFileSave();
}

void MainFrame::OnFileSaveAs(wxCommandEvent& event)
{
	DoFileSaveAs();
}


void MainFrame::OnFileClose(wxCommandEvent& event)
{
	if (m_pNbEditor->GetPageCount() == 0)
		return;

	int idx = m_pNbEditor->GetSelection();

	miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

    if (ed->GetModified() == false)
    {
        m_pNbEditor->DeletePage(idx);
        return;
    }

    wxString msg = wxT("\"");
    msg << m_pNbEditor->GetPageText(idx);
    msg << wxT("\" not saved, save it before close?");
    wxMessageDialog *dlg = new wxMessageDialog(this, msg, wxT("save file"), wxYES|wxNO|wxCANCEL);

    int ret = dlg->ShowModal();
    if (wxID_YES == ret)
    {
        if (true == DoFileSave())
        {
            m_pNbEditor->DeletePage(idx);
            return;
        }
        else
        {
        }
    }
    else if (wxID_NO == ret)
    {
        m_pNbEditor->DeletePage(idx);
        return;
    }
    else if (wxID_CANCEL == ret)
    {
        return;
    }

    dlg->Destroy();
}

void MainFrame::OnFileCloseAll(wxCommandEvent& event)
{

}

void MainFrame::SaveFileHistory()
{
    wxArrayString as;
    for (int i = 0; i < m_pFilesHistory->GetCount(); i++)
    {
        as.Add(m_pFilesHistory->GetHistoryFile(i));
    }

    ConfigManager::get_manager()->write_array_str(wxT("/editor/recentfiles"), as);
}

void MainFrame::SaveAppCfg()
{
    SaveFileHistory();
    ConfigManager::get_manager()->write_value(wxT("/layout/size/width"), GetSize().GetWidth());
    ConfigManager::get_manager()->write_value(wxT("/layout/size/height"), GetSize().GetHeight());
    ConfigManager::get_manager()->write_value(wxT("/layout/position/x"), GetPosition().x);
    ConfigManager::get_manager()->write_value(wxT("/layout/position/y"), GetPosition().y);
    ConfigManager::get_manager()->write_str(wxT("/layout/perspective"), m_mgr.SavePerspective());

    ConfigManager::get_manager()->save();
}

void MainFrame::OnExit(wxCommandEvent& event)
{
	while (m_pNbEditor->GetPageCount() != 0)
	{
		if (PreProcEditorPageClose())
		{
			m_pNbEditor->DeletePage(m_pNbEditor->GetSelection());
		}
		else
		{
			return;
		}
	}


    SaveAppCfg();

    Close(true);
}



void MainFrame::OnClose(wxCloseEvent& event)
{
	while (m_pNbEditor->GetPageCount() != 0)
	{
		if (PreProcEditorPageClose())
		{
			m_pNbEditor->DeletePage(m_pNbEditor->GetSelection());
		}
		else
		{
		    if (event.CanVeto())
                return;
            else
                Destroy();
		}
	}

	SaveAppCfg();

	Destroy();  // you may also do:  event.Skip();
				// since the default event handler does call Destroy(), too
}


void MainFrame::OnViewMsgWin(wxCommandEvent& event)
{
    wxAuiPaneInfo &pane = m_mgr.GetPane(wxT("Messages"));
    pane.Show(!pane.IsShown());
    m_mgr.Update();
}

void MainFrame::OnViewToolbarMain(wxCommandEvent& event)
{
    wxAuiPaneInfo &pane = m_mgr.GetPane(wxT("maintb"));
    pane.Show(!pane.IsShown());
    m_mgr.Update();
}

void MainFrame::OnViewToolbarBuild(wxCommandEvent& event)
{
    wxAuiPaneInfo &pane = m_mgr.GetPane(wxT("buildtb"));
    pane.Show(!pane.IsShown());
    m_mgr.Update();
}

void MainFrame::OnSearchFind(wxCommandEvent& event)
{
	//get text control
	if (m_pNbEditor->GetPageCount() == 0)
	{
	    return;
	}

    int idx = m_pNbEditor->GetSelection();

    miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

    if (!PrepareFindReplaceInput(ed->GuessTextToFind()))
        return;

    int ret = ed->FindText(ed->GetCurrentPos(),
	                       ed->GetLength(),
                           m_tFindReplaceData.GetTtf(),
                           m_tFindReplaceData.GetFlags());

	if (ret != -1)
	{
		ed->GoToPos(ret);
		ed->SetSelectioin(ret, ret + m_tFindReplaceData.GetTtf().Length());
	}
}

void MainFrame::OnSearchFindNext(wxCommandEvent& event)
{
    //get text control
	if (m_pNbEditor->GetPageCount() == 0)
	{
	    return;
	}

    int idx = m_pNbEditor->GetSelection();

    miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

    if (m_tFindReplaceData.GetTtf().empty())
    {
        if (!PrepareFindReplaceInput(ed->GuessTextToFind()))
        {
            return;
        }
    }

    int ret = ed->FindText(ed->GetCurrentPos(),
	                       ed->GetLength(),
                           m_tFindReplaceData.GetTtf(),
                           m_tFindReplaceData.GetFlags());

	if (ret != -1)
	{
		ed->GoToPos(ret);
		ed->SetSelectioin(ret, ret + m_tFindReplaceData.GetTtf().Length());
	}


}


void MainFrame::OnSearchFindPrev(wxCommandEvent& event)
{
    //get text control
	if (m_pNbEditor->GetPageCount() == 0)
	{
	    return;
	}

    int idx = m_pNbEditor->GetSelection();

    miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

    if (m_tFindReplaceData.GetTtf().empty())
    {
        if (!PrepareFindReplaceInput(ed->GuessTextToFind()))
        {
            return;
        }
    }

    int ret = ed->FindText(ed->GetCurrentPos(),
	                       0,
                           m_tFindReplaceData.GetTtf(),
                           m_tFindReplaceData.GetFlags());

	if (ret != -1)
	{
		ed->GoToPos(ret);
		ed->SetSelectioin(ret + m_tFindReplaceData.GetTtf().Length(), ret);
	}


}

bool MainFrame::PrepareFindReplaceInput(const wxString &default_ttf)
{
    miFindDlg* dlg = new miFindDlg(this, m_tFindReplaceData, default_ttf);

    if (wxID_OK != dlg->ShowModal())
        return false;

    wxString ttf = dlg->GetTextToSearch();

    if (ttf.empty()) //don't search empty string
        return false;

    m_tFindReplaceData.AddChoice(ttf); //save find replace data
    m_tFindReplaceData.SetTtf(ttf);


    int flags = 0;
    flags |= dlg->GetMatchCase()?wxSTC_FIND_MATCHCASE:0;
    flags |= dlg->GetWholeWord()?wxSTC_FIND_WHOLEWORD:0;
    flags |= dlg->GetStartWord()?wxSTC_FIND_WORDSTART:0;
    flags |= dlg->GetRegExpr()?wxSTC_FIND_REGEXP:0;


    m_tFindReplaceData.SetFlags(flags); //save find replace data

    dlg->Destroy();
    return true;
}

MainFrame::~MainFrame()
{
    m_mgr.UnInit();
}

wxAuiDockArt* MainFrame::GetDockArt()
{
    return m_mgr.GetArtProvider();
}

void MainFrame::DoUpdate()
{
    m_mgr.Update();
}


void MainFrame::OnSize(wxSizeEvent& event)
{
    event.Skip();
}


void MainFrame::OnUpdateUI(wxUpdateUIEvent& event)
{
    switch (event.GetId())
    {
    case ID_View_Toolbar_Main:
        m_main_menu_bar->Check(ID_View_Toolbar_Main, m_mgr.GetPane(wxT("maintb")).IsShown());
        m_main_menu_bar->Check(ID_View_Toolbar_Build, m_mgr.GetPane(wxT("buildtb")).IsShown());
        break;
    case ID_View_MsgWin:
        m_main_menu_bar->Check(ID_View_MsgWin, m_mgr.GetPane(wxT("Messages")).IsShown());
        break;
    default:
        break;
    }
}


bool MainFrame::PreProcEditorPageClose()
{
	if (m_pNbEditor->GetPageCount() == 0)
    {
        return true;
    }

	int idx = m_pNbEditor->GetSelection();

	miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

    if (ed->GetModified() == false)
    {
        return true;
    }

    wxString msg = wxT("\"");
    msg << m_pNbEditor->GetPageText(idx);
    msg << wxT("\" not saved, save it before close?");
    wxMessageDialog *dlg = new wxMessageDialog(this, msg, wxT("save file"), wxYES|wxNO|wxCANCEL);

    int ret = dlg->ShowModal();
    dlg->Destroy();
    if (wxID_YES == ret)
    {
        return DoFileSave();
    }
    else if (wxID_NO == ret)
    {
        return true;
    }
    else// if (wxID_CANCEL == ret)
    {
        return false;
    }
}


void MainFrame::OnEditorPageClose(wxAuiNotebookEvent &event)
{
    if (!PreProcEditorPageClose())
    	event.Veto();
}


void MainFrame::OnSettingsEditor(wxCommandEvent& event)
{
    miEditorSettingsDlg *dlg = new miEditorSettingsDlg(this);
    if (wxID_OK == dlg->ShowModal())
    {
        int page_count = m_pNbEditor->GetPageCount();
        for (int i = 0; i< page_count; i++)
        {
        	miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(i));

        	ed->UpdateUI();
        }
    }

    dlg->Destroy();
}


void MainFrame::OnSettingsEnvironment(wxCommandEvent& event)
{
    miEnvironmentSettingsDlg *dlg = new miEnvironmentSettingsDlg(this);
    dlg->ShowModal();
    dlg->Destroy();
}

void MainFrame::SetBuildWinStyle()
{
    #if wxUSE_UNICODE
    m_OutputFont.SetNativeFontInfo(ConfigManager::get_manager()->read_str(wxT("/output/font")));
    #else
    m_OutputFont.SetNativeFontInfo(ConfigManager::get_manager()->read_str(wxT("/output/font")).To8BitData());
    #endif

    for (int i = 0; i < 36; i++)
    {
        m_pBuildOutput->StyleSetFaceName(i, m_OutputFont.GetFaceName());
        m_pBuildOutput->StyleSetSize(i, m_OutputFont.GetPointSize());
    }


    for (int i = 0; i < 36; i++)
    {
        m_pBuildError->StyleSetFaceName(i, m_OutputFont.GetFaceName());
        m_pBuildError->StyleSetSize(i, m_OutputFont.GetPointSize());
    }
}

void MainFrame::OnSettingsOutput(wxCommandEvent& event)
{
    miOutputSettingsDlg *dlg = new miOutputSettingsDlg(this);
    if (wxID_OK == dlg->ShowModal())
    {
        SetBuildWinStyle();
    }

    dlg->Destroy();
}

 void MainFrame::OnBuildCheckSyntax(wxCommandEvent& event)
 {

    if (m_pNbEditor->GetPageCount() == 0)
    {
        return ;
    }

	int idx = m_pNbEditor->GetSelection();

	miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(idx));

    if (ed->GetModified())
    {
        DoFileSave();
    }

    wxString file_path = ed->GetFilePath();

    wxString cmd;
    cmd <<ConfigManager::get_manager()->read_str(wxT("/environment/general/mpl_exe_path"), wxT("mpl"));
    cmd << wxT(" -c ");
    wxString mpl_lib_path = ConfigManager::get_manager()->read_str(wxT("/environment/general/mpl_lib_path"));
    if (!mpl_lib_path.IsEmpty())
        cmd <<wxT(" -i ")<<mpl_lib_path<< wxT(" ");

    cmd << file_path;

    wxArrayString output;
    wxArrayString err;

    m_pBuildOutput->Clear();
    m_pBuildError->Clear();
    m_pBuildOutput->AppendText(cmd);
    m_pBuildOutput->AppendText(wxT("\n"));

    long ret = wxExecute(cmd, output, err, wxEXEC_SYNC);



    for (int i = 0; i < err.GetCount(); i++)
    {
        m_pBuildError->AppendText(err[i]);
        m_pBuildError->AppendText(wxT("\n"));
    }

    for (int i = 0; i < output.GetCount(); i++)
    {
        m_pBuildOutput->AppendText(output[i]);
        m_pBuildOutput->AppendText(wxT("\n"));
    }

    if (ret == 0)
    {
        m_pNbOutput->SetSelection(0);
    }
    else
    {
        m_pNbOutput->SetSelection(1);
    }

 }

void MainFrame::OnBuildRun(wxCommandEvent& event)
{
    int old_ed_sel= -1;

    //create dialog
    if (!m_pRunDlg)
        m_pRunDlg = new miRunDlg(this);


    //get current page, save it, and set it as the default mpl src file
    if (m_pNbEditor->GetPageCount() != 0)
    {

        old_ed_sel = m_pNbEditor->GetSelection();

        miEditor* ed = static_cast<miEditor*>(m_pNbEditor->GetPage(old_ed_sel));

        if (ed->GetModified())
        {
            DoFileSave();
        }

        wxString file_path = ed->GetFilePath();

        m_pRunDlg->set_mpl_file_path(file_path);
    }

    int dlg_ret = m_pRunDlg->ShowModal();

    // restore focus, dialog will restore the focus to where it was first created
    // we can solve this problem by creating the dlg each time it's needed,
    // but then we will have to remember what was set in the dialog and restore them
    // at the dialog creation
    if (m_pNbEditor->GetPageCount() != 0)
    {
        if (-1 != old_ed_sel)
        {
            m_pNbEditor->SetSelection(old_ed_sel);
        }
    }

    if (wxID_OK != dlg_ret)
    {
        return ;
    }

    //build command line string
    wxString  cmd;
    cmd <<ConfigManager::get_manager()->read_str(wxT("/environment/general/mpl_exe_path"), wxT("mpl"));
    wxString mpl_lib_path = ConfigManager::get_manager()->read_str(wxT("/environment/general/mpl_lib_path"));
    if (!mpl_lib_path.IsEmpty())
        cmd <<wxT(" -i ")<<mpl_lib_path;

    cmd <<wxT(" ")<< m_pRunDlg->get_mpl_file_path();

    switch(m_pRunDlg->get_input_option())
    {
    case 0: //input string
        break;
    case 1: //input file
        cmd <<wxT(" -m ")<<m_pRunDlg->get_raw_stream_file_path();
        break;
    case 2: // no input
        cmd << wxT(" -n");
        break;
    }

    wxString options = ConfigManager::get_manager()->read_str(wxT("/environment/run/options"));
    if (!options.IsEmpty())
        cmd << wxT(" ") << options;

    //build options
    if (m_pRunDlg->get_show_msg_only())
        cmd << wxT(" --print-msg-only");
    if (m_pRunDlg->get_beautify_message())
        cmd << wxT(" -u");
    if (m_pRunDlg->get_show_hex_format())
        cmd << wxT(" -x");
    if (m_pRunDlg->get_input_hex_no_0x())
        cmd << wxT(" --no-0x");

    wxString extra_options = m_pRunDlg->get_extra_options();
    if (!extra_options.IsEmpty())
        cmd << wxT(" ") << extra_options;

    if (m_pRunDlg->get_clear_prev_result())
    {
        m_pBuildOutput->ClearAll();
        m_pBuildError->ClearAll();
    }
    else
    {
        m_pBuildError->AppendText(wxT("-------- start new session --------\n"));
        m_pBuildOutput->AppendText(wxT("-------- start new session --------\n"));
    }

    //if (m_pRunDlg->get_input_option() == 0)
    //    cmd << wxT(" -m \"") << ConfigManager::get_manager()->get_cfg_dir() + wxT("/raw_stream_content.txt") <<"\"";

    m_pBuildOutput->AppendText(cmd);
    m_pBuildOutput->AppendText(wxT("\n"));


    if (!m_pProc)
        m_pProc = new miPipeProc(this);

    m_pProc->Redirect();

    std::cout<<"run "<<cmd<<std::endl;
    m_ProcID = wxExecute(cmd, wxEXEC_ASYNC, m_pProc);

    //m_BuildRunningTimer.Start(100);

    if (m_pRunDlg->get_input_option() == 0)  //input string
    {
        wxOutputStream* output = m_pProc->GetOutputStream();

        if (output)
        {
            wxString input = m_pRunDlg->get_raw_stream_text();
        #if wxUSE_UNICODE
            output->Write(input.mb_str(wxConvUTF8), input.Len());
        #else
            output->Write(input, input.Len());
        #endif
        }

        m_pProc->CloseOutput();
    }

    return;
}

bool MainFrame::RedirectChildProcOutput()
{
    bool has_input = false;

    if (!m_pProc)
        return false;

    if (m_pProc->IsInputAvailable())
    {
        wxTextInputStream tis(*(m_pProc->GetInputStream()));
        // this assumes that the output is always line buffered
        //m_pBuildOutput->AppendText(tis.ReadLine());
        //m_pBuildOutput->AppendText("\n");
        m_BuildOutputStrBuf << tis.ReadLine() << "\n";
        has_input = true;
    }
    else
    {
        m_pBuildOutput->AppendText(m_BuildOutputStrBuf);
        m_BuildOutputStrBuf = wxEmptyString;
    }

    if (m_pProc->IsErrorAvailable())
    {
        wxTextInputStream tis(*(m_pProc->GetErrorStream()));
        // this assumes that the output is always line buffered
        //m_pBuildError->AppendText(tis.ReadLine());
        //m_pBuildError->AppendText("\n");
        m_BuildErrorsStrBuf << tis.ReadLine() << "\n";
        has_input = true;
    }
    else
    {
        m_pBuildError->AppendText(m_BuildErrorsStrBuf);
        m_BuildErrorsStrBuf = wxEmptyString;
    }

    return has_input;
}

void MainFrame::OnIdle(wxIdleEvent& event)
{
    if (!m_pProc)
        return;

    bool hasInput = RedirectChildProcOutput();

    if (hasInput)
        event.RequestMore();
}


void miPipeProc::OnTerminate(int pid, int status)
{
    //m_parent->m_pBuildOutput->AppendText(m_parent->m_OutputStr);
    //m_parent->m_pBuildError->AppendText(m_parent->m_ErrorStr);

    m_parent->DeregSubProc(this);
    //delete this;
    //m_parent->m_pProc = NULL;
}

void MainFrame::OnErrWinLeftDclick(wxMouseEvent &event)
{
    if (!m_pBuildError)
    {
        return;
    }

#if 0
    int pos = m_pBuildError->GetInsertionPoint();
    long x,y;
    m_pBuildError->PositionToXY(pos, &x, &y);
    wxString line = m_pBuildError->GetLineText(y);

#if (_BSD_SOURCE || _XOPEN_SOURCE >= 500)
    int start = line.Find('>');
    if (start != -1)
    {
        start++;
    }
    else
    {
        start = 0;
    }

#else
    int start = line.Find('/');
#endif
    int end = line.Find(':') - 1;
    wxString file_name = line.SubString(start, end);

    if (!wxFileExists(file_name))
        return;

    start = end + 2;
    end = line.find(':', start)-1;
    wxString line_no = line.SubString(start, end);


    miEditor* ed = OpenFile(file_name);

    if (ed)
    {
        long lineno;
        if (line_no.ToLong(&lineno))
        {
            ed->HightLightLine(lineno - 1);
        }
    }

#endif
}


bool MainFrame::OnDropFiles(wxCoord x, wxCoord y, const wxArrayString& files)
{
    bool success = true; // Safe case initialisation

    /*
    // first check to see if a workspace is passed. If so, only this will be loaded
    wxString foundWorkspace;
    for (unsigned int i = 0; i < files.GetCount(); ++i)
    {
        FileType ft = FileTypeOf(files[i]);
        if (ft == ftCodeBlocksWorkspace || ft == ftMSVC6Workspace || ft == ftMSVC7Workspace)
        {
            foundWorkspace = files[i];
            break;
        }
    }

    if (!foundWorkspace.IsEmpty())
      success &= OpenGeneric(foundWorkspace);
    else
    {
        wxBusyCursor useless;
        wxPaintEvent e;
        ProcessEvent(e);

        Freeze();
        for (unsigned int i = 0; i < files.GetCount(); ++i)
          success &= OpenGeneric(files[i]);
        Thaw();
    }
    */

    for (unsigned int i = 0; i < files.GetCount(); ++i)
    {
          OpenFile(files[i]);
    }

    return success;
}


void MainFrame::OnTimerRunning(wxTimerEvent& event)
{

    RedirectChildProcOutput();

    if (wxProcess::Exists(m_ProcID))
    {

    }
    else
    {
        //m_BuildRunningTimer.Stop();
    }
}
