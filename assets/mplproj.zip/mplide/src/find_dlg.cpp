
#include <wx/bookctrl.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/statbox.h>
#include <wx/checkbox.h>
#include <wx/stattext.h>
#include <wx/spinctrl.h>
#include <wx/textctrl.h>
#include <wx/button.h>
#include <wx/radiobox.h>
#include <wx/combobox.h>
#include "find_dlg.h"




BEGIN_EVENT_TABLE(miFindDlg, wxPropertySheetDialog)
END_EVENT_TABLE()

miFindDlg::miFindDlg(wxWindow* parent, const FindReplaceData& frd, const wxString &ttf)
{
	Create(parent, frd, ttf);
}

miFindDlg::~miFindDlg()
{

}

bool miFindDlg::Create(wxWindow* parent, const FindReplaceData& frd, const wxString &ttf)
{
    if (!wxPropertySheetDialog::Create(parent, -1, wxT("Search"), wxDefaultPosition, wxDefaultSize,
                wxDEFAULT_DIALOG_STYLE|wxRESIZE_BORDER|wxMAXIMIZE_BOX|wxMINIMIZE_BOX))
        return false;

    SetSheetStyle(wxPROPSHEET_SHRINKTOFIT | wxPROPSHEET_BUTTONTOOLBOOK);
    SetSheetInnerBorder(0);
    SetSheetOuterBorder(0);

    CreateButtons(wxOK|wxCANCEL);

    wxBookCtrlBase* notebook = GetBookCtrl();
    wxPanel *find_settings = CreateFindPage(notebook, frd, ttf);
    wxPanel *findinfiles_settings = CreateFindInFilesPage(notebook);

    notebook->AddPage(find_settings, wxT("Find"));
    notebook->AddPage(findinfiles_settings, wxT("Find in files"));
    LayoutDialog();

    return true;

}

wxPanel* miFindDlg::CreateFindPage(wxWindow *parent, const FindReplaceData& frd, const wxString &ttf)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);
    wxBoxSizer *top_sizer = new wxBoxSizer(wxVERTICAL);

	// text to search
	top_sizer->Add(new wxStaticText(panel, wxID_ANY, wxT("Text to search for")), 0, wxTOP|wxBOTTOM|wxALIGN_LEFT|wxEXPAND, 5);
	text = new wxComboBox(panel, wxID_ANY, ttf, wxDefaultPosition, wxDefaultSize, frd.GetChoiceNum(), frd.GetChoices(), wxCB_DROPDOWN);
	top_sizer->Add(text, 0, wxEXPAND|wxALIGN_LEFT, 0);

	wxBoxSizer *sizer_2 = new wxBoxSizer(wxHORIZONTAL);
	//options
	wxStaticBoxSizer *options = new wxStaticBoxSizer(wxVERTICAL, panel, wxT("Options"));
	options->Add( m_pcbWholeWord = new wxCheckBox(panel, wxID_ANY, wxT("Whole word")), 0, wxALL|wxALIGN_LEFT, 5);
	options->Add( m_pcbStartWord = new wxCheckBox(panel, wxID_ANY, wxT("Start word")), 0, wxALL|wxALIGN_LEFT, 5);
	options->Add( m_pcbMatchCase = new wxCheckBox(panel, wxID_ANY, wxT("Match case")), 0, wxALL|wxALIGN_LEFT, 5);
	options->Add( m_pcbRegExpr = new wxCheckBox(panel, wxID_ANY, wxT("Regular expression")), 0, wxALL|wxALIGN_LEFT, 5);

	m_pcbWholeWord->SetValue(frd.GetWholeWord());
	m_pcbStartWord->SetValue(frd.GetStartWord());
	m_pcbMatchCase->SetValue(frd.GetMatchCase());
	m_pcbRegExpr->SetValue(frd.GetRegExpr());

	//directoiin

	wxString directions[2]={wxT("Forward"), wxT("Backward")};
    wxRadioBox *direction = new wxRadioBox(panel, wxID_ANY, wxT("Direction"), wxDefaultPosition, wxDefaultSize, 2, directions,1);


	sizer_2->Add(options,  0, wxEXPAND|wxSHAPED, 0);
	sizer_2->Add(direction,  0, wxEXPAND|wxLEFT, 5);


	top_sizer->Add(sizer_2, 0, wxTOP|wxEXPAND|wxALIGN_LEFT, 5);

    panel->SetSizer(top_sizer);
    top_sizer->Fit(panel);

    // set focus
    text->SetFocus();
    return panel;
}


wxPanel* miFindDlg::CreateFindInFilesPage(wxWindow *parent)
{
    wxPanel *panel = new wxPanel(parent, wxID_ANY);

    return panel;
}


wxString miFindDlg::GetTextToSearch()const
{
	return text->GetValue();
}

bool miFindDlg::GetWholeWord()const
{
	return m_pcbWholeWord->GetValue();
}

bool miFindDlg::GetStartWord()const
{
	return m_pcbStartWord->GetValue();
}

bool miFindDlg::GetMatchCase()const
{
	return m_pcbMatchCase->GetValue();
}

bool miFindDlg::GetRegExpr()const
{
	return m_pcbRegExpr->GetValue();
}
