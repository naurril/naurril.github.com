#if !defined __MPLIDE_MAIN_H__
#define __MPLIDE_MAIN_H__
#include "find_replace_data.h"
class miPipeProc;
class miRunDlg;
class miFindDlg;
class wxFileHistory;
//main frame
class MainFrame : public wxFrame
{
    enum
    {
        ID_Build_CheckSyntax = wxID_HIGHEST+1,
        ID_Build_Run,

        ID_File_Open_Recent_File_Clear_History,


        ID_View_Toolbar_Main,
        ID_View_Toolbar_Build,
        ID_View_MsgWin,

        ID_Search_Find,
        ID_Search_FindNext,
		ID_Search_FindPrev,

        ID_Settings_Environment,
        ID_Settings_Editor,
        ID_Settings_Output,

        //ID_Timer_BuildRunning,

        ID_About,

    };

public:
    MainFrame(wxWindow* parent,
            wxWindowID id,
            const wxString& title,
            const wxPoint& pos = wxDefaultPosition,
            const wxSize& size = wxDefaultSize,
            long style = wxDEFAULT_FRAME_STYLE | wxSUNKEN_BORDER);

    ~MainFrame();

    wxAuiDockArt* GetDockArt();
    void DoUpdate();

private:

    bool DoFileSaveAs();
    bool DoFileSave();
private:
    void OnFileNew(wxCommandEvent& event);
    void OnFileOpen(wxCommandEvent& event);
    void OnFileSave(wxCommandEvent& event);
    void OnFileSaveAs(wxCommandEvent& event);
    void OnFileClose(wxCommandEvent& event);
    void OnFileReopen(wxCommandEvent& event);
    void OnFileCloseAll(wxCommandEvent& event);
    void OnFile(wxCommandEvent& event);
    void OnExit(wxCommandEvent& event);
    void OnSize(wxSizeEvent& event);

    void OnViewMsgWin(wxCommandEvent& event);
    void OnViewToolbarMain(wxCommandEvent& event);
    void OnViewToolbarBuild(wxCommandEvent& event);
    void OnSearchFind(wxCommandEvent& event);
    void OnSearchFindNext(wxCommandEvent& event);
	void OnSearchFindPrev(wxCommandEvent& event);
    void OnBuildCheckSyntax(wxCommandEvent& event);
    void OnBuildRun(wxCommandEvent& event);

	void OnSettingsEditor(wxCommandEvent& event);
	void OnSettingsEnvironment(wxCommandEvent& event);
	void OnSettingsOutput(wxCommandEvent& event);

	bool PreProcEditorPageClose();

    void OnEditorPageClose(wxAuiNotebookEvent &event);
    void OnUpdateUI(wxUpdateUIEvent& event);
	void OnClose(wxCloseEvent& event);
    void OnErrWinLeftDclick(wxMouseEvent &event);

	void OnIdle(wxIdleEvent& event);

    void OnTimerRunning(wxTimerEvent& event);

	miEditor* OpenFile(const wxString &file_path);
	void InstallAccelerator();
	void InstallToolbars();
	void InstallMenus();
	void InitializeRecentFilesHistory();
	void AddToRecentFilesHistory(const wxString& FileName);
	void CreatePanes();

	void SaveAppCfg();
	void SaveFileHistory();

	bool PrepareFindReplaceInput(const wxString &default_ttf);

	friend class miPipeProc;
    bool RedirectChildProcOutput();

    void SetBuildWinStyle();

public:
	bool OnDropFiles(wxCoord x, wxCoord y, const wxArrayString& files);

private:

    wxAuiManager m_mgr;

    wxAuiNotebook* m_pNbEditor;
    wxAuiNotebook* m_pNbOutput;

    wxStyledTextCtrl *m_pBuildOutput;
    wxStyledTextCtrl *m_pBuildError;

    miRunDlg *m_pRunDlg;
    FindReplaceData m_tFindReplaceData;

    int     m_RunningStatus;
    //wxTimer m_BuildRunningTimer;

    wxFont  m_OutputFont;
private:
    wxMenuBar* m_main_menu_bar;
    wxFileHistory* m_pFilesHistory;

public:
    void DeregSubProc(miPipeProc* proc) {m_RunningStatus=0;}
private:
    miPipeProc *m_pProc;
    int  m_ProcID;

    wxString m_BuildOutputStrBuf;
    wxString m_BuildErrorsStrBuf;

    DECLARE_EVENT_TABLE();
};

#endif //__MPLIDE_MAIN_H__
