#if !defined __MPLIDE_FIND_REPLACE_H_
#define __MPLIDE_FIND_REPLACE_H_

#include <wx/string.h>
#include <wx/stc/stc.h>

class FindReplaceData
{
public:
    FindReplaceData():flags(0),n_choices(0),n_replaces(0) {}

    int SetFlags(int f) { return flags = f;}
    int GetFlags()const {return flags;}

    bool GetMatchCase()const { return flags & wxSTC_FIND_MATCHCASE;}
    bool GetWholeWord()const { return flags & wxSTC_FIND_WHOLEWORD;}
    bool GetStartWord()const { return flags & wxSTC_FIND_WORDSTART;}
    bool GetRegExpr()const   { return flags & wxSTC_FIND_REGEXP;}

    int GetChoiceNum()const {return n_choices;}
    const wxString* GetChoices()const{return choices;}
    int GetReplacesNum()const {return n_choices;}
    const wxString* GetReplaces()const{return choices;}

    wxString GetTtf()const{ return ttf;}
    void SetTtf(const wxString &ttf_) {ttf = ttf_;}

    void AddChoice(const wxString &choice);
    void AddReplace(const wxString &replace);

private:
    int flags;

    wxString ttf;

    const static int MAX_CHOICES = 20;

    int n_choices;
    wxString choices[MAX_CHOICES + 1];

    int n_replaces;
    wxString replaces[MAX_CHOICES + 1];
};


#endif
