
#ifndef FIND_DLG_H
#define FIND_DLG_H
#include <wx/propdlg.h>
#include <wx/string.h>
#include "find_replace_data.h"

class wxPanel;
class wxComboBox;
class wxCheckBox;


class miFindDlg : public wxPropertySheetDialog
{
	public:
		miFindDlg(wxWindow* parent, const FindReplaceData &frd, const wxString &ttf);
		~miFindDlg();

	public:
		wxString GetTextToSearch()const;
		bool GetWholeWord()const;
		bool GetStartWord()const;
		bool GetMatchCase()const;
		bool GetRegExpr()const;
		//void SetTextToFind(const wxString &ttf);
	private:
		wxPanel* CreateFindPage(wxWindow *parent, const FindReplaceData &frd_, const wxString &ttf);
		wxPanel* CreateFindInFilesPage(wxWindow *parent);
		bool Create(wxWindow* parent, const FindReplaceData &frd_, const wxString &ttf);

		wxComboBox *text;
		wxCheckBox *m_pcbWholeWord;
		wxCheckBox *m_pcbStartWord;
		wxCheckBox *m_pcbMatchCase;
		wxCheckBox *m_pcbRegExpr;

	private:

		DECLARE_EVENT_TABLE()
};


#endif // FIND_DLG_H

