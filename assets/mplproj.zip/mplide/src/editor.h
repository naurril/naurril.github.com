#if !defined __MPLIDE_EDITOR_H__
#define __MPLIDE_EDITOR_H__


class wxStyledTextEvent;
class wxSplitterWindow;
class wxBoxSizer;
class wxStyledTextCtrl;
class wxFont;

class miEditor: public wxPanel
{
	DECLARE_EVENT_TABLE()

public:
	miEditor(wxWindow* parent, const wxString& filename);
	virtual ~miEditor();
	bool 	LoadFile (const wxString &file, int fileType=wxTEXT_TYPE_ANY);
	bool SaveFile(const wxString& filename = wxT(""));
	bool HasFilePath()const {return file_path!=wxT("");}
	bool GetModified()const;
	wxString GetFilePath()const {return file_path;}
	void UpdateUI();
	void HightLightLine(int lineno);
	void ShowPos(int pos);
	void GoToPos(int pos);
	void SetSelectioin(int start, int end);

	int FindText (int minPos, int maxPos, const wxString& text, int flags);
	int GetLength()const;
	int GetCurrentPos()const;

public:
	wxStyledTextCtrl* GetControl()const {return m_pControl;}
	wxString GuessTextToFind()const;

private:

	void ApplyStyle();
	void UpdateStyleConfig();

private:
	wxSplitterWindow* m_pSplitter;
	wxBoxSizer* m_pSizer;
	wxStyledTextCtrl* m_pControl;
	wxStyledTextCtrl* m_pControl2;
    wxFont *m_pFont;
    int m_nTabSize;
    wxStyledTextCtrl* CreateEditor();
	wxString file_path;
	wxString file_name;

private:
	wxString GetLineIndentString(int line);
	wxChar GetLastNonWhitespaceChar(int position = -1);

	// scintilla events
	void OnMarginClick(wxStyledTextEvent& event);
	void OnEditorUpdateUI(wxStyledTextEvent& event);
	void OnEditorChange(wxStyledTextEvent& event);
	void OnEditorCharAdded(wxStyledTextEvent& event);
	void OnEditorDwellStart(wxStyledTextEvent& event);
	void OnEditorDwellEnd(wxStyledTextEvent& event);
	void OnEditorModified(wxStyledTextEvent& event);
	void OnUserListSelection(wxStyledTextEvent& event);
	void OnZoom(wxStyledTextEvent& event);
	void OnScintillaEvent(wxStyledTextEvent& event);
	void OnClose(wxCloseEvent& event);



};


#endif //__MPLIDE_EDITOR_H__
