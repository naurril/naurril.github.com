


#if !defined _MPLIDE_ENVIRONMENT_SETTINGS_DLG_H__
#define _MPLIDE_ENVIRONMENT_SETTINGS_DLG_H__


#include <wx/propdlg.h>
class wxPanel;
class wxTextCtrl;
class miEnvironmentSettingsDlg : public wxPropertySheetDialog
{
    enum
    {
        ID_MplExeChoose = wxID_HIGHEST+200,
        ID_MplLibChoose,
    };

public:
    miEnvironmentSettingsDlg(wxWindow* parent);
    ~miEnvironmentSettingsDlg();
private:
    bool Create(wxWindow* parent);
    wxPanel* CreateGeneralPage(wxWindow *parent);
    wxPanel* CreateRunOptionsPage(wxWindow *parent);
    wxPanel* CreateSyntaxCheckOptionsPage(wxWindow *parent);
    wxTextCtrl *mpl_path;
    wxTextCtrl *mpl_lib_path;
    wxTextCtrl* run_options;

private:
    void OnOkBtn(wxCommandEvent& event);
    void OnMplExeChoose(wxCommandEvent& event);
    void OnMplLibChoose(wxCommandEvent& event);


DECLARE_EVENT_TABLE()
};

#endif
