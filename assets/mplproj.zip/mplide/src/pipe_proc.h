#if !defined __MPLIDE_PIPE_PROC__
#define __MPLIDE_PIPE_PROC__
#include <wx/process.h>
class MainFrame;

class miPipeProc: public wxProcess
{
public:
    miPipeProc(MainFrame *parent)
    {
        m_parent = parent;
    }

    // instead of overriding this virtual function we might as well process the
    // event from it in the frame class - this might be more convenient in some
    // cases
    virtual void OnTerminate(int pid, int status);

protected:
    MainFrame *m_parent;
};

#endif
