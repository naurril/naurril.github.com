
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum Action {ACT_NONE, ACT_READ_NUM, ACT_READ_LINES};


struct StatTab
{
    int state;
    const char *match_str;
    int state_next_ok;
    Action act_ok;       // 0 - continue, 1 - read num, 2-read lines
    int state_next_fail;
    Action act_fail;     // 0 - continue, 1 - read num, 2-read lines
};

struct StatFsm
{
    char *name;
    int   mask;
    StatTab tab[5];
};

StatFsm g_fsms[] =
{

    {
        "air", 0,
        {
            {0, "ucBURST_TYPE=3",           1, ACT_NONE,    0, ACT_NONE},
            {1, "ucNUM_MSGS",               2, ACT_NONE,    0, ACT_NONE},
            {2, "ucNUM_FIELDS=",            3, ACT_READ_NUM,0, ACT_NONE},
            {3, "aucCHARi",                 4, ACT_NONE,    0, ACT_NONE},
            {4, "",                         4, ACT_READ_LINES, 0, ACT_NONE},
        },
    },

    /* air2 example
          |-ucMSG_NUMBER=1 (0x01)(short)
          |-ucBURST_TYPE=3 (0x03)(short)
          |-ucNUM_MSGS=1 (0x01)(short)
          |-ucNUM_FIELDS=29 (0x1d)(short)
          |-aucDataBurstCHARi[158](1 Dimension Array)
            |-[0]=0 (0x00)(short)
            |-[1]=0 (0x00)(short)

    */

    {
        "air2", 0,
        {
            {0, "ucBURST_TYPE=3",           1, ACT_NONE,    0, ACT_NONE},
            {1, "ucNUM_MSGS",               2, ACT_NONE,    0, ACT_NONE},
            {2, "ucNUM_FIELDS=",            3, ACT_READ_NUM,0, ACT_NONE},
            {3, "aucDataBurstCHARi",        4, ACT_NONE,    0, ACT_NONE},
            {4, "",                         4, ACT_READ_LINES, 0, ACT_NONE},
        },
    },


    {
        "a1", 0,
        {
            {0, "tADDSUserPart",          1, ACT_NONE,    0, ACT_NONE},
            {1, "ucDataBurstType=3",        2, ACT_NONE,    0, ACT_NONE},
            {2, "ucLength=",                3, ACT_READ_NUM,0, ACT_NONE},
            {3, "aucApplicationDataMessage",4, ACT_NONE,    0, ACT_NONE},
            {4, "",                         4, ACT_READ_LINES, 0, ACT_NONE},
        }
    },

    {
        "mtp3", 0,
        {
            {0, "CIC_SLS",              1, ACT_NONE,    0, ACT_NONE},
            {1, "ucH1H0",               2, ACT_NONE,    0, ACT_NONE},
            {2, "wLen=",                3, ACT_READ_NUM,0, ACT_NONE},
            {3, "bSif",                 4, ACT_NONE,    0, ACT_NONE},
            {4, "",                     4, ACT_READ_LINES, 0, ACT_NONE},
        },
    },

    //end, shouldn't change
    {
        NULL, 0,
        {
            {0, "",                     4, ACT_READ_LINES, 0, ACT_NONE},
        },
    },
};

int parse(FILE *in, struct StatTab *tab)
{
    const int BUF_SIZE = 10240;
    char str[BUF_SIZE + 1];
    char format_str[1024];

    char *t;
    int sms_lines=0;
    int lines_read = 0;

    int state = 0;

    while (!feof(in))
    {
        str[0] = 0;
        if (NULL == fgets(str, BUF_SIZE, in))
        {
            //end of line
            break;
        }

        t= strstr(str, tab[state].match_str);
        if (t != NULL)
        {
            switch (tab[state].act_ok)
            {
            case ACT_NONE:
                break;
            case ACT_READ_NUM:
                format_str[0]=0;
                strcat(format_str, tab[state].match_str);
                strcat(format_str, "%d");
                sscanf(t, format_str, &sms_lines);
                break;
            case ACT_READ_LINES:
                if (sms_lines-- > 0)
                {
                    printf(str);
                    lines_read++;
                    //printf("\n");
                }
                else
                {
                    return 0;
                }
                break;
            };

            state = tab[state].state_next_ok;
        }
        else
        {
               state = tab[state].state_next_fail;
        }


   }

    return lines_read;
}

int show_help()
{
        fprintf(stdout, "Usage: raw_msg_extractor  input-filename interface-type\n");
        fprintf(stdout, "       intput-filename: path of the file (text format, zte 1xstp) \n");
        fprintf(stdout, "       interface-type: 'a1'(a-one) or 'air'\n");
        fprintf(stdout, "  e.g. raw_msg_extractor e:\EV_S_UmfDataBurstMsg.txt a1");

        return 0;
}


StatTab *find_tab(char *tab_name)
{
    StatFsm *fsm = g_fsms;
    while (fsm->name)
    {
        if (strcmp(fsm->name, tab_name) == 0) // match
        {
            return fsm->tab;
        }

        fsm++;
    }

    return NULL;
}

int main(int argc, char* argv[])
{
    FILE *in = NULL;

    StatTab *tab;

    if (argc < 2)
    {
        show_help();
        return 0;
    }

    tab = NULL;
    // user specified input content type?
    if (argc >=3)
    {
        tab = find_tab(argv[2]);

        if (!tab)
        {
            show_help();
        }
        else
        {
            in = fopen(argv[1], "r");
            if (in==NULL)
            {
                perror(argv[1]);
                return 0;
            }

            parse(in, tab);
            fclose(in);
        }
        return 0;
    }


    //user didn't specified the format,  try one by one
    StatFsm *fsm = g_fsms;
    while (fsm->name)
    {
        in = fopen(argv[1], "r");
        if (in==NULL)
        {
            perror(argv[1]);
            return 0;
        }

        if (parse(in, fsm->tab))
        {
            fclose(in);
            return 0;
        }
        fclose(in);
        fsm++;
    }

    return 0;
}
