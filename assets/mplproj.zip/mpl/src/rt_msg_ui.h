
#if !defined _RT_MSG_UI_H_
#define _RT_MSG_UI_H_

int print_msg_text_layout(FILE* fout, MsgNodePtr  msg, IRawMemory *mem);
int print_msg_text_layout(std::ostream &o, MsgNodePtr  msg, IRawMemory *mem);

#endif // !defined _RT_MSG_UI_H_
