/*
* MPL syntax parser
*/


//#ifdef HAVE_CONFIG_H
//# include "config.h"
//#endif


#include "code.h"
#include "rt_msg_tree.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <cctype>
#include <memory>
#include <climits>
#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include "global.h"
#include "settings.h"
#include "engine_intl_func.h"
#include "str_manager.h"

//#include "config.h"



//constructor
MplCode::MplCode(std::ostream &_out, std::ostream &_err):
        o_out(_out), o_err(_err)
{
    current_line = -1 ;
    current_column = 0;
    current_token = UNKNOWN;
    end_of_file = false;
    current_indent = 0;
    file_id = STR_ID_STDIN;

    indent_stack.push(0);
    pending_token.clean();

    total_errors = 0;
    total_warnings = 0;
    input_file = NULL;
    src_codes = NULL;
    src_codes_index = 0;
}


void MplCode::print_current_spot(std::ostream &out)
{
    out << line<<std::endl;
    std::string pos = "";

    for (unsigned int i = 1; i < current_column; i++)
    {
        if (line[i-1] == '\t')
            pos += '\t';
        else
            pos+=' ';
    }
    pos += '^';
    out << pos << std::endl;
}


int MplCode::emit_compile_warning_info(CompileError &e)
{
    total_warnings++;

    //print_current_spot(o_err);
    o_err << "mplcode> "<< id2str(file_id)<<":" <<current_line + 1<<":"<<current_column<<": warning:("<<e.err_code<<"): ";

    switch (e.err_code)
    {
    case err_loop_import_detected:
        o_err<<"loop import of '"<<e.info<<"'"<<", ignored."<<std::endl;
        break;
    case err_repeated_import_detected:
        o_err<<"duplicate import of '"<<e.info<<"'"<<", ignored."<<std::endl;
        break;
    case err_cannot_open_file:
        o_err<<"cannot open file: "<<e.info<<", ignored."<<std::endl;
        break;
    case err_unknown_escape_character:
        o_err<<"unknown escaped character '"<<e.para_1<<"'."<<std::endl;
        break;
    default:
        o_err<<"general warning: "<<e.info<<std::endl;
        break;
    }

    return 0;
}

int MplCode::emit_compile_err_info(CompileError &e, bool throwable)
{
    //print_current_spot(o_err);
    o_err << "mplcode> " << id2str(file_id)<<":" <<current_line + 1<<":"<<current_column<<": error("<<e.err_code<<"): ";

    switch (e.err_code)
    {
    case err_expect_token:
        o_err << "expect "<<token2Name(static_cast<Token>(e.para_1))
        <<" while encountering "<<token2Name(static_cast<Token>(e.para_2))<<std::endl;
        break;
    case err_unexpected_end_of_line:
    case err_unexpected_end_of_file:
        o_err << e.info<<std::endl;
        break;
        //case unknown_func_name:
        //    o_err<<e.err_code<<", unknown function name: "<<e.info<<std::endl;
        //    break;
    case err_unexpected_token:
        o_err<<"unexpected token: "<<token2Name(static_cast<Token>(e.para_1))<<e.extra_info<<std::endl;
        break;
    case err_cannot_open_file:
        o_err<<"cannot open file: "<<e.info<<std::endl;
        break;
    case err_unexpected_break:
        o_err<<"unexpected \'break\'"<<std::endl;
        break;
    case err_unexpected_continue:
        o_err<<"unexpected \'continue\'"<<std::endl;
        break;
    case err_name_confliction:
        o_err<<"conflict definition with the name: '"<<e.info<<"'"<<std::endl;
        //o_err<<"\t(the line number shown above indicates the end of the current definition)"<<std::endl;
        o_err<<e.extra_info<<std::endl;
        break;
    case err_unmatched_para_list:
        o_err<<"unmatched parameter number: expected "<<e.para_1<<", but got "<<e.para_2<<std::endl;
        break;
    case err_incorrect_const_char_defined:
        o_err<<"incorrect const character definition"<<std::endl;
        break;

    case err_too_many_errors:
        o_err<<"too many errors, syntax checking stopped."<<std::endl;
        break;
    case err_non_int_value_in_vnldef:
        o_err<<"expect integer value in vnldef."<<std::endl;
        break;
    case err_non_string_in_vnldef:
        o_err<<"expect string literal in vnldef."<<std::endl;
        break;
    case err_invalid_dedent:
        o_err<<"unindent doesn't match any earlier indentation level."<<std::endl;
        break;
	case err_src_codes_already_set:
		o_err<<"source codes already input."<<std::endl;
		break;
	case err_src_file_already_set:
		o_err<<"source file already set."<<std::endl;
		break;
    default:
        o_err<<"general error: "<<e.info<<std::endl;
        break;
    }

    if (throwable)
    {
        ++total_errors;

        if (total_errors >= 50)
        {
            throw  CompileError (err_too_many_errors, total_errors, 0, "");
        }
    }

    return 0;
}

GNode* MplCode::parse(const char* src, InputType type)
{
    try
    {
      GNode* g = NULL;
      if (INPUT_FILE == type)
         set_src_file(src);
      else
        set_src_codes(src);

      next_token();
      g = mpl();

      //o_out << "mpl: syntax checking finished, "<<total_errors<<" errors, "<<total_warnings<<" warnings."<<std::endl;
      if (total_errors)
        {
	  delete g;
	  return 0;
        }

      return g;
    }
    catch (CompileError e)
    {
        // special process for 'too many errors'
        if (e.err_code == err_too_many_errors)
        {
            o_err<<"mpl: too many errors ("<<e.para_1<<"), syntax checking stopped."<<std::endl;
        }
        else
        {
            emit_compile_err_info(e, false);
            total_errors++;
        }
    }
    catch (MplError e)
    {
        o_err<<"unknonwn error occured!!"<<std::endl;
    }
    catch ( ...)
    {
        o_err << "unknown error!"<<std::endl;
    }

    //o_err << "mpl: syntax checking finished, "<<total_errors<<" errors, "<<total_warnings<<" warnings."<<std::endl;

    return 0;
}

GNode* MplCode::mpl()
{
    GNodeAutoPtr g(create_new_gnode(NT_MSG_DEF, "__unnamed_mpl_node__"));

    while (current_token != END_MARKER)
    {
        g->add_node(stmt(g.get()));
    }

    //g->add_node(stmt_seq());

    return g.release();
}

// p: parent node
GNode* MplCode::stmt(GNode* p)
{
    switch (current_token)
    {
    case IF:
        return if_stmt(p);
    case WHILE:
        return while_stmt(p);
    case TRY_LOOP:
        return try_loop_stmt(p);
    case FOR:
        return for_stmt(p);
    case VNL_DEF:
        return vnl_def(p);
    case MSG_DEF:
        return msg_def(p);
    case FUNC_DEF:
        return func_def(p);
    case INTERPRET:
        return interpret_stmt();
    case RUN_SWITCH:
        return runswitch_stmt();
    case IMPORT:
        return import_stmt(p);
        //case ASSERT:
        //    return assert_stmt();
        //case CHECK:
        //    return check_stmt();
    case RETURN:
        return return_stmt(p);
    case BREAK:
        return break_stmt(p);
	case CONTINUE:
		return continue_stmt(p);
    case SEMICOLON:
        drain_semicolon();
        return NULL;

    case AT:
    case DOT:
        //    return special_assignment();
    default:
        return simple_stmt(p);
    }
    return NULL;
}

/*
// assignment who doesn't generate a new msg item
GNode* MplCode::special_assignment()
{
    bool is_hiden = false;
    bool is_non_local = false;

    if (current_token == DOT)
    {
        match(DOT);
        is_non_local = true;
    }
    else
    {
        match(AT);
        is_hiden = true;
    }

    //int line_number = current_line;
	std::string name = current_token_str;
    match(NAME);
    match(ASSIGN);

    GNodeAutoPtr g(create_new_gnode(NT_ASSIGN_STMT, name));
    GNodeAutoPtr exp(expr_stmt());

    g->add_node(create_new_gnode(NT_NAME, name, g.get()));
    g->add_node(exp.release());

    if (is_non_local)
        g->attr = NA_NON_LOCAL;
    else if (is_hiden)
        g->attr = NA_HIDEN;

    drain_semicolon();

    return g.release();

}
*/

// check if a 'break' statement is semantic valid
bool MplCode::is_loop_context_stmt(GNode* g)
{
    GNode* p = g;

    //break cannot cross msg-call or func-call boundary
    while (p)
    {
        if (IS_LOOP_CONTEXT_STMT(p->type))
            return true;
        p = p->parent;
    }

    return false;
}


GNode* MplCode::break_stmt(GNode* p)
{
    if (!is_loop_context_stmt(p))
    {
        CompileError e(err_unexpected_break, 0, 0, "unexpected \'break\'");
        emit_compile_err_info(e);
        //throw e;
        match(BREAK);
        return NULL;
    }


    match(BREAK);
    GNodeAutoPtr g(create_new_gnode(NT_BREAK_STMT, "__unnamed_break_stmt__"));

    return g.release();
}
GNode* MplCode::continue_stmt(GNode* p)
{
    if (!is_loop_context_stmt(p))
    {
        CompileError e(err_unexpected_continue, 0, 0, "unexpected 'continue'");
        emit_compile_err_info(e);
        //throw e;
        match(CONTINUE);
        return NULL;
    }


    match(CONTINUE);
    GNodeAutoPtr g(create_new_gnode(NT_CONTINUE_STMT, "__unnamed_continue_stmt__"));

    return g.release();
}
GNode* MplCode::return_stmt(GNode* p)
{
    match(RETURN);
    GNodeAutoPtr g(create_new_gnode(NT_RETURN_STMT, "__unnamed_return_stmt__", p));

    if (current_token != SEMICOLON)
    {
        GNodeAutoPtr exp(expr_stmt());
        g->add_node(exp.release());
    }

    drain_semicolon();

    return g.release();
}


// check and assert are implemented as built-in functions
/*
GNode* MplCode::check_stmt()
{
	match(CHECK);
	match(LEFT_PRNTH);

    GNodeAutoPtr g(create_new_gnode(NT_CHECK_STMT, "__unnamed_check_node__"));
	GNodeAutoPtr exp(expr_stmt());
	exp->parent = g.get();
	g->children.push_back(exp.get());
	exp.release();

	match(COMMA);
	g->name = current_token_str;
	match(CONST);

    match(RIGHT_PRNTH);
    drain_semicolon();

    return g.release();
}

GNode* MplCode::assert_stmt()
{
	match(ASSERT);
	match(LEFT_PRNTH);

    GNodeAutoPtr g(create_new_gnode(NT_ASSERT_STMT, "__unnamed_assert_node__"));
	GNodeAutoPtr exp(expr_stmt());
	exp->parent = g.get();
	g->children.push_back(exp.get());
	exp.release();

	match(COMMA);
	g->name = current_token_str;
	match(CONST);

    match(RIGHT_PRNTH);
    drain_semicolon();

    return g.release();
}
*/
GNode* MplCode::simple_stmt(GNode* p)
{
	GNode* s = NULL;
    if (current_token == FIXED || current_token == MULTIPLE || current_token == OPTIONAL)
    {
        s = specifier();
    }

    return simple_stmt_with_specifier(s, p);
}

GNode* MplCode::specifier()
{
    switch (current_token)
    {
    case FIXED:
    {
        GNodeAutoPtr g(create_new_gnode(NT_FIXED_SPECIFIER, "__unnamed_fixed_specifier_node__"));
        match(FIXED);
        match(LEFT_PRNTH);
        GNodeAutoPtr exp(expr_stmt());
        exp->parent = g.get();
        g->children.push_back(exp.get());
        exp.release();
        match(RIGHT_PRNTH);
        return g.release();
    }
    case MULTIPLE:
    {
        GNodeAutoPtr g(create_new_gnode(NT_MULTIPLE_SPECIFIER, "__unnamed_multiple_specifier_node__"));
        match(MULTIPLE);
        match(LEFT_PRNTH);
        GNodeAutoPtr exp(expr_stmt());
        exp->parent = g.get();
        g->children.push_back(exp.get());
        exp.release();
        match(RIGHT_PRNTH);
        return g.release();
    }
    case OPTIONAL:
    {
        match(OPTIONAL);
        return create_new_gnode(NT_OPTIONAL_SPECIFIER, "__unnamed_optional_specifier_node__");
    }
    default:
        //never reach here
        return NULL;
        break;
    }

}

// submsg call, func call, assignment
GNode* MplCode::simple_stmt_with_specifier(GNode* specifier, GNode* p)
{
    unsigned long attr = 0;

    GNodeAutoPtr protected_specifier(specifier);


    if (current_token == AT)
    {
        match(AT);
        attr |= NA_HIDDEN;
    }
    else if (current_token == DOT)
    {
        match(DOT);
        attr |= NA_NON_LOCAL;
    }

    int line_number = current_line;
    std::string name = current_token_str;
    match(NAME);

    // maybe func name, or sub-msg name, or left-variable of assignment
    GNodeAutoPtr tmp(qualified_name(name));
    record_node_position(tmp.get(), line_number);

    if (current_token == LEFT_PRNTH)
    {
        if (attr != 0)
        {
            //give warning. TBC
        }
        GNode *g = func_call(tmp.release(), protected_specifier.release());
	if (g)
	    g->attr = attr;
	return g;
    }
    else  if (current_token == ASSIGN)
    {
        //assign
        match(ASSIGN);
        GNodeAutoPtr g(create_new_gnode(NT_ASSIGN_STMT, tmp->get_full_name()));
        g->attr = attr;

        GNodeAutoPtr exp(expr_stmt());

        if (specifier)
        {
            g->add_node(protected_specifier.release());
        }

        g->add_node(tmp.release());
        g->add_node(exp.release());

        drain_semicolon();

        return g.release();
    }
    else
    {
        //sub_msg_call without para-list
        GNodeAutoPtr g(create_new_gnode(NT_SUB_MSG_CALL, name));
        record_node_position(g.get(), line_number);
        g->attr = attr;
        tmp->parent = g.get();
        if (specifier)
        {
            g->add_node(protected_specifier.release());
        }
        g->add_node(tmp.release());

        drain_semicolon();

        return g.release();
    }


    return NULL;
}


GNode* MplCode::expr_stmt()
{
    return or_test();
}

GNode* MplCode::or_test()
{
    GNodeAutoPtr c(and_test());

    if (current_token != OR)
    {
        return c.release();
    }

    GNodeAutoPtr g(create_new_gnode(NT_OR_TEST, "__unnamed_or_test__"));
    c->parent = g.get();
    g->children.push_back(c.get());
    c.release();

    while (current_token == OR)
    {
        match(OR);
        GNodeAutoPtr re(and_test());
        re->parent = g.get();
        g->children.push_back(re.get());
        re.release();
    }

    return g.release();

}


GNode* MplCode::and_test()
{

    GNodeAutoPtr c(cmp_exp());

    if (current_token != AND)
    {
        return c.release();
    }


    GNodeAutoPtr g(create_new_gnode(NT_AND_TEST, "__unnamed_and_test__"));

    c->parent = g.get();
    g->children.push_back(c.get());
    c.release();

    while (current_token == AND)
    {
        match(AND);
        GNodeAutoPtr t(cmp_exp());
        t->parent = g.get();
        g->children.push_back(t.get());
        t.release();
    }

    return g.release();;

}

GNode* MplCode::cmp_exp()
{

    GNodeAutoPtr left(arith_exp());

    switch (current_token)
    {
    case LESS_THAN:
    case GREATER_THAN:
    case EQUAL:
    case NOT_EQUAL:
    case LESS_OR_EQUAL:
    case GREATER_OR_EQUAL:
        break;
    default:
        return left.release(); // no comparation
        break;
    }

    GNodeAutoPtr g(create_new_gnode(NT_CMP_EXP, "__unnamed_cmp_exp__"));
    //left
    left->parent = g.get();
    g->children.push_back(left.get());
    left.release();
    g->tokens.push_back(current_token);
    match(current_token);

    //right operator
    GNodeAutoPtr right(arith_exp());
    right->parent = g.get();
    g->children.push_back(right.get());
    right.release();
    return g.release();
}

GNode* MplCode::arith_exp()
{

    GNodeAutoPtr c(term_exp());

    if (!(current_token == ADD || current_token == SUB))
    {
        return c.release();
    }

    GNodeAutoPtr g (create_new_gnode(NT_ARITH_EXP, "__unnamed_arith_exp__"));
    c->parent = g.get();
    g->children.push_back(c.get());
    c.release();

    while (current_token == ADD || current_token == SUB)
    {
        g->tokens.push_back(current_token);
        match(current_token);
        GNodeAutoPtr t(term_exp());
        t->parent = g.get();
        g->children.push_back(t.get());
        t.release();
    }

    return g.release();

}

GNode* MplCode::term_exp()
{

    GNodeAutoPtr f(factor());

    if (!(current_token == MUL || current_token == DIV || current_token == MOD))
    {
        return f.release();
    }

    GNodeAutoPtr g(create_new_gnode(NT_TERM_EXP, "__unnamed_term_exp__"));
    f->parent = g.get();
    g->children.push_back(f.get());
    f.release();


    while (current_token == MUL || current_token == DIV || current_token == MOD)
    {
        g->tokens.push_back(current_token);
        match(current_token);

        GNodeAutoPtr f(factor());
        f->parent = g.get();
        g->children.push_back(f.get());
        f.release();
    }

    return g.release();
}

//current_token is already left_brace
// it's func-call, or func-call formed message call
GNode* MplCode::func_call(GNode* func_name, GNode* specifier)
{
    GNodeAutoPtr protected_func_name(func_name);
    GNodeAutoPtr protected_specifier(specifier);

    GNodeAutoPtr g(create_new_gnode(NT_FUNC_CALL, func_name->get_full_name()));

    match(LEFT_PRNTH);

    //para is second child
    //first para
    GNodeAutoPtr para_list(create_new_gnode(NT_PARA_LIST, func_name->get_full_name()));
    if (current_token != RIGHT_PRNTH)
    {
        para_list->add_node(expr_stmt());
    }

    while (current_token != RIGHT_PRNTH)
    {
        match(COMMA);
        para_list->add_node(expr_stmt());
    }

    //check parameter number, TBC
    //use full name to match function call, otherwise incorrect match may occur
    int ret = EngineIntlFunc::static_check(protected_func_name.get()->get_full_name(), para_list.get()->children.size());

    if (ret)
    {
        // print error info, and continue compiling
        CompileError e(err_unmatched_para_list, ret - 1, para_list.get()->children.size(), "");
        emit_compile_err_info(e);

    }

    match(RIGHT_PRNTH);


    if (specifier)
        g->add_node(protected_specifier.release());

    g->add_node(protected_func_name.release());
    g->add_node(para_list.release());
    drain_semicolon();

    return g.release();
}

GNode* MplCode::factor()
{
    GNode *g = NULL;


    switch (current_token)
    {
    case NAME:
    {
        std::string first_name = current_token_str;
        match(NAME);

        GNodeAutoPtr tmp(qualified_name(first_name));

        if (current_token == LEFT_PRNTH)
        {
            return func_call(tmp.release());
        }
        else
        {
            //nt_name, or nt_qualified_name
            return tmp.release();
        }
    }
    break;
    case CONST:
        g = create_new_gnode(NT_CONST, current_token_str);
        g->value = current_value;
        match(CONST);
        return g;
        break;

    case LEFT_PRNTH:
    {
        match(LEFT_PRNTH);
        GNodeAutoPtr e(expr_stmt());
        match(RIGHT_PRNTH);
        return e.release();
        break;
    }
    /*
    case CONST:
        g = create_new_gnode(NT_CONST, current_token_str);
        g->value = current_value;
        match(LITERAL_STRING);
        return g;
        break;
    */
    case ADD:
    case SUB:
    case NOT:
    {
        return unary_exp();
        break;
    }
    case END_MARKER:
    default:
    {
        CompileError e(err_unexpected_token, current_token, 0, "unexpected token", 0, " (expect an expression)");
        //if (current_token == END_MARKER)
        {
            throw e;
        }
        //else
        {
            emit_compile_err_info(e);
            return NULL; //return null will cause crash. refer to the calling place
        }
    }

    }

    return NULL;
}

GNode* MplCode::unary_exp()
{
    Token t = current_token;
    match(current_token);
    GNodeAutoPtr e(create_new_gnode(NT_UNARY_EXP, "__unnamed_unary_expr"));
    GNodeAutoPtr se(factor());
    se->parent = e.get();
    e->tokens.push_back(t);
    e->children.push_back(se.release());
    return e.release();


}

// if it's not really dotted name, modify the type to NT_NAME
GNode* MplCode::qualified_name(std::string first_name)
{
    GNodeAutoPtr g(create_new_gnode(NT_NAME, first_name));

    //g->qualified_name.push_back(first_name);
    bool is_compound = false;
    bool is_dotted = false;

    while (1)
    {
        if (current_token == DOT)
        {
            match(DOT);
            std::string name = current_token_str;
            match(NAME);
            GNodeAutoPtr c(create_new_gnode(NT_NAME, name));
            c->parent = g.get();
            g->children.push_back(c.get());
            c.release();

            g->tokens.push_back(DOT);
            is_compound = true;
            is_dotted = true;
        }
        else if (current_token == LEFT_BRACKET)
        {
            match(LEFT_BRACKET);
            GNodeAutoPtr c(expr_stmt());
            match(RIGHT_BRACKET);
            c->parent = g.get();
            g->children.push_back(c.get());
            c.release();

            g->tokens.push_back(LEFT_BRACKET);
            is_compound = true;
        }
        else
        {
            break;
        }
    }

    if (is_compound)
    {

        /*
        if (is_dotted)
        {
            g->type = NT_QUALIFIED_NAME;
        }
        else
        {
            g->type = NT_PURE_INDEXED_NAME;
        }
        */
        // 28Jul2010, lie, pure_indexed_name seems useless to be a
        // single unique identifiers.
        g->type = NT_QUALIFIED_NAME;
    }

    return g.release();
}




void MplCode::print_in_file_stack()
{
    // print out file stack here
    o_out<<std::endl;
    o_out<<"current source file stack :"<<std::endl;
    for (SRC_FILE_CONTEXT_STACK::iterator i = src_file_context_stack.begin(); i != src_file_context_stack.end(); i++)
    {
        o_out<<id2str(i->file_id)<<std::endl;
    }
    o_out<<id2str(this->file_id)<<std::endl;
    o_out<<"-----------"<<std::endl;
}

// seach a file, if fail return null string
std::string MplCode::search_file(const char* file_name, const char* first_path) const
{
    std::string full_path_name;
    //o_out<<"search "<<file_name << " from "<<first_path<<std::endl;
    // try 0: try directly
    if (0 == access(file_name, R_OK))
    {
        return file_name;
    }

    // try 1 seach parent module path
    full_path_name = first_path;
    full_path_name  += "/";
    full_path_name  += file_name;

    if (0 == access(full_path_name.c_str(), R_OK))
    {
        return full_path_name;
    }

    //try 2, seach current path
    full_path_name =  "./";
    full_path_name += file_name;
    if (0 == access(full_path_name.c_str(), R_OK))
    {
        return full_path_name;
    }

    //try 3, -i
    if (get_global_settings()->search_path_list.size())
    {
        for (std::list<std::string>::iterator i = get_global_settings()->search_path_list.begin();
                i != get_global_settings()->search_path_list.end();
                ++i)
        {
            full_path_name = *i;

            if (full_path_name[full_path_name.size()-1] != '/' && full_path_name[full_path_name.size()-1] != '\\')
                full_path_name += '/';

            full_path_name += file_name;

            if (0 == access(full_path_name.c_str(), R_OK))
            {
                return full_path_name;
            }
        }
    }
    //try 4 seach environment path
    //char buf[1024];
    //searchenv(file_name, "MPL_ROOT_LIB_PATH", buf);
    char *buf = getenv("MPL_ROOT_LIB_PATH");
    if (buf != NULL && buf[0] != 0)
    {
        if (get_global_settings()->verbose)
        {
            o_err << "mplcode> getenv 'MPL_ROOT_LIB_PATH' succeeded: "<< buf << std::endl;
        }

        full_path_name = buf;

        if (full_path_name[full_path_name.size()-1] != '/' && full_path_name[full_path_name.size()-1] != '\\')
            full_path_name += '/';

        full_path_name += file_name;

        if (0 == access(full_path_name.c_str(), R_OK))
        {
            return full_path_name;
        }
    }

    o_err<<"mplcode> cannot find file: "<<file_name<<std::endl;
    return "";
}


std::string MplCode::get_abs_file_path(const std::string &relative_path)
{
    char *ret;
#if defined __MINGW32__
    ret = _fullpath(NULL, relative_path.c_str(), 0);
#else
    ret = realpath(relative_path.c_str(), NULL);
#endif
//#if (_BSD_SOURCE || _XOPEN_SOURCE >= 500)
//    ret = realpath(relative_path.c_str(), NULL);
//#else
//    ret = _fullpath(NULL, relative_path.c_str(), 0);
//#endif


    if (ret == NULL)
    {
        perror(relative_path.c_str());
        o_err<<"mplcode> get real path of '"<<relative_path<<"' failed"<<std::endl;
        return relative_path;
    }

    //std::cout<<"full path:"<<ret<<std::endl;
    std::string str = ret;
    free(ret);
    return str;
}

/*
22Jul2010, lie
how to eliminate repeated import
  record every imported file-id in every gnode, when same files are
  imported in same gnode-context, ignore it.

*/
GNode* MplCode::import_stmt(GNode* p)
{
    match(IMPORT);
    std::string module_name = current_token_str; // a.b.c.d.module - moudle name
    std::string imported_file_name = current_token_str; // a/b/c/d/module.mpl - path name

    /*
    If the import statement is the last one of
    a file, the match(...) will pop out SOME files which may cause the loop detection faiure.
         e.g
          file a (root file)
            ...
            import b
          file b:
            ...
            import b
     obviously it's a dead loop, but when the parser read "import b" line of file b, after 'b' is matched,
     file-b is already popped out from the 'in_file_stack', thus we cannot detect this error.
     **attention: in other cases, an import statement may cause more than one files to pop out.

     ok, we could copy one tempory in_file_stack, and use them to detect dead-loop.

     this is why we need temp_stack.
     */

    SRC_FILE_ID_STACK  temp_stack = src_file_name_stack;

    //save somthing, for loop-import detection, and error reporting

    std::string importing_file_name = id2str(this->file_id);
    //std::string importing_file_path = id2str(this->path_id);
    int importing_line = this->current_line;
    int importing_column = this->current_column;

    // after this match, context may change
    match(NAME);


    while (current_token == DOT)
    {
        match(DOT);
        //module_name +=".";
        //module_name += current_token_str;
        module_name = current_token_str;
        imported_file_name += "/";
        imported_file_name += current_token_str;
        match(NAME);
    }

    drain_semicolon();

    // the above match may pop out some files

    // file seaching order
    /*
    1) same path as parent module (here it's importing_file_name)
    2) root_module_path + file_path
    3) -I search parth
    4) MPL_ROOT_LIB_PATH
    */

    imported_file_name+= ".mpl";

    std::string full_path_name = search_file(imported_file_name.c_str(), id2str(this->path_id));

    if (full_path_name == "")
    {
        CompileError e(err_cannot_open_file, 0, 0, imported_file_name);
        emit_compile_warning_info(e);
        return 0;
    }

    //absoluate file path
    full_path_name = get_abs_file_path(full_path_name);

    FILE* temp_in  = fopen(full_path_name.c_str(), "r");
    if (NULL == temp_in)
    {
        perror(full_path_name.c_str());
        //print_current_spot(o_err);
        o_err <<"mplcode> "<< importing_file_name<<"(line " <<importing_line + 1<<":"<<importing_column<<") error: failed open file :"
        <<imported_file_name<<", ignored for now!"<<std::endl;
        return 0;
        //throw CompileError(cannot_open_file, 0, 0, file_name);
    }


    //check parent files, to detect loop import
    for (SRC_FILE_ID_STACK::iterator i = temp_stack.begin(); i != temp_stack.end(); i++)
    {
        if (id2str(*i) == full_path_name)
        {
            //o_err<<"mplcode> warning(2): loop import of \""<<imported_file_name<<"\",";
            //o_err<<"statement ignored!"<<std::endl;
            CompileError e(err_loop_import_detected, 0, 0, imported_file_name);
            emit_compile_warning_info(e);
            fclose(temp_in);
            return 0;
        }
    }

    /*
    how to detect repeated import? TBD
    */
    // check repeated importing
    for (GNode::IMPORTED_FILE_ID_STACK::iterator i = p->imported_file_stack.begin();
    	i != p->imported_file_stack.end();
    	i++)
    {
        if (id2str(*i) == full_path_name)
        {
            //o_err<<"mplcode> warning(2): loop import of \""<<imported_file_name<<"\",";
            //o_err<<"statement ignored!"<<std::endl;
            CompileError e(err_repeated_import_detected, 0, 0, imported_file_name);
            emit_compile_warning_info(e);
            fclose(temp_in);
            return 0;
        }
    }

    if (get_global_settings()->verbose)
    {
        o_out<<"mplcode> source file: "<<full_path_name<<" opened!"<<std::endl;
    }

    src_file_name_stack.push_back(this->file_id);

    save_current_file_pos();

    //update current parsing position
    this->input_file = temp_in;
    this->line[0] = 0;
    this->line_size = 0;
    this->current_line = -1;

    this->current_column = 0;
    this->end_of_file = false;
    this->module_name = module_name;

    this->file_id = get_str_manager()->store_new_str(full_path_name.c_str());
    this->path_id = get_str_manager()->store_new_str(file_2_path(full_path_name).c_str());

    this->pending_token.clean();  // previous pending token has been saved earlier

	// record imported file id
	p->imported_file_stack.push_back(this->file_id);

    while (indent_stack.size() > 1)
    {
        indent_stack.pop();
    }
    // no need to push 0 here. because 0 wasn't pop out

    next_line();
    next_token();
    return NULL;
}

GNode* MplCode::stmt_seq(GNode* p)
{
    GNodeAutoPtr g(create_new_gnode(NT_STMT_SEQ, "__unnamed_stmt_seq__", p));

    // pointer returned from stmt() need not be protected by auto_ptr
    // add_node will release the memory if fails
    g->add_node(stmt(g.get()));


    while ((current_token != DEDENT) && (current_token != END_MARKER))
    {
        // pointer returned from stmt() can not be protected by auto_ptr
        // add_node will release the memory if fails
        g->add_node(stmt(g.get()));
    }

    return g.release();
}

GNode* MplCode::if_stmt(GNode* p)
{
    match(IF);

    GNodeAutoPtr g(create_new_gnode(NT_IF_STMT, "__unnamed_if_stmt__", p));

    GNodeAutoPtr test(expr_stmt());
    g->add_node(test.get());
    test.release();
    g->tokens.push_back(IF);


    match(COLON);
    match(INDENT);
    GNodeAutoPtr stmts(stmt_seq(g.get()));
    match(DEDENT);

    g->add_node(stmts.get());

    stmts.release();
    g->tokens.push_back(PHONY_STUB);

    while (current_token == ELIF)
    {
        match(ELIF);
        GNodeAutoPtr test(expr_stmt());
        g->children.push_back(test.get());
        test->parent = g.get();
        test.release();
        g->tokens.push_back(ELIF);

        match(COLON);

        match(INDENT);
        GNodeAutoPtr stmts(stmt_seq(p));
        match(DEDENT);
        g->children.push_back(stmts.get());
        stmts->parent = g.get();
        stmts.release();
        g->tokens.push_back(PHONY_STUB);
    }

    if (current_token == ELSE)
    {
        match(ELSE);
        match(COLON);
        match(INDENT);
        GNodeAutoPtr stmts(stmt_seq(p));
        match(DEDENT);
        g->children.push_back(stmts.get());
        stmts->parent = g.get();
        stmts.release();
        g->tokens.push_back(ELSE);
    }

    return g.release();
}

GNode* MplCode::interpret_stmt()
{
    int line_number;

    //create interpret node
    match(INTERPRET);
    std::string first_name = current_token_str;
    GNodeAutoPtr g(create_new_gnode(NT_INTERPRET_STMT, first_name));

    // create first child
    line_number = current_line;
    match(NAME);
    GNodeAutoPtr t_first(qualified_name(first_name));
    record_node_position(t_first.get(), line_number);

    match(COLON);

    GNodeAutoPtr t_second(expr_stmt());

    record_node_position(t_second.get(), line_number);

    // push children
    g->children.push_back(t_first.get());
    t_first->parent = g.get();
    t_first.release();

    g->children.push_back(t_second.get());
    t_second->parent = g.get();
    t_second.release();

    drain_semicolon();
    return g.release();
}

GNode* MplCode::runswitch_stmt()
{
    int line_number;

    //create interpret node
    match(RUN_SWITCH);
    std::string first_name = current_token_str;
    GNodeAutoPtr g(create_new_gnode(NT_RUNSWITCH_STMT, first_name));

    // create first child
    line_number = current_line;
    match(NAME);
    GNodeAutoPtr t_first(qualified_name(first_name));
    record_node_position(t_first.get(), line_number);

    match(COLON);

    GNodeAutoPtr t_second(expr_stmt());

    record_node_position(t_second.get(), line_number);

    // push children
    g->children.push_back(t_first.get());
    t_first->parent = g.get();
    t_first.release();

    g->children.push_back(t_second.get());
    t_second->parent = g.get();
    t_second.release();

    drain_semicolon();
    return g.release();
}

GNode* MplCode::try_loop_stmt(GNode* p)
{
    GNodeAutoPtr g(create_new_gnode(NT_TRY_LOOP, "__unnamed_try_loop__"));

    match(TRY_LOOP);
    match(COLON);
    match(INDENT);

    g->add_node(stmt_seq(g.get()));

    match(DEDENT);

    return g.release();
}

GNode* MplCode::while_stmt(GNode* p)
{
    GNodeAutoPtr g(create_new_gnode(NT_WHILE_STMT, "__unnamed_while_stmt__"));

    match(WHILE);
    g->add_node(expr_stmt());
    match(COLON);
    match(INDENT);


    g->add_node(stmt_seq(g.get()));

    match(DEDENT);

    return g.release();
}

GNode* MplCode::for_stmt(GNode* p)
{
    return NULL;
}

/*
only check funcdef, msgdef, vnldef
return:
	0 - no repetition
	others - yes
*/
int MplCode::check_def_repetition(GNode *parent, GNode *def)
{
    if (parent)
    {
        GNode::MSG_MAP::iterator i = parent->sub_defs.find(def->name);
        if (i != parent->sub_defs.end())
        {
            //repetition found!
            std::stringstream ss;
            //std::cerr<<"mplcode> message or value-name-list repetition detected, name: "<<p->name<<std::endl;
            ss<<"\tcurrently defined in "<<id2str(def->src_file_id)<<":"<<def->src_line_number + 1<<std::endl;
            ss<<"\tpreviously defined in "<<id2str(i->second->src_file_id)<<":"<<i->second->src_line_number + 1<<std::endl;

            CompileError e(err_name_confliction, 0, 0, def->name, 0, ss.str());
            emit_compile_err_info(e);

            //throw e;
            return 1;
        }
    }

    return 0;
}

GNode* MplCode::vnl_def(GNode* p)
{
    match(VNL_DEF);
    std::string vld_name = current_token_str;
    GNodeAutoPtr g(create_new_gnode(NT_VNL_DEF, vld_name));

    check_def_repetition(p, g.get());
    match(NAME);


    // parameter list
    if (current_token == LEFT_PRNTH)
    {
        match(LEFT_PRNTH);
        if (current_token != RIGHT_PRNTH)
        {
            GNodeAutoPtr para_list(create_new_gnode(NT_PARA_LIST, vld_name));
            std::string para_name = current_token_str;
            match(NAME);
            GNode* para = create_new_gnode(NT_NAME, para_name);
            para_list->add_node(para);
            g->add_node(para_list.release());
        }

        match(RIGHT_PRNTH);
    }

    match(COLON);
    match(INDENT);

    while (current_token != DEDENT && current_token != END_MARKER && current_token != DEFAULT)
    {
        MplValue v = current_value;
        match(CONST);
        //const must be integer value
        if (!IS_INT_TYPE(v))
        {
            CompileError e(err_non_int_value_in_vnldef, v.type, 0, "");
            emit_compile_err_info(e);
        }
        match(COLON);
        std::string str = current_token_str;
        match(CONST);

        //const must be string literal
        g->vnl[v.value.i] = str;

	// add one statement to support run-switch
	if (current_token == COMMA)
	{
	    match(COMMA);
	    GNode *st = simple_stmt(g.get());
	    st->parent = g.get();
	    g->vsl[v.value.i] = st;
	}
        drain_semicolon();
    }

    if (current_token == DEFAULT)
    {
        match(DEFAULT);
        match(COLON);

        GNode* tg = expr_stmt();
        tg->parent = g.get();
        g->vnl_default_handler = tg;

	// add one statement to support run-switch
	if (current_token == COMMA)
	{
	    match(COMMA);
	    GNode *st = simple_stmt(g.get());
	    st->parent = g.get();
	    g->vsl_default_handler = st;
	}

        drain_semicolon();
    }

    match(DEDENT);

    return g.release();
}


// p: parent node
GNode* MplCode::msg_def(GNode* p)
{
    match(MSG_DEF);
    std::string msg_name = current_token_str;
    GNodeAutoPtr g(create_new_gnode(NT_MSG_DEF, msg_name, p));

    //record_node_position(g.get());

    // check repetition, only give error-info,donnot stop
    check_def_repetition(p, g.get());

    match(NAME);
    GNodeAutoPtr para_list(create_new_gnode(NT_PARA_LIST, msg_name));

    if (current_token == LEFT_PRNTH)
    {
        //parameter list
        match(LEFT_PRNTH);

        if (current_token != RIGHT_PRNTH)
        {
            std::string para_name = current_token_str;
            match(NAME);
            GNode* para = create_new_gnode(NT_NAME, para_name);
            para_list->add_node(para);
        }

        while (current_token != RIGHT_PRNTH)
        {
            match(COMMA);
            std::string para_name = current_token_str;
            match(NAME);
            GNode* para = create_new_gnode(NT_NAME, para_name);
            para_list->add_node(para);
        }

        match(RIGHT_PRNTH);
    }

    g->add_node(para_list.release());

    match(COLON);
    match(INDENT);

    while ((current_token != DEDENT) && (current_token != END_MARKER))
    {
        g->add_node(stmt(g.get()));
    }

    match(DEDENT);
    return g.release();

}

GNode* MplCode::func_def(GNode* p)
{
    match(FUNC_DEF);
    std::string func_name = current_token_str;
    GNodeAutoPtr g(create_new_gnode(NT_FUNC_DEF, func_name));

    //record_node_position(g.get());
    check_def_repetition(p, g.get());

    match(NAME);


    //parameter list
    match(LEFT_PRNTH);
    GNodeAutoPtr para_list(create_new_gnode(NT_PARA_LIST, func_name));

    if (current_token != RIGHT_PRNTH)
    {
        std::string para_name = current_token_str;
        match(NAME);
        GNode* para = create_new_gnode(NT_NAME, para_name);
        para_list->add_node(para);
    }

    while (current_token != RIGHT_PRNTH)
    {
        match(COMMA);
        std::string para_name = current_token_str;
        match(NAME);
        GNode* para = create_new_gnode(NT_NAME, para_name);
        para_list->add_node(para);
    }

    match(RIGHT_PRNTH);
    match(COLON);
    match(INDENT);

    g->add_node(para_list.release());

    //GNodeAutoPtr func_body(create_new_gnode(NT_STMT_SEQ, func_name));
    while ((current_token != DEDENT) && (current_token != END_MARKER))
    {
        // check repetition
        g->add_node(stmt(g.get()));
    }

    //g->add_node(func_body.release());

    match(DEDENT);

    return g.release();

}

GNode* MplCode::create_new_gnode(NodeType type, std::string name, GNode* p)
{
    return new GNode(type, name, file_id, current_line, p);
}

void MplCode::record_node_position(GNode* g)
{
    g->src_file_id = file_id;
    g->src_line_number = current_line;
}

void MplCode::record_node_position(GNode* g, int line_number)
{
    g->src_file_id = file_id;
    g->src_line_number = line_number;
}

void MplCode::drain_semicolon()
{
    while (current_token == SEMICOLON)
        match(SEMICOLON);
}
