#ifndef _MPL_STACKLESS_ENGINE_H
#define _MPL_STACKLESS_ENGINE_H

#include "engine.h"
#include <stack>


struct EngineFrame
{
public:
    EngineFrame(){}
    ~EngineFrame(){}
    MsgNodePtr msg;   // message body currently building
    GNode *g_node;  // points to grammar node currently running

    std::vector<GNode*>::iterator continuation;
};

typedef std::stack<EngineFrame*> FrameStack;


class StacklessEngine: public Engine
{
public:
    StacklessEngine(GNode* _grammar, IRawMemory *_mem, std::ostream &_out = std::cout, std::ostream &_err = std::cerr);
    int run(MsgNodePtr msg);
    virtual ~StacklessEngine(){}

private:
    FrameStack frame_stack;
    MplValue run_top_frame();

protected:
    //MsgNodePtr get_msg() {return &top_msg_node; }

    int runtime_assert(bool expr, GNode* g, MsgNodePtr msg, const std::string &info);

    int run_gnode(GNode* g, MsgNodePtr msg);
    int run_if_stmt(GNode* g, MsgNodePtr msg);
    int run_assign_stmt(GNode* g, MsgNodePtr msg);
    int run_stmt_seq(GNode* g, MsgNodePtr msg);
    int run_interpret_stmt(GNode* g, MsgNodePtr msg);
    int run_assert_stmt(GNode* g, MsgNodePtr msg);
    int run_check_stmt(GNode* g, MsgNodePtr msg);
    int run_sub_msg_call(GNode* g, MsgNodePtr msg);
    int try_sub_msg_call(GNode* g, MsgNodePtr sub_msg);

    MplValue eval_func_call(GNode* g, MsgNodePtr msg);
    MplValue eval_expr(GNode* g, MsgNodePtr msg);
    MplValue eval_or_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_and_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_cmp_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_arith_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_term_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_qualified_name(GNode* g, MsgNodePtr msg);

    //helper funcs
    MsgNodePtr locate_msg_by_qualified_name(GNode* name, MsgNodePtr starting_msg);

};

#endif

