

#ifndef _GLOBAL_H_
#define _GLOBAL_H_

//attention, not effect at all cases, you are warned!
template <class T, int N> char (&__helper_func(T (&para)[N]))[N];
#define __countof(a) sizeof(__helper_func(a))

#endif

