#ifndef _MPL_VALUE_H_
#define _MPL_VALUE_H_

#include <string>
#include <iostream>
#include "shared_ptr.h"
#include "msg_node.h"
//typedef int MplValue;
//class MsgNode;


enum ValueType{
    VT_INT,
    VT_FLOAT,
    VT_CHAR,
    VT_WCHAR,
    VT_STRING,
    VT_WSTRING,
    VT_A_INT,  //arbitrary integer, TBC
    VT_MSG_REF,   //msg ? make any sense?
    VT_NON_TYPE,
};

#define IS_INT_TYPE(v) ((v).type == VT_INT || (v).type == VT_CHAR || (v).type == VT_WCHAR)

struct MplValue
{
    ValueType type;
    struct {
        int i; // int, char, wchar_t
        double f;
        std::string s;
        std::wstring ws;
        //MsgNodePtr msg_ref; // msg reference
        MsgNodePtr msg_ref;
    }value;

    MplValue(int _i) {type = VT_INT; value.i = _i; }
    MplValue(double _f) {type = VT_FLOAT; value.f = _f; }
    MplValue(char _c) {type = VT_CHAR; value.i = _c; }
    MplValue(wchar_t _c) {type = VT_WCHAR; value.i = _c; }
    MplValue(const std::string &_str) {type = VT_STRING; value.s = _str; }
    MplValue(const std::wstring &_str) {type = VT_WSTRING; value.ws = _str; }
    MplValue(const char* _str) {type = VT_STRING; value.s = _str; }
    MplValue(const wchar_t* _str) {type = VT_WSTRING; value.ws = _str; }
    MplValue(MsgNodePtr _msg) {type = VT_MSG_REF; value.msg_ref = _msg; }
    MplValue() {type = VT_NON_TYPE; }
    //operator int() {return value.i;}
    int asint() ;

    bool operator == (const MplValue &v) const;
    bool operator >  (const MplValue &v) const;
    bool operator <  (const MplValue &v) const;
    bool operator >= (const MplValue &v) const;
    bool operator <= (const MplValue &v) const;
    bool operator != (const MplValue &v) const;
    MplValue operator + (const MplValue &v);
    MplValue operator += (const MplValue &v);
    MplValue operator - (const MplValue &v);
    MplValue operator -= (const MplValue &v);
    MplValue operator * (const MplValue &v);
    MplValue operator *= (const MplValue &v);
    MplValue operator / (const MplValue &v);
    MplValue operator /= (const MplValue &v);
    MplValue operator % (const MplValue &v);
    MplValue operator %= (const MplValue &v);
    MplValue operator - ();
    MplValue operator + ();
    MplValue operator ! ();

    std::string tostr();
    std::string tostr_hex();

    static std::string &get_type_name(ValueType t) {return value_type_name[t]; }
private:
    static std::string value_type_name[];
};

std::ostream & operator << (std::ostream &o, MplValue v);
void print_value(FILE* fout, MplValue &v, bool hex = false);
#endif
