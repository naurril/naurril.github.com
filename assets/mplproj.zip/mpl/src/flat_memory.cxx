/*
07Sep2009, lie, support multi-byte hex numbers, e.g. 0x1234567890abcde,
                pad 4 bits of 0 if the digits length is odd
*/

/*
format:
'#' started line is comment
' ' ',' ';' '\t' '\r' '\n'  seperators
0123456789abcdef - numbers
#@ - starts a command
@restart - start a new input stream
other char started strings are ignored
@end -- end all, same as 'End Of File'
@format-hex-no-0x
@format-normal

e.g.
 # comments
 0 1 0x11  070   x1231  5  # 0x00 0x11 0x38 0x05

if --no-0x is set, all numbers are considered hex
e.g.
 aa bb cc 0xff 00 01 23     #0xaa 0xbb 0xcc 0x00 0x00 0x01 0x23
*/
#include <cstring>
#include <cstdlib>
#include <cstdio>

#include "settings.h"
#include "raw_memory.h"
#include "flat_memory.h"

#define MEM_BLOCK_SIZE 1024  //initial memory size

FlatMemory::MemFrame::MemFrame()
{
    mem = 0;
    mem_len = 0;
    cur_pos.octet = 0;
    cur_pos.bit = 0;
    bits_endian = ET_BIG_ENDIAN;
    bytes_endian = ET_BIG_ENDIAN;
    length_guard_type = GUARD_NONE;
    length_guard_value = 0;
    align_octet = false;

    frame_id = 0;
    next_frame = NULL;
}

FlatMemory::MemFrame::~MemFrame()
{
    if (mem) delete[] mem;
}


FlatMemory::~FlatMemory()
{
    while (frames)
    {
        MemFrame *p = frames;
        frames = frames->next_frame;
        delete p;
    }
}

FlatMemory::FlatMemory()
{
    reset_parse_mode();
    frames = new MemFrame();
    cf = frames;
}


FlatMemory::FlatMemory(char *mem_addr, int len_)
{
    reset_parse_mode();

    frames = new MemFrame();
    cf = frames;

    cf->mem = mem_addr;
    cf->mem_len = len_;
    cf->mem_buf_size = len_;
}

FlatMemory::FlatMemory(const char* str)  //string as input
{
    reset_parse_mode();

    frames = new MemFrame();
    cf = frames;

    cf->mem = new char[MEM_BLOCK_SIZE];
    cf->mem_buf_size = MEM_BLOCK_SIZE;

    parse_line(str, 1, "<stdin>");

}

FlatMemory::FlatMemory(FILE *in, const char  * file_name)
{
    reset_parse_mode();

    frames = new MemFrame();
    cf = frames;

    int line_no = 0;
    cf->mem = new char[MEM_BLOCK_SIZE];
    cf->mem_buf_size = MEM_BLOCK_SIZE;
    cf->mem_len = 0;

    char str[10240];  // if one line is longer than this value, the result may be incorrect
                      // the main problem is how the long line is sliced, if one word are seperated
                      // into different line, the result is incorrect
                      // TBD

    while (1)
    {

        if (NULL == fgets(str, 10240, in)) //error or end of file
        {
            break;
        }

        line_no++;

        if (0 != parse_line(str, line_no, file_name))
        {
            break;
        }
    }

    int mem_frame_count = 0;
    int mem_byte_count = 0;
    MemFrame *p = frames;
    while (p)
    {
        mem_byte_count += p->mem_len;
        mem_frame_count++;

        p = p->next_frame;
    }

    fprintf(stdout, "mplmem> %d raw data frames, %d bytes inputted\n", mem_frame_count, mem_byte_count); //no new line
    print_all_frames();

}

void FlatMemory::reset_parse_mode()
{
    parse_mode = get_global_settings()->no_0x? PARSE_HEX_NO_0X : PARSE_NORMAL_FORMAT;
}


int FlatMemory::parse_line(const char *str, int line_no, const char* file_name)
{
    if (parse_mode == PARSE_HEX_NO_0X)
        return parse_line_hex_without_0x(str, line_no, file_name);
    else
        return parse_line_all_formatted_number(str, line_no, file_name);
}
int FlatMemory::start_new_mem_frame(const char *file, int line)
{

    if (cf->mem_len == 0)
    {
        fprintf(stderr, "mplmem> %s:%d: current frame empty, command 'restart' ignored\n", file, line);
        return 0;
    }

    reset_parse_mode();

    cf->next_frame = new MemFrame();
    cf->next_frame->frame_id = cf->frame_id + 1;
    cf = cf->next_frame;

    cf->mem = new char[MEM_BLOCK_SIZE];
    cf->mem_buf_size = MEM_BLOCK_SIZE;
    cf->mem_len = 0;

    return 0;
}

int FlatMemory::print_all_frames()
{
    MemFrame *f = frames;
    while (f)
    {
        fprintf(stdout, "@restart #frame %d", f->frame_id + 1);  // no new line char
        print_frame(f);
        f = f->next_frame;
    }

    return 0;
}

int FlatMemory::print_frame(MemFrame *f)
{
    for (int i = 0; i < f->mem_len; i++)
    {
        if (i % 16 == 0)
              fprintf(stdout, "\nx%04x: ", i/16*16);
        else if (i % 8 == 0)
            fprintf(stdout, "  ");
        else if (i % 4 == 0)
            fprintf(stdout, " ");
        fprintf(stdout, "%02x ", (unsigned char)(f->mem[i]));

    }
    fprintf(stdout, "\n");
    return 0;
}

int FlatMemory::print_current_frame()
{
    //   if (get_global_settings()->verbose)
    {
        fprintf(stdout, "mplmem> %d octets inputted", cf->mem_len); //no new line
        print_frame(cf);
    }
    return 0;
}

int FlatMemory::parse_line_hex_without_0x(const char *str, int line_no, const char* file_name)
{
    unsigned int i = 0;
    unsigned int size = strlen(str);
    int digits;

    while ( i < size)
    {
        int v;
        char c;
        c = str[i];
        switch (c)
        {
        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
        case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
        case 'A': case 'B': case 'C': case 'D': case 'E': case 'F':
            // the following algorithm cannot handle odd-digits hex numbers correctly
            // for example, 0x12345 will be interpreted as 0x12,0x34,0x50
            // so the input is required to be even-aligned.
            // TBD
            v = 0;
            digits = 0;
            while (i < size)
            {
                c = str[i];
                if (c <= '9' && c >= '0')
                {
                    v = v * 16 + c - '0';
                    i++;
                }
                else if (c <= 'f' && c >= 'a')
                {
                    v = v * 16 + c - 'a' + 10;
                    i++;
                }
                else if (c <= 'F' && c >= 'A')
                {
                    v = v * 16 + c - 'A' + 10;
                    i++;
                }
                else
                {
                    break;
                }

                // add one otect every 2 digits
                digits++;
                if (digits == 2)
                {
                    cf->add_mem(v);
                    v = 0;  //reset
                    digits = 0;
                }
            }

            if (1 == digits)
            {
                v *= 16;
                cf->add_mem(v);
            }
            else if (2 == digits)
            {
                cf->add_mem(v);
            }

            break;
        case ' ':
        case ',':
        case ';':
        case '\t':
        case '\r':
        case '\n':
            i++; //seperators
            break;
        case '#':
            i = size; // get next line
            break;
        case '@':
            if (1 == parse_line_mini_command(str+i, size-i, i, file_name, line_no))
            {
                return 1;  //end
            }

            i = size;
            break;i = size;
            break;

        default:
            //go until seperator
            fprintf(stderr, "mplmem> %s:%d: invalid char '", file_name, line_no);
            while ( i < size)
            {
                c = str[i];
                if (c != ' ' && c != ',' && c != ';'
                    && c != '\t' && c != '\r' && c != '\n')
                    {
                        fprintf(stderr, "%c", c);
                        i++;
                    }
                else
                {
                    fprintf(stderr, "'\n", c);
                    break;
                }
            }
            //fprintf(stderr, "mplmem> %s:%d: invalid char '%c'\n", file_name, line_no,c);
            //i++;
            break;
        }
    }

    return 0;
}


int FlatMemory::parse_line_all_formatted_number(const char *str, int line_no, const char* file_name)
{
    unsigned int i = 0;
    unsigned int size = strlen(str);
    int digits;

    while ( i < size)
    {
        int v;
        char c;
        c = str[i];
        switch (c)
        {
        case '0':
        {
            if ((i + 1 < size) && (str[i + 1] == 'x'|| str[i + 1] == 'X'))
            {
                // the following algorithm cannot handle odd-digits hex numbers correctly
                // for example, 0x12345 will be interpreted as 0x12,0x34,0x50
                // so the input is required to be even-aligned.
                // TBD
                bool add_tail_zero=false; //if 3 or more digits found, add tail zero, otherwise don't
                v = 0;
                i+=2;  // 0x, 0X
                digits = 0;
                while (i < size)
                {
                    c = str[i];
                    if (c <= '9' && c >= '0')
                    {
                        v = v * 16 + c - '0';
                        i++;
                    }
                    else if (c <= 'f' && c >= 'a')
                    {
                        v = v * 16 + c - 'a' + 10;
                        i++;
                    }
                    else if (c <= 'F' && c >= 'A')
                    {
                        v = v * 16 + c - 'A' + 10;
                        i++;
                    }
                    else
                    {
                        break;
                    }

                    // add one otect every 2 digits
                    digits++;
                    if (digits == 2)
                    {
                        cf->add_mem(v);
                        v = 0;  //reset
                        digits = 0;
                        add_tail_zero = true;
                    }
                }

                if (1 == digits)
                {
                    if (add_tail_zero)
                        v *= 16;
                    cf->add_mem(v);
                }
                else if (2 == digits)
                {
                    cf->add_mem(v);
                }

                break;
            }
            else  //octal
            {
                v = 0;
                i++;
                while (i < size)
                {
                    c = str[i];

                    if (c <= '7' && c >= '0')
                    {
                        v = v * 8 + c - '0';
                        i++;
                    }
                    else
                    {
                        if (c == '8' || c == '9')
                        {
                            fprintf(stderr, "mplmem> %s:%d: invalid octal number '%c', treat as new decimal\n",file_name, line_no,c);
                        }
                        break;
                    }
                }
                cf->add_mem(v);
                break;
            }
        }
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        {
            v = c - '0';
            i++;
            while (str[i])
            {
                c = str[i];
                if (c <= '9' && c >= '0')
                {
                    i++;
                    v = v * 10 + c - '0';
                }
                else
                {
                    break;
                }
            }
            cf->add_mem(v);
            break;
        }
        case ' ':
        case ',':
        case ';':
        case '\t':
        case '\r':
        case '\n':
            i++; //seperators
            break;
        case '#':
            i = size; // get next line
            break;
        case '@':
            if (1 == parse_line_mini_command(str+i, size-i, i, file_name, line_no))
            {
                return 1; //end
            }

            i = size;
            break;

        default:
            fprintf(stderr, "mplmem> %s:%d: invalid char '", file_name, line_no);
            while ( i < size)
            {
                c = str[i];
                if (c != ' ' && c != ',' && c != ';'
                    && c != '\t' && c != '\r' && c != '\n')
                    {
                        fprintf(stderr, "%c", c);
                        i++;
                    }
                else
                {
                    fprintf(stderr, "'\n", c);
                    break;
                }
            }
            //fprintf(stderr, "mplmem> %s:%d: invalid char '%c'\n", file_name, line_no,c);
            //i++;
            break;
        }

    }

    return 0;
}

// ret 0: ok
// ret 1: end of file (@end)
// ret 2: unkown error
int FlatMemory::parse_line_mini_command(const char *str, size_t size, int offset, const char* file_name, int line_no)
{
    int i = 1;



    while (i < size)
    {
        //filter non-alpha
        while (i < size)
        {
            char c = str[i];
            if (c ==' ' || c == '\t' || c == ',' || c == ';')
            {
                i++;
                continue;
            }
            else if (c == '@')
            {
                //ignore
                i++;
                continue;
            }
            else if (c == '#' || c == '\r' || c== '\n')
            {
                //end
                return 0;
            }
            else if (isalpha(c))
            {
                break;
            }
            else
            {
                // incorrect char in mini-command-line
                fprintf(stderr, "mplmem> %s:%d:%d incorrect char '%c', ingnored\n", file_name, line_no, offset + i, c);
                i++;
            }
        }

        //get one word
        std::string word = "";
        int cmd_pos_col = i;
        while (i < size)
        {
            if (isalnum(str[i]) || str[i] == '-')
                word += str[i];
            else
                break;
            i++;
        }

        // commands
        if (word == "")
        {

        }
        else if (word == "restart")
        {
            //start new memframe
            start_new_mem_frame(file_name, line_no);
        }
        else if (word == "end")
        {
            return 1; // end of parsing
        }
        else if (word == "format-hex-no-0x")
        {
            parse_mode = PARSE_HEX_NO_0X;
        }
        else if (word == "format-normal")
        {
            parse_mode = PARSE_NORMAL_FORMAT;
        }
        else
        {
            fprintf(stderr, "mplmem> %s:%d:%d: unknonw mini-command '%s'\n", file_name, line_no, cmd_pos_col, word.c_str());
        }
    }

    return 0;
}


int FlatMemory::MemFrame::add_mem(int value)
{
    if (mem_len >= mem_buf_size)
    {
        char* new_mem = new char[mem_buf_size*2];
        memcpy(new_mem, mem, mem_buf_size);
        delete[] mem;
        mem = new_mem;
        mem_buf_size *=2;
    }

    mem[mem_len] = (unsigned char)value;
    mem_len++;

    return  0;
}

int FlatMemory::switch_to_next_frame()
{
    if (cf->next_frame)
    {
        cf = cf->next_frame;
        return 0;
    }
    else
    {
        return 1; /* no next frame */
    }
}

int FlatMemory::reset_to_first_frame()
{
    cf = frames;
    return 0;
}

int FlatMemory::get_bits(int len, int *rv)
{
    if (ET_LITTLE_ENDIAN == cf->bits_endian)
        return get_bits_little_endian(len, rv);
    else
        return get_bits_big_endian(len, rv);
}

/*
int FlatMemory::peep_bits(int len, int *rv)
{
	return 0;
}
*/

int FlatMemory::get_bits_little_endian(int len, int *rv)
{
    int r = 0;
    int header_len = 0;
    //int middle_len = 0;
    //int tail_len = 0;



    //little endian algorithm
    //header
    if (cf->cur_pos.bit !=0)
    {
        if (end_of_input())
        {
            *rv = r;
            return 1;
        }

        if (len + cf->cur_pos.bit > 8)
            header_len = 8 - cf->cur_pos.bit;
        else
            header_len = len;

        r = reinterpret_cast<unsigned char*>(cf->mem)[cf->cur_pos.octet];
        r = ((unsigned char)(r << (8 - header_len - cf->cur_pos.bit)))>>(8-header_len);

        cf->cur_pos.bit += header_len;
        if (cf->cur_pos.bit == 8)
        {
            cf->cur_pos.bit = 0;
            cf->cur_pos.octet++;;
        }
    }

    // middle bytes
    if (len - header_len >= 8)
    {
        int temp = (len - header_len) / 8;
        while (temp > 0)
        {
            if (end_of_input())
            {
                *rv = r;
                return 1;
            }

            r = r * 0x100 + reinterpret_cast<unsigned char*>(cf->mem) [cf->cur_pos.octet];
            cf->cur_pos.octet++;

            temp--;
        }
    }

    //tail
    if ((len - header_len) % 8)
    {
        if (end_of_input())
        {
            *rv = r;
            return 1;
        }

        int temp = (len - header_len) % 8;  //bits number to be read
        r <<= temp;
        cf->cur_pos.bit += temp;

        /*
        it's impossible for bit to reach the end of the byte
        if (cf->cur_pos.bit == 8)
        {
        cf->cur_pos.bit = 0;
        cf->cur_pos.octet++;
        }
        */

        temp = (unsigned char)(0xff >> (8- temp));
        temp = (reinterpret_cast<unsigned char*>(cf->mem) [cf->cur_pos.octet]) & temp;
        r += temp;
    }

    *rv = r;
    return 0;
}

int FlatMemory::get_bits_big_endian(int len, int *rv)
{
    int r = 0;
    int header_len = 0;
    //int middle_len = 0;
    //int tail_len = 0;



    //big endian algorithm
    //header
    if (cf->cur_pos.bit !=0)
    {
        if (end_of_input())
        {
            *rv = r;
            return 1;
        }

        if (len + cf->cur_pos.bit > 8)
            header_len = 8 - cf->cur_pos.bit;
        else
            header_len = len;


        r = reinterpret_cast<unsigned char*>(cf->mem)[cf->cur_pos.octet];
        r = ((unsigned char)(r << cf->cur_pos.bit)) >> (8 - header_len);

        cf->cur_pos.bit += header_len;
        if (cf->cur_pos.bit == 8)
        {
            cf->cur_pos.bit = 0;
            cf->cur_pos.octet++;;
        }
    }

    // middle bytes
    if (len - header_len >= 8)
    {
        int temp = (len - header_len) / 8;
        while (temp > 0)
        {
            if (end_of_input())
            {
                *rv = r;
                return 1;
            }

            r = r * 0x100 + reinterpret_cast<unsigned char*>(cf->mem) [cf->cur_pos.octet];
            cf->cur_pos.octet++;

            temp--;
        }
    }

    //tail
    if ((len - header_len) % 8)
    {
        if (end_of_input())
        {
            *rv = r;
            return 1;
        }

        int temp = (len - header_len) % 8;  //bits number to be read
        r <<= temp;
        cf->cur_pos.bit += temp;

        /*
        it's impossible for bit to reach the end of the byte
        if (cf->cur_pos.bit == 8)
        {
        cf->cur_pos.bit = 0;
        cf->cur_pos.octet++;;
        }
        */

        temp = reinterpret_cast<unsigned char*>(cf->mem) [cf->cur_pos.octet] >> (8 - temp);
        r += temp;
    }

    *rv = r;
    return 0;
}

// 0-succeeded,
// 1-mem end encountered
// 2-length guard assert, failed
// 3-length guard warning, but got what is needed
int FlatMemory::get_octets(int len, int *rv)
{
    int r = 0;
    int index = 0;

    if (cf->align_octet)
    {

        while (len>0)
        {
            if (end_of_input())
            {
                *rv = r;
                return 1;
            }
            if (ET_BIG_ENDIAN == cf->bytes_endian)
                r = r * 0x100 + reinterpret_cast<unsigned char*>(cf->mem) [cf->cur_pos.octet];
            else
                r += reinterpret_cast<unsigned char*>(cf->mem) [cf->cur_pos.octet] << (8 *index);
            cf->cur_pos.octet++;

            index++;
            len--;
        }

        *rv = r;

        if (cf->cur_pos.octet > cf->length_guard_value)
        {
            return cf->length_guard_type;
        }
    }
    else // disable octet alignment
    {
        int rt;
        int ret;

        while (len-- > 0)
        {
            ret = get_bits(8, &rt);
            if (ret != 0)
            {
                *rv = r;
                return ret;
            }

            if (ET_BIG_ENDIAN == cf->bytes_endian)
            {
                r = r*0x100 + rt;
            }
            else
            {
                r += rt << (8 * index);
            }

            index++;
        }

        *rv = r;
        if (cf->cur_pos.octet > cf->length_guard_value)
        {
            return cf->length_guard_type;
        }
    }

    return 0;
}
/*
int FlatMemory::peep_octets(int len, int *rv)const
{
    int index = 0;
    int r = 0;
    MemPos pos = cf->cur_pos;
    while (len>0)
    {
        if (end_of_input())
        {
            *rv = r;
            return 1;
        }

        if (ET_BIG_ENDIAN == bytes_endian)
            r = r * 0x100 + reinterpret_cast<unsigned char*>(mem) [pos.octet];
        else
            r += reinterpret_cast<unsigned char*>(mem) [pos.octet] << (8 *index);
        pos.octet++;

        index++;
        len--;
    }

    *rv = r;
    return 0;
}

*/




int FlatMemory::get_string(int len, int bits, std::string *rv)
{
    //return "string test test test";

    std::string r="";
    int c;
    int ret;

    while (len--)
    {
        if (end_of_input())
        {
            *rv = r;
            return 1;
        }

        ret = get_bits(bits, &c);

        if (ret)
        {
            *rv = r;
            return ret;
        }

        r += (char)c;
    }

    *rv = r;

    return 0;
}


int FlatMemory::get_wstring(int len, int bits, std::wstring *rv)
{
    //return "string test test test";

    std::wstring r=L"";
    int c;
    int ret;

    while (len--)
    {
        if (end_of_input())
        {
            *rv = r;
            return 1;
        }

        ret = get_bits(bits, &c);

        if (ret)
        {
            *rv = r;
            return ret;
        }

        r += c;
    }

    *rv = r;

    return 0;
}

