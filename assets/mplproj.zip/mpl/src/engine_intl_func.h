

#ifndef _MPL_ENGINE_INTL_FUNC_
#define _MPL_ENGINE_INTL_FUNC_

#include "raw_memory.h"
#include "value.h"
#include "error.h"
#include "grammar_node.h"
#include "rt_msg_tree.h"
#include "engine.h"

class EngineIntlFunc
{

public:
    EngineIntlFunc(IRawMemory *mem_, GNode *g_, MsgNodePtr msg_, Engine* e_)
            :mem(mem_),g(g_),msg(msg_), engine(e_)//, o_out(_out), o_err(_err)
            {}
    MplValue operator () (std::string name, MplValue para_1 = 0,MplValue para_2=0,MplValue para_3=0);

    // -----------------------------------------------------------------------
    // operations malipuate raw stream memory
    MplValue get_octets(MplValue len, MplValue p1, MplValue p2);
    MplValue peep_octets(MplValue len, MplValue p1, MplValue p2);

    MplValue get_bits(MplValue len, MplValue p1, MplValue p2);
    MplValue peep_bits(MplValue len, MplValue p1, MplValue p2);

    MplValue get_char(MplValue len, MplValue p1, MplValue p2);
    MplValue get_wchar(MplValue len, MplValue p1, MplValue p2);

    MplValue get_string(MplValue len, MplValue p1, MplValue p2);
    MplValue get_wstring(MplValue len, MplValue p1, MplValue p2);

    //MemPos get_current_pos();
    MplValue get_current_octet_pos(MplValue p0, MplValue p1, MplValue p2);
    MplValue get_current_bit_pos(MplValue p0, MplValue p1, MplValue p2);
    MplValue get_current_pos(MplValue p0, MplValue p1, MplValue p2);

    MplValue set_current_octet_pos(MplValue p0, MplValue p1, MplValue p2);
    MplValue set_current_bit_pos(MplValue p0, MplValue p1, MplValue p2);
    MplValue set_current_pos(MplValue p0, MplValue p1, MplValue p2);
    MplValue restore_current_pos(MplValue p0, MplValue p1, MplValue p2);

    MplValue set_bits_endian(MplValue p0, MplValue p1, MplValue p2);
    MplValue set_bytes_endian(MplValue p0, MplValue p1, MplValue p2);
    MplValue set_bits_endian_little(MplValue p0, MplValue p1, MplValue p2);
    MplValue set_bytes_endian_little(MplValue p0, MplValue p1, MplValue p2);
    MplValue set_bits_endian_big(MplValue p0, MplValue p1, MplValue p2);
    MplValue set_bytes_endian_big(MplValue p0, MplValue p1, MplValue p2);

    //MplValue set_words_endian(MplValue p0, MplValue p1, MplValue p2);

	MplValue length_guard_assert(MplValue p0, MplValue p1, MplValue p2);
	MplValue length_guard_check(MplValue p0, MplValue p1, MplValue p2);
	MplValue length_guard_cancel(MplValue p0, MplValue p1, MplValue p2);


    // tools
    MplValue my_check(MplValue e, MplValue p1, MplValue p2);
    MplValue my_assert(MplValue e, MplValue p1, MplValue p2); //shoud not use assert which is a known c function

    // sizeof()
	MplValue my_sizeof(MplValue e, MplValue p1, MplValue p2);
	MplValue my_info(MplValue e, MplValue p1, MplValue p2);

	MplValue value2str(MplValue p0, MplValue p1, MplValue p2);
	MplValue value2strhex(MplValue p0, MplValue p1, MplValue p2);
	MplValue value2char(MplValue p0, MplValue p1, MplValue p2);
	MplValue value2wchar(MplValue p0, MplValue p1, MplValue p2);
    MplValue int_interpret_as_str(MplValue p0, MplValue p1, MplValue p2);
    MplValue my_print(MplValue p0, MplValue p1, MplValue p2);
    static int  static_check(std::string name, int  paranum);
private:
    int handle_mem_ret_code(int ret);
private:
    IRawMemory *mem;
    GNode      *g;
    MsgNodePtr  msg;
    Engine  *engine;

    //std::ostream &o_out;
    //std::ostream &o_err;
};


typedef MplValue (EngineIntlFunc::*FUNC_PTR)(MplValue,MplValue,MplValue);
#define MAX_PARA_NUM  3

#define MF_CHECK_PARA_NUM_NO       0X00 //DONT CHECK
#define MF_CHECK_PARA_NUM_EQUAL    0x01 //
#define MF_CHECK_PARA_NUM_GREATER  0x02 // AT LEAST
#define MF_CHECK_PARA_NUM_LESS     0x03 // AT MOST

#define MF_CHECK_PARA_TYPE_1       0x10
#define MF_CHECK_PARA_TYPE_2       0x20
#define MF_CHECK_PARA_TYPE_3       0x40
#define MF_CHECK_PARA_TYPE_ALL     0x70
#define MF_CHECK_PARA_TYPE_NO      0x00
// internal function
typedef struct MplFunc
{
    const char* name;
    int  paranum;
    ValueType para_type[MAX_PARA_NUM];
    int check_mask;
    FUNC_PTR pfunc;
}MplFunc;


#endif

