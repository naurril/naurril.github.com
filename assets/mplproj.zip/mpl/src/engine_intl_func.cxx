#include "global.h"
#include "engine_intl_func.h"
#include <iostream>
#include <cstring>
#include <sstream>


int EngineIntlFunc::handle_mem_ret_code(int ret)
{
    if (0 == ret)
    {
        return ret;
    }
    else if (1 == ret)
    {
        throw RuntimeError(err_unexpected_end_of_input, 0, 0, "unexpected end of input");
    }
    else if (2 == ret)
    {
        throw RuntimeError(err_length_guard_assert_failed, g->src_line_number, 0, id2str(g->src_file_id), msg.get());
    }
    else if (3 == ret)
    {
        RuntimeError e(err_length_guard_check_failed, g->src_line_number, 0, id2str(g->src_file_id), msg.get());
        engine->emit_runtime_warning(e);
        //o_err<<"mplengine> "<<id2str(g->src_file_id)<<" line "<<g->src_line_number + 1 <<" length guard check failed!"<<std::endl;
        return ret;
        //throw RuntimeError(err_length_guard_check_failed, 0, 0, "length guard check failed");
    }
    else
    {
        //unknown ret code
        std::cerr<< "debug> unknown code "<<ret<<std::endl;
        return ret;
    }
}


MplValue EngineIntlFunc::get_octets(MplValue len, MplValue p1, MplValue p2)
{
    int v;

    if (len > 4)
      {
	RuntimeError e(err_value_truncated, g->src_line_number, 0, id2str(g->src_file_id), msg.get());
	engine->emit_runtime_warning(e);
      }

    int ret = mem->get_octets(len.asint(), &v);
    //std::cout<<"internal  func called, get_octet("<<len<<","<<p1<<","<<p2<<")="<<ret<<std::endl;

    handle_mem_ret_code(ret);

    return v;
}


MplValue EngineIntlFunc::peep_octets(MplValue len, MplValue p1, MplValue p2)
{
    //std::cout<<"internal  func called, peep_octet("<<len<<","<<p1<<","<<p2<<")"<<std::endl;
    int v;
    MemPos pos = mem->get_current_pos();  //save pos
    int ret = mem->get_octets(len.asint(), &v);
    mem->set_current_pos(pos);           //restore pos

    handle_mem_ret_code(ret);

    return v;
}
MplValue EngineIntlFunc::get_bits(MplValue len, MplValue p1, MplValue p2)
{
    int v;
    if (len > 32)
      {
	RuntimeError e(err_value_truncated, g->src_line_number, 0, id2str(g->src_file_id), msg.get());
	engine->emit_runtime_warning(e);
      }

    //    runtime_assert(len.assint()<=32,"error");
    int ret= mem->get_bits(len.asint(), &v);

    handle_mem_ret_code(ret);

    return v;
}

MplValue EngineIntlFunc::peep_bits(MplValue len, MplValue p1, MplValue p2)
{
    int v;
    MemPos pos = mem->get_current_pos();  //save pos
    int ret = mem->get_bits(len.asint(), &v);
    mem->set_current_pos(pos);           //restore pos

    handle_mem_ret_code(ret);

    return v;
}

// len: string len
MplValue EngineIntlFunc::get_char(MplValue len, MplValue bits, MplValue p2)
{
    int c;
    int ret = mem->get_bits(len.asint(), &c);
    handle_mem_ret_code(ret);

    return MplValue((char)c);
}

// len: string len
MplValue EngineIntlFunc::get_wchar(MplValue len, MplValue bits, MplValue p2)
{
    int c;
    int ret = mem->get_bits(len.asint(), &c);
    handle_mem_ret_code(ret);

    return MplValue((wchar_t)c);
}



// len: string len
MplValue EngineIntlFunc::get_string(MplValue len, MplValue bits, MplValue p2)
{
    std::string s;
    int ret = mem->get_string(len.asint(), bits.asint(), &s);

    handle_mem_ret_code(ret);

    return MplValue(s);
}

// len: string len
MplValue EngineIntlFunc::get_wstring(MplValue len, MplValue bits, MplValue p2)
{
    std::wstring s;
    int ret = mem->get_wstring(len.asint(), bits.asint(), &s);

    handle_mem_ret_code(ret);

    return MplValue(s);
}


MplValue EngineIntlFunc::my_check(MplValue e, MplValue p1, MplValue p2)
{
    if (!e.asint())
    {
        RuntimeError e(err_check_failed, g->src_line_number, 0, id2str(g->src_file_id), msg.get(), p1.value.s);
        engine->emit_runtime_warning(e);
        return p1;
    }

    return 0;
}


MplValue EngineIntlFunc::my_assert(MplValue e, MplValue p1, MplValue p2)
{
    if (!e.asint())
    {
        //o_err<<"verify failed!"<<std::endl;
        std::stringstream ss;
        ss<<p1;
        throw RuntimeError(err_assert_failed, g->src_line_number, 0, id2str(g->src_file_id), msg.get(), ss.str());
    }
    return p1;
}

/*
  MplValue EngineIntlFunc::my_sizeof(MplValue e, MplValue p1, MplValue p2)
  {
  if (e.type != VT_MSG_REF)
  {
  //o_err<<"verify failed!"<<std::endl;
  throw RuntimeError(err_assert_failed, g->src_line_number, 0, id2str(g->src_file_id), msg, p1.value.s);
  }

  return e.value.msg_ref->get_subitems_count();
  }

  MplValue EngineIntlFunc::my_info(MplValue e, MplValue p1, MplValue p2)
  {
  if (!e.asint())
  {
  //o_err<<"verify failed!"<<std::endl;
  throw RuntimeError(err_assert_failed, g->src_line_number, 0, id2str(g->src_file_id), msg, p1.value.s);
  }
  return 0;
  }
*/

MplValue EngineIntlFunc::get_current_bit_pos(MplValue e, MplValue p1, MplValue p2)
{
    return mem->get_current_bit_pos();
}


MplValue EngineIntlFunc::get_current_octet_pos(MplValue e, MplValue p1, MplValue p2)
{
    return mem->get_current_pos().octet;
}

MplValue EngineIntlFunc::get_current_pos(MplValue e, MplValue p1, MplValue p2)
{
    return (mem->get_current_pos().octet<<3) + mem->get_current_bit_pos();
}

MplValue EngineIntlFunc::set_current_bit_pos(MplValue p0, MplValue p1, MplValue p2)
{
    MemPos pos = mem->get_current_pos();
    pos.bit = p0.asint() % 8;

    mem->set_current_pos(pos);

    return pos.octet;
}

MplValue EngineIntlFunc::set_current_octet_pos(MplValue p0, MplValue p1, MplValue p2)
{
    MemPos pos = mem->get_current_pos();
    pos.octet = p0.asint();
    mem->set_current_pos(pos);

    return pos.octet;
}

MplValue EngineIntlFunc::set_current_pos(MplValue p0, MplValue p1, MplValue p2)
{
    mem->set_current_pos(MemPos(p0.asint(), p1.asint()));

    return mem->get_current_pos().octet;
}


MplValue EngineIntlFunc::restore_current_pos(MplValue p0, MplValue p1, MplValue p2)
{
    mem->set_current_pos(MemPos(p0.asint()>>3, p0.asint()&0x7));

    return mem->get_current_pos().octet;
}

MplValue EngineIntlFunc::set_bits_endian(MplValue p0, MplValue p1, MplValue p2)
{
    return mem->set_bits_endian(EndianType(p0.asint()));
}
MplValue EngineIntlFunc::set_bits_endian_little(MplValue p0, MplValue p1, MplValue p2)
{
    return mem->set_bits_endian(ET_LITTLE_ENDIAN);
}
MplValue EngineIntlFunc::set_bits_endian_big(MplValue p0, MplValue p1, MplValue p2)
{
    return mem->set_bits_endian(ET_BIG_ENDIAN);
}

MplValue EngineIntlFunc::set_bytes_endian(MplValue p0, MplValue p1, MplValue p2)
{
    return mem->set_bytes_endian(EndianType(p0.asint()));
}
MplValue EngineIntlFunc::set_bytes_endian_little(MplValue p0, MplValue p1, MplValue p2)
{
    return mem->set_bytes_endian(ET_LITTLE_ENDIAN);
}
MplValue EngineIntlFunc::set_bytes_endian_big(MplValue p0, MplValue p1, MplValue p2)
{
    return mem->set_bytes_endian(ET_BIG_ENDIAN);
}

// 1) verify the new guard
// 2) set guard to mem
MplValue EngineIntlFunc::length_guard_assert(MplValue p0, MplValue p1, MplValue p2)
{
    int old_limit, new_limit;
    MsgNodePtr p;
    LengthGuardType lgt;

    new_limit = mem->get_current_pos().octet + p0.asint();

    p = msg->get_parent();
    if (p)
    {
        lgt = p->get_length_guard(&old_limit);

        if (lgt == GUARD_ASSERT)
        {
            if (old_limit < new_limit)
            {
                // invalid new guard
                // what to do?  warn and ignore? or stop the whole processing?

                std::stringstream ss;
                ss<<std::endl<<"\t"<<p->get_src_file_name()<<":"<<p->get_src_line_number()+1<< " parent msg '"<<p->get_name()<<"' has set length guard to "<<old_limit<<std::endl;
                ss<<"\t"<<msg->get_src_file_name()<<":"<<msg->get_src_line_number()+1<<" want to set it to "<<new_limit;
                throw RuntimeError(err_invalid_length_guard_assertion, g->src_line_number, 0, id2str(g->src_file_id), msg.get(), ss.str());
            }
        }
    }

    // record the new guard
    msg->set_length_guard(GUARD_ASSERT, new_limit);

    return mem->set_length_guard(GUARD_ASSERT, new_limit);
}

MplValue EngineIntlFunc::length_guard_check(MplValue p0, MplValue p1, MplValue p2)
{
    msg->set_length_guard(GUARD_CHECK, mem->get_current_pos().octet + p0.asint());
    return mem->set_length_guard(GUARD_CHECK, mem->get_current_pos().octet + p0.asint());
}


MplValue EngineIntlFunc::length_guard_cancel(MplValue p0, MplValue p1, MplValue p2)
{
    msg->set_length_guard(GUARD_NONE, 0);
    return mem->set_length_guard(GUARD_NONE, 0);
}

MplValue EngineIntlFunc::value2str(MplValue p0, MplValue p1, MplValue p2)
{
    std::stringstream ss;
    ss<<p0;
    return ss.str();
}

MplValue EngineIntlFunc::value2strhex(MplValue p0, MplValue p1, MplValue p2)
{
    std::stringstream ss;
    ss<<std::hex<<p0;
    return ss.str();
}
MplValue EngineIntlFunc::value2char(MplValue p0, MplValue p1, MplValue p2)
{
    return (char)p0.asint();
}

MplValue EngineIntlFunc::value2wchar(MplValue p0, MplValue p1, MplValue p2)
{
    return (wchar_t)p0.asint();
}

// p0 - int value
// p2 - string size
MplValue EngineIntlFunc::int_interpret_as_str(MplValue p0, MplValue p1, MplValue p2)
{
    char temp[17];
    int len = std::min(p1.asint(), 4);
    int value = p0.asint();

    // check byte order of the machine
    //unsigned short test = 1;
    //bool big_endian = (*(unsigned char*)(&test));

    if (len == 1)
    {
        char c = value;
        temp[0] = c;
        temp[1] = 0;
    }
    if (len == 2)
    {
        short c = value;
        memcpy(temp, &c, sizeof(c));
        temp[sizeof(c)] = 0;
    }
    else if (len == 4)
    {
        int c = value;
        memcpy(temp, &c, sizeof(c));
        temp[sizeof(c)] = 0;
    }

    std::string str = temp;

    return str;
}

MplValue EngineIntlFunc::my_print(MplValue p0, MplValue p1, MplValue p2)
{
	std::cout<<p0;
	return 0;
}

static const MplFunc inter_funcs[]=
{
    {"get_octets", 1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_octets},
    {"get_bits",   1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_bits},
    {"octets",    1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_octets},
    {"bits",      1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_bits},
    {"o",         1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_octets},
    {"b",         1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_bits},

    {"peep_octets", 1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::peep_octets},
    {"peep_bits",   1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::peep_bits},

    {"get_char",  1, {VT_INT, }, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_char},
    {"char",      1, {VT_INT, }, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_char},
    {"get_wchar", 1, {VT_INT, }, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_wchar},
    {"wchar",     1, {VT_INT, }, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_wchar},



    {"get_string", 2, {VT_INT, VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_string},
    {"str", 	       2, {VT_INT, VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_string},
    {"get_wstring", 2, {VT_INT, VT_INT},MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_wstring},
    {"wstr", 	       2, {VT_INT, VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_wstring},

    {"check",      2, {VT_INT, VT_STRING}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_1, &EngineIntlFunc::my_check},
    {"assert",     2, {VT_INT, VT_STRING}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_1, &EngineIntlFunc::my_assert},

    {"get_current_bit_pos",   0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_current_bit_pos},
    {"get_current_octet_pos", 0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_current_octet_pos},
    {"get_current_pos",       0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::get_current_pos},

    {"set_current_bit_pos",   1, {VT_INT, }, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_current_bit_pos},
    {"set_current_octet_pos", 1, {VT_INT, }, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_current_octet_pos},
    {"set_current_pos",       2, {VT_INT, VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_current_pos},
    {"restore_current_pos",       1, {VT_INT, }, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::restore_current_pos},

    {"set_bits_endian",       1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_bits_endian},
    {"set_bytes_endian",      1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_bytes_endian},
    {"set_bits_endian_little",       0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_bits_endian_little},
    {"set_bytes_endian_little",      0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_bytes_endian_little},
    {"set_bits_endian_big",       0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_bits_endian_big},
    {"set_bytes_endian_big",      0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::set_bytes_endian_big},

    {"length_guard_assert",      1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::length_guard_assert},
    {"length_guard_check",      1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::length_guard_check},
    {"length_guard_cancel",      0, {}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::length_guard_cancel},


    {"int_interpret_as_str",  2, {VT_INT,VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::int_interpret_as_str},
    {"tostr",               1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::value2str},
    {"tostrhex",           1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::value2strhex},
    {"tochar",               1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::value2char},
    {"towchar",               1, {VT_INT}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_ALL, &EngineIntlFunc::value2wchar},
	//{"sizeof",                1, {VT_MSG_REF}, &EngineIntlFunc::my_sizeof},
    //{"info",                  1, {VT_MSG_REF}, &EngineIntlFunc::my_info},
    {"print",               1, {VT_STRING}, MF_CHECK_PARA_NUM_EQUAL | MF_CHECK_PARA_TYPE_NO, &EngineIntlFunc::my_print},
};



/*
  check parameter number only, not their type (for function 'exist' the parameter type doesn't matter)
  return 1 plus the expected number of the function if failed
  return 0 if succeeded
*/
int  EngineIntlFunc::static_check(std::string name, int  paranum)
{
    for (unsigned int i = 0; i < __countof(inter_funcs); i++)
    {
        if (name == inter_funcs[i].name)
        {
            if (inter_funcs[i].paranum != paranum)
            {
                return inter_funcs[i].paranum + 1;
            }
            else
                return 0;
        }
    }

    return 0;
}

MplValue  EngineIntlFunc::operator () (std::string name, MplValue para_1,MplValue para_2,MplValue para_3)
{
	const MplFunc *pfunc;
	for (unsigned int i = 0; i < __countof(inter_funcs); i++)
    {
    	pfunc = &inter_funcs[i];
        if (name == pfunc->name)
        {
            //runtime type check
            if ((pfunc->check_mask & MF_CHECK_PARA_TYPE_1) && pfunc->paranum >= 1)
            {
            	if (pfunc->para_type[0] != para_1.type)
					throw RuntimeError(err_func_para_incompatible, (0<<16)+(pfunc->para_type[0]<<8)+para_1.type, 0, name);
            }
            if ((pfunc->check_mask & MF_CHECK_PARA_TYPE_2) && pfunc->paranum >= 2)
            {
            	if (pfunc->para_type[1] != para_2.type)
					throw RuntimeError(err_func_para_incompatible, (1<<16)+(pfunc->para_type[1]<<8)+para_2.type, 0, name);
            }
            if ((pfunc->check_mask & MF_CHECK_PARA_TYPE_3) && pfunc->paranum >= 3)
            {
            	if (pfunc->para_type[2] != para_3.type)
					throw RuntimeError(err_func_para_incompatible, (2<<16)+(pfunc->para_type[2]<<8)+para_3.type, 0, name);
            }

            return (this->*(inter_funcs[i].pfunc))(para_1,para_2,para_3);
        }
    }

    throw RuntimeError(err_unknown_func_name, 0, 0, name);
}

