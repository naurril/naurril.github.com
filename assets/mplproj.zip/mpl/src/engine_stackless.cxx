#include "global.h"
#include "engine_stackless.h"
#include "engine_intl_func.h"

StacklessEngine::StacklessEngine(GNode* _grammar, IRawMemory *_mem, std::ostream &_out, std::ostream &_err):
                                              Engine(_grammar, _mem, _out, _err)
{
    //current_msg_node = NULL;


}


int StacklessEngine::run(MsgNodePtr msg)
{
   return 0;


}

MplValue StacklessEngine::run_top_frame()
{
    //get top frame
    EngineFrame *frame = frame_stack.top();

    GNode *g = *(frame->continuation);
    MsgNodePtr msg = frame->msg;
    return run_gnode(g, msg);
}

int StacklessEngine::run_gnode(GNode* g, MsgNodePtr msg)
{
    MplValue v;

    switch (g->type)
    {
        case NT_INVALID:
            break;
        case NT_STMT_SEQ:
            return run_stmt_seq(g, msg);
            break;
        //case NT_SIMPLE_STMT:
        //    break;
        case NT_IF_STMT:
            return run_if_stmt(g, msg);
            break;
        case NT_WHILE_STMT:
        case NT_FOR_STMT:
            break;
        case NT_ASSIGN_STMT:
            return run_assign_stmt(g,msg);
            break;
        case NT_INTERPRET_STMT:
            return run_interpret_stmt(g, msg);
            break;
		/*
		case NT_ASSERT_STMT:
		    return run_assert_stmt(g, msg);
		    break;

		case NT_CHECK_STMT:
		    return run_check_stmt(g, msg);
		    break;
        */
        case NT_SUB_MSG_CALL:
            return run_sub_msg_call(g, msg);
            break;

        case NT_FUNC_CALL:
        case NT_OR_TEST:
        case NT_AND_TEST:
        case NT_CMP_EXP:
        case NT_ARITH_EXP:
        case NT_TERM_EXP:
        case NT_VARIABLE:
        case NT_CONST:
        case NT_QUALIFIED_NAME:    // a.b: a[1].b: a.b[1]: at least one dot
        case NT_PURE_INDEXED_NAME: // a[]: b[][][]: no bot: at least one bracket pair
        case NT_NAME: //different from dotted name
            eval_expr(g, msg);
            break;
        case NT_VNL_DEF:
        case NT_MSG_DEF:
            //runtime error!!!
            break;
		default:
		    break;
    }
    return 0;
}



//helper function
// only try to run, return error if fails, add sub-msg into *msg if succeeds
int StacklessEngine::try_sub_msg_call(GNode* g, MsgNodePtr sub_msg)
{
    return 0;
}

int StacklessEngine::run_sub_msg_call(GNode* g, MsgNodePtr msg)
{


    return 0;
}


int StacklessEngine::run_check_stmt(GNode* g, MsgNodePtr msg)
{
	MplValue v = eval_expr(g->children[0], msg);

	if (v == 0)
	{
		return err_check_failed;
	}

    return 0;
}
int StacklessEngine::run_assert_stmt(GNode* g, MsgNodePtr msg)
{



    return 0;
}



int StacklessEngine::run_assign_stmt(GNode* g, MsgNodePtr msg)
{




    return 0;
}

int StacklessEngine::run_stmt_seq(GNode* g, MsgNodePtr msg)
{
    std::vector<GNode*>::iterator ig;

    for (ig = g->children.begin(); ig != g->children.end(); ig++)
    {
        run_gnode(*ig, msg);
    }

    return 0;
}

int StacklessEngine::run_interpret_stmt(GNode* g, MsgNodePtr msg)
{

    return 0;
}

int StacklessEngine::run_if_stmt(GNode* g, MsgNodePtr msg)
{
    std::vector<Token>::iterator it;
    std::vector<GNode*>::iterator ig;
    MplValue v;

    for (it = g->tokens.begin(), ig = g->children.begin();
       it != g->tokens.end() && ig != g->children.end();
       it++,ig++)
    {
        if (*it == IF || *it == ELIF)
        {
            v = eval_expr(*ig, msg);
            if (v != 0)
            {
                run_gnode(*(ig+1), msg);
                return 0;
            }
        }

        if (*it == ELSE)
        {
            run_gnode(*ig, msg);
            return 0;
        }
    }

    return 0;
}

MplValue StacklessEngine::eval_expr(GNode* g, MsgNodePtr msg)
{
    MplValue ret;

    switch (g->type)
    {
        case NT_OR_TEST:
            ret = eval_or_exp(g, msg);
            break;
        case NT_AND_TEST:
            ret = eval_and_exp(g, msg);
            break;
        case NT_CMP_EXP:
            ret = eval_cmp_exp(g, msg);
            break;
        case NT_ARITH_EXP:
            ret = eval_arith_exp(g, msg);
            break;
        case NT_TERM_EXP:
            ret = eval_term_exp(g, msg);
            break;
        case NT_NAME:
        case NT_PURE_INDEXED_NAME:
        case NT_QUALIFIED_NAME:
            ret =  eval_qualified_name(g, msg);
            break; //TBC

        case NT_CONST:
            ret = g->value;
            break;
        case NT_FUNC_CALL:
            ret = eval_func_call(g, msg);
            break;
        default:
            break;
    }

    //o_out<<"expr eval: "<<ret<<std::endl;
    return ret;
    // or - exp
}

MplValue StacklessEngine::eval_qualified_name(GNode* g, MsgNodePtr msg)
{

    return 0;
}


MsgNodePtr StacklessEngine::locate_msg_by_qualified_name(GNode* name, MsgNodePtr starting_msg)
{


    return 0;
}


MplValue StacklessEngine::eval_or_exp(GNode* g, MsgNodePtr msg)
{


    return 0; //false
}
MplValue StacklessEngine::eval_and_exp(GNode* g, MsgNodePtr msg)
{


    return 1;
}

MplValue StacklessEngine::eval_cmp_exp(GNode* g, MsgNodePtr msg)
{

    return 0;
}
MplValue StacklessEngine::eval_arith_exp(GNode* g, MsgNodePtr msg)
{
    return 0;
}

MplValue StacklessEngine::eval_term_exp(GNode* g, MsgNodePtr msg)
{
    MplValue v;
    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator iop;
    v = eval_expr(g->children[0], msg);
    for (iop = g->tokens.begin(), i = g->children.begin()+1;
         iop != g->tokens.end()  && i != g->children.end();
         iop++, i++)
    {
        switch (*iop)
        {
            case MUL:
                v *= eval_expr(*i, msg);
                break;
            case DIV:
                v /= eval_expr(*i, msg);
                break;
            case MOD:
                v %= eval_expr(*i, msg);
            default:
                //TBC
                break;
        }
    }
    return v;
}




MplValue StacklessEngine::eval_func_call(GNode* g, MsgNodePtr msg)
{
    return 0;
}


