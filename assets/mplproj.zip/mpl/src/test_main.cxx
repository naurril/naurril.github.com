
//test shared ptr
#include <iostream>
#include <sstream>
#include "global.h"
#include "shared_ptr.h"
#include "code.h"
#include "flat_memory.h"
#include "engine_cstack_based.h"
#include "rt_msg_ui.h"
#include "settings.h"


/**************************************************************
SharedPtr class tests
**************************************************************/
class TestedClass
{
public:
    TestedClass(){}
    virtual ~TestedClass(){}
    virtual int release()=0;
    virtual int add_ref()=0;
    virtual int get_ref()=0;

    virtual int func() = 0;
    virtual int vfunc() = 0;
};
class TestedClassDerived:public TestedClass
{
public:
    TestedClassDerived(const char* _name):ref(0),name(_name)
    {
        counter++;
    }
    virtual ~TestedClassDerived()
    {
        counter--;
    }
    int release()
    {
        //std::cerr<<"release testedclass "<<name<<" "<<ref<<std::endl;
        return --ref;
    }
    int add_ref()
    {
        //std::cerr<<"add ref testedclass "<<name<<" "<<ref<<std::endl;
        return ++ref;
    }
    int get_ref()
    {
        return ref;
    }

    int func()
    {
        return 0;
    }
    virtual int vfunc()
    {
        return 0;
    }

public:
    static int counter;
private:
    int ref;
    const char *name;
};

class TestedClassDerived2:public TestedClass
{
public:
    TestedClassDerived2(const char* _name){}
    virtual int vfunc()
    {
        return 1;
    }
};

int TestedClassDerived::counter=0;

SharedPtr<TestedClass> test_shared_ptr_2(SharedPtr<TestedClass> x)
{
    //SharedPtr<TestedClass> a(new TestedClassDerived("test-shared-ptr-2-a"));
    return x;
}
SharedPtr<TestedClass> test_shared_ptr_3(SharedPtr<TestedClass> x)
{
    //SharedPtr<TestedClass> a(new TestedClassDerived("test-shared-ptr-3-a"));
    //return a;
    return test_shared_ptr_2(x);
}
int test_shared_ptr()
{
    {
        SharedPtr<TestedClass> a(new TestedClassDerived("a"));
        SharedPtr<TestedClass> b(new TestedClassDerived("b"));
        SharedPtr<TestedClass> c(new TestedClassDerived("c"));
        SharedPtr<TestedClass> d(new TestedClassDerived("d"));
        a = b;
        a = c;
        SharedPtr<TestedClass> e = c;

        test_shared_ptr_2(a);
        c = test_shared_ptr_2(d);
        d = 0;
        c->func();

        SharedPtr<TestedClass> f(0);
        f = new TestedClassDerived("f");
    }

    {
        //std::cout<<"test operator=="<<std::endl;
        SharedPtr<TestedClass> a(new TestedClassDerived("xxxa"));
        SharedPtr<TestedClass> b(new TestedClassDerived("xxxb"));
        a = b;
        TestedClass *q = a.get();
        TestedClass *p = a.release();
        q->func();
        b.release();
        delete p;
    }

    return 0;
}

int test_shared_ptr2()
{
    SharedPtr<TestedClass> a(new TestedClassDerived("test-a"));
    test_shared_ptr_3(a);
    return 0;
}

int test_shared_ptr_operator_eq()
{
    SharedPtr<TestedClass> x(0);
    if (x)
        std::cout<<"SharedPtr::operator bool test failed"<<std::endl;

    SharedPtr<TestedClass> x1(new TestedClassDerived("helo"));
    if (!x1)
        std::cout<<"SharedPtr::operator bool test failed"<<std::endl;
    return 0;
}

int testcases_shared_ptr()
{
    test_shared_ptr();
    test_shared_ptr2();
    test_shared_ptr_operator_eq();

    if (TestedClassDerived::counter != 0)
        std::cout<<"test shared ptr failed: counter = "<<TestedClassDerived::counter<<std::endl;
    else
        std::cout<<"shared_ptr tests passed!"<<std::endl;

    return 0;
}



/**************************************************************
MPL self tests
**************************************************************/
struct TestCase
{
    int lineno;
    int options_num;
    const char* options[10];
    const char* source_input;
    const char* mem_input;
    const char* compile_output;
    const char* compile_error;
    const char* runtime_output;
    const char* runtime_error;
    const char* msg_output;
    int compile_err_num, compile_warn_num;
    int runtime_err_num, runtime_warn_num;

};


//pending testcases
// restart, end... line commands
TestCase test_cases[]=
{
        // test automatic value interpretation
    {
        __LINE__,
        1, {"mpl",},
        "a = 5\n"
        "vnldef a:\n"
        "   5: \"five\"\n"
        "fixed(3) submsg\n"
        "msgdef submsg:\n"
        "  x=o(1)\n"
        "  vnldef x:\n"
        "    1: \"one\"\n"
        "    2: \"two\"\n"
        "    default: \"unknown: \"+__vnl_value__\n",
        "1,2,3", //mem
        "",
        "",
        "",
        "",
        "0:0-0:0  ........ ........  +-a: 5: five\n"
        "0:0-3:0                     +-submsg\n"
        "0:0-1:0                       +-[0]\n"
        "0:0-1:0  00000001 ........    | +-x: 1: one\n"
        "1:0-2:0                       +-[1]\n"
        "1:0-2:0  ........ 00000010    | +-x: 2: two\n"
        "2:0-3:0                       +-[2]\n"
        "2:0-3:0  00000011 ........      +-x: 3: unknown: 3\n",

        0,0,
        0,0,
    },

    // test automatic value interpretation
    {
        __LINE__,
        1, {"mpl",},
        "a = 5\n"
        "vnldef a:\n"
        "   5: \"five\"\n"
        "fixed(3) submsg\n"
        "msgdef submsg:\n"
        "  x=o(1)\n"
        "  vnldef x:\n"
        "    1: \"one\"\n"
        "    2: \"two\"\n"
        "    default: \"unknown!\"\n",
        "1,2,3", //mem
        "",
        "",
        "",
        "",
        "0:0-0:0  ........ ........  +-a: 5: five\n"
        "0:0-3:0                     +-submsg\n"
        "0:0-1:0                       +-[0]\n"
        "0:0-1:0  00000001 ........    | +-x: 1: one\n"
        "1:0-2:0                       +-[1]\n"
        "1:0-2:0  ........ 00000010    | +-x: 2: two\n"
        "2:0-3:0                       +-[2]\n"
        "2:0-3:0  00000011 ........      +-x: 3: unknown!\n",

        0,0,
        0,0,
    },

    // test start&end position of fixed-num-item msg
    {
        __LINE__,
        1, {"mpl",},
        "fixed(2) submsg\n"
        "msgdef submsg:\n"
        "   i=o(1)\n",
        "0x01,0x02", //mem
        "",
        "",
        "",
        "",

        "0:0-2:0                     +-submsg\n"
        "0:0-1:0                       +-[0]\n"
        "0:0-1:0  00000001 ........    | +-i: 1\n"
        "1:0-2:0                       +-[1]\n"
        "1:0-2:0  ........ 00000010      +-i: 2\n",
        0,0,
        0,0,
    },

    // test start&end position of multiple-num-item msg
    {
        __LINE__,
        1, {"mpl",},
        "multiple(2) submsg\n"
        "msgdef submsg:\n"
        "   i=o(1)\n",
        "0x01,0x02,03", //mem
        "",
        "",
        "",
        "",

        "0:0-3:0                     +-submsg\n"
        "0:0-1:0                       +-[0]\n"
        "0:0-1:0  00000001 ........    | +-i: 1\n"
        "1:0-2:0                       +-[1]\n"
        "1:0-2:0  ........ 00000010    | +-i: 2\n"
        "2:0-3:0                       +-[2]\n"
        "2:0-3:0  00000011 ........      +-i: 3\n",
        0,0,
        0,0,
    },

    {
        __LINE__,
        3, {"mpl", "--no-0x","-x",},
        "x=octets(2)\n"
        "y=octets(2)\n"
        "z=octets(2)\n"
        "a=octets(2)\n"
        ,
        "x000 11 00 ff y000 FF aa bb Cc DD ",  //invalid-char started string are all filtered
        "",
        "",
        "",
        "",
        "0:0-2:0  00010001 00000000  +-x: 0x1100\n"
        "2:0-4:0  11111111 11111111  +-y: 0xffff\n"
        "4:0-6:0  10101010 10111011  +-z: 0xaabb\n"
        "6:0-8:0  11001100 11011101  +-a: 0xccdd\n",
        0,0,
        0,0,
    },

    {
        __LINE__,
        3, {"mpl", "--no-0x","-x",},
        "x=octets(2)\n"
        "y=octets(2)\n"
        "z=octets(2)\n"
        "a=octets(2)\n"
        ,
        "x000 1100ff y000 FFaabb Cc DDee ",  //invalid-char started string are all filtered
        "",
        "",
        "",
        "",
        "0:0-2:0  00010001 00000000  +-x: 0x1100\n"
        "2:0-4:0  11111111 11111111  +-y: 0xffff\n"
        "4:0-6:0  10101010 10111011  +-z: 0xaabb\n"
        "6:0-8:0  11001100 11011101  +-a: 0xccdd\n",
        0,0,
        0,0,
    },

    {
        __LINE__,
        0, {""},
        "x=5",
        "",
        "",
        "",
        "",
        "",
        "0:0-0:0  ........ ........  +-x: 5\n",
        0,0,
        0,0,
    },

    {
        __LINE__,
        0, {""},
        "x=octets(1)",
        "0",
        "",
        "",
        "",
        "",
        "0:0-1:0  00000000 ........  +-x: 0\n",
        0,0,
        0,0,
    },



    {
        __LINE__,
        0, {""},
        ",x=0",
        "",
        "",
        "mplcode> <stdin>:1:1: error(4): expect IDENTIFIER while encountering ','\n",
        "",
        "",
        "0:0-0:0  ........ ........  +-x: 0\n",
        1,0,
        0,0,
    },


    {
        __LINE__,
        0, {""},
        "#print out unfinished message to assist problem disgnose\n"
        "testcase_msg_output #moved to internal test\n"
        "msgdef testcase_msg_output:\n"
        "  msgdef msg:\n"
        "    x = 1\n"
        "    y = 2\n"
        "    assert(y == 3, \"assert\")\n"
        "    z = 3\n"
        "  msg()\n"
        "  #fixed(2) msg()\n"
        "  #multiple(1) msg()\n"
        "  #x = msg()\n",

        "",

        "",
        "",
        "",
        "mplengine> <stdin>:7 error (104): assertion failed: assert\n"
        "\t\tcalled from <stdin>:9;\n"
        "\t\tcalled from <stdin>:2;\n"
        "\t\tcalled from stdin:0;\n",

        //msg otuput
        "0:0-0:0                     +-testcase_msg_output\n"
        "0:0-0:0                       +-msg\n"
        "0:0-0:0  ........ ........      +-x: 1\n"
        "0:0-0:0  ........ ........      +-y: 2\n",

        0,0,
        1,0,

    },

    {
        __LINE__,
        0, {""},
        "#print out unfinished message to assist problem disgnose\n"
        "testcase_msg_output #moved to internal test\n"
        "msgdef testcase_msg_output:\n"
        "  msgdef msg:\n"
        "    x = 1\n"
        "    y = 2\n"
        "    assert(y == 3, \"assert\")\n"
        "    z = 3\n"
        "  #msg()\n"
        "  fixed(2) msg()\n"
        "  #multiple(1) msg()\n"
        "  #x = msg()\n",

        "",
        "",
        "",
        "",
        "mplengine> <stdin>:7 error (104): assertion failed: assert\n"
        "\t\tcalled from <stdin>:10;\n"
        "\t\tcalled from <stdin>:10;\n"
        "\t\tcalled from <stdin>:2;\n"
        "\t\tcalled from stdin:0;\n",

        //msg otuput
        "0:0-0:0                     +-testcase_msg_output\n"
        "0:0-0:0                       +-msg\n"
        "0:0-0:0                         +-[0]\n"
        "0:0-0:0  ........ ........        +-x: 1\n"
        "0:0-0:0  ........ ........        +-y: 2\n",

        0,0,
        1,0,
    },

    //test deadloop
    {
        __LINE__,
        5, {"mpl", "-d", "--max-msg-level", "10", "--print-msg-only"},
        "msgdef xxx:\n"
        "	a = 10\n"
        "	yyy\n"
        "xxx\n"
        "msgdef yyy:\n"
        "	@xxx.a = xxx()\n"
        "	#xxx()\n"
        "yyy\n"
        "y=xxx.a\n",

        "", // no mem

        "mplcode> source file: <stdin> opened!\n"
		"mplcode> source file: <stdin> closed!\n",

        "",
        "",
        "mplengine> <stdin>:6 error (122): suspicious deadloop detected.\n",
        " +-xxx(Bb)\n"
		"   +-a(i)(Bb): (non_type)unknown type!!\n"
		"   +-yyy(Bb)\n"
		"     +-xxx(Bb)\n"
		"       +-a(i)(Bb): (non_type)unknown type!!\n"
		"       +-yyy(Bb)\n"
		"         +-xxx(Bb)\n"
		"           +-a(i)(Bb): (non_type)unknown type!!\n"
		"           +-yyy(Bb)\n"
		"             +-xxx(Bb)\n"
		"               +-a(i)(Bb): (non_type)unknown type!!\n"
		"               +-yyy(Bb)\n"
		"                 +-xxx(Bb)\n"
		"                   +-a(Bb): (int)10\n"
		"                   +-yyy(Bb)\n",
        0,0,
        1,0,
    },


	//test divide by zero
    {
        __LINE__,
        2, {"mpl", "--print-msg-only"},
        "x = 5/0\n",
        "", // no mem

        "",
        "",

        "",
        "mplengine> <stdin>:1 error (128): divide by zero.\n"
        "\t\tcalled from stdin:0;\n",

        " +-x: unknown type!!\n",
        0,0,
        1,0,
    },

    //test -u
    {
        __LINE__,
        4, {"mpl", "-u", "--print-msg-only", "-n"},  //options
        "this_is_a_test = 0\n"
        "interpret this_is_a_test:\"ok\"\n",
        "", // no mem

        "", "",//compile output, error
        "", "",//runtime output, error
        " +-this is a test: 0: ok\n", //message output
        0,0,
        0,0,
    },

    //test -u
    {
        __LINE__,
        4, {"mpl", "-u", "--print-msg-only", "-n"},  //options
        "msgdef testcase_continue:\n"
		"    continue;\n",
        "", // no mem

        "",
        "mplcode> <stdin>:2:12: error(117): unexpected 'continue'\n",//compile output, error
        "", "",//runtime output, error
        " +-this is a test: 0: ok\n", //message output
        1,0,
        0,0,
    },


};
int test_mpl()
{
    std::cout<<"********************************"<<std::endl;
    std::cout<<"* Starting MPL self-tests"<<std::endl;
    std::cout<<"********************************"<<std::endl;


    int error_count = 0;

    for (unsigned int i = 0; i < __countof(test_cases); i++)
    {
        bool pass = true;
        std::cout<<"----"<<std::endl;
        std::cout<<"testing testcase "<<i<<"..."<<std::endl;

        // compile
        std::stringstream compile_output;
        std::stringstream compile_error;
		get_global_settings()->reset();
		get_global_settings()->cmd_line_parse(test_cases[i].options_num, test_cases[i].options);
        MplCode code(compile_output, compile_error);
        GNode *g = code.parse(test_cases[i].source_input, MplCode::INPUT_STRING);

        if (test_cases[i].compile_output != compile_output.str())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected output"<<std::endl;
            std::cout<<"expect:"<<std::endl;
            std::cout<<test_cases[i].compile_output<<std::endl;
            std::cout<<"got:"<<std::endl;
            std::cout<<compile_output.str()<<std::endl;
            pass = false;
        }

        if (test_cases[i].compile_error != compile_error.str())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected error information"<<std::endl;
            std::cout<<"expect:"<<std::endl;
            std::cout<<test_cases[i].compile_error<<std::endl;
            std::cout<<"got:"<<std::endl;
            std::cout<<compile_error.str()<<std::endl;
            pass = false;
        }

        if (test_cases[i].compile_err_num != code.get_errors())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected compile errors"<<std::endl;
            std::cout<<"expect:"<<test_cases[i].compile_err_num<<std::endl;
            std::cout<<"got:"<<code.get_errors()<<std::endl;
            pass = false;
        }
        if (test_cases[i].compile_warn_num != code.get_warnings())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected compile warnings"<<std::endl;
            std::cout<<"expect:"<<test_cases[i].compile_warn_num<<std::endl;
            std::cout<<"got:"<<code.get_warnings()<<std::endl;
            pass = false;
        }

        if (test_cases[i].compile_err_num !=0)
            continue;

        if (!g)
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: compiling expected to succeed"<<std::endl;
            pass = false;
            continue;
        }

        //run
        std::stringstream msg_output;
        std::stringstream runtime_output;
        std::stringstream runtime_error;
        int runtime_err_num;
        FlatMemory mem(test_cases[i].mem_input);

        CStackBasedEngine e(g, &mem, runtime_output, runtime_error);
        MsgNodePtr msg(new RtMsgNode(MNT_NODE, 0, STR_ID_STDIN, -1 ));
        runtime_err_num = e.run(msg);

        if (get_global_settings()->hex)  // set output format, 19Jul2010, lie
            msg_output<<std::hex;
        else
            msg_output<<std::dec;

        print_msg_text_layout(msg_output, msg, &mem);


        if (test_cases[i].runtime_output != runtime_output.str())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected runtime output"<<std::endl;
            std::cout<<"expect:"<<std::endl;
            std::cout<<test_cases[i].runtime_output<<std::endl;
            std::cout<<"got:"<<std::endl;
            std::cout<<runtime_output.str()<<std::endl;
            pass = false;
        }
        if (test_cases[i].runtime_error != runtime_error.str())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected runtime error"<<std::endl;
            std::cout<<"expect:"<<std::endl;
            std::cout<<test_cases[i].runtime_error<<std::endl;
            std::cout<<"got:"<<std::endl;
            std::cout<<runtime_error.str()<<std::endl;
            pass = false;
        }

        if (test_cases[i].runtime_err_num != runtime_err_num)
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected runtime errors"<<std::endl;
            std::cout<<"expect:"<<test_cases[i].runtime_err_num<<std::endl;
            std::cout<<"got:"<<runtime_err_num<<std::endl;
            pass = false;
        }
        if (test_cases[i].runtime_warn_num != e.get_warnings())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected runtime warnings"<<std::endl;
            std::cout<<"expect:"<<test_cases[i].runtime_warn_num<<std::endl;
            std::cout<<"got:"<<e.get_warnings()<<std::endl;
            pass = false;
        }
        if (test_cases[i].msg_output != msg_output.str())
        {
            std::cout<<"testcase "<<i<<"(line"<<test_cases[i].lineno<<") failed: unexpected message output"<<std::endl;
            std::cout<<"expect:"<<std::endl;
            std::cout<<test_cases[i].msg_output<<std::endl;
            std::cout<<"got:"<<std::endl;
            std::cout<<msg_output.str()<<std::endl;
            pass = false;
        }


        if (!pass)
            error_count++;
    }

    std::cout<<"********************************"<<std::endl;
    if (error_count)
        std::cout<<"* "<<error_count<<" MPL tests failed!"<<std::endl;
    else
        std::cout<<"All MPL self-tests passed!"<<std::endl;
    std::cout<<"********************************"<<std::endl;

    return error_count;
}

int test()
{
	int ret;
    ret = testcases_shared_ptr();
    if (ret) return ret;

    ret = test_mpl();
	if (ret) return ret;

    return 0;
}

int main()
{
    return test();
}
