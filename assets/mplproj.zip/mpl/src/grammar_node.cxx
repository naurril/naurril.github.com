#include <iostream>
#include <sstream>
#include <memory>
#include "grammar_node.h"

#include "global.h"
#include "error.h"

int GNode:: node_count = 0;

GNode::GNode(NodeType _type, std::string _name, STR_ID _file_id, int _src_line, GNode* _p):
    type(_type),
    name(_name),
    src_file_id(_file_id),
    src_line_number(_src_line),
    parent(_p)
{
    layer = 0;
    value = 0;
    vnl_default_handler = 0;
    vsl_default_handler = 0;
    node_count++;
    attr = 0;
    ref_count=0;
}

GNode::~GNode()
{
    for (std::vector<GNode*>::iterator i = children.begin(); i != children.end(); i++)
        delete *i;


    for (GNode::MSG_MAP::iterator i = sub_defs.begin(); i != sub_defs.end(); i++)
        delete i->second;

    if (vnl_default_handler != 0)
        delete vnl_default_handler;

    if (vsl_default_handler != 0)
	delete vsl_default_handler;

//TBC release vsl-statements

    node_count--;
}

void GNode::set_position(STR_ID file_id, int src_line)
{
    src_file_id = file_id;
    src_line_number = src_line;
}

const char* TokenName[] =
{
    "UNKNOWN",
    "PHONY_STUB",
    "ADD", "SUB",
    "MUL", "DIV", "MOD",
    "AND", "OR", "NOT(\'!\')",
    "BIT_OR", "BIT_AND", "BIT_XOR",
    "DOT","AT",
    "LEFT_BRACKET", "RIGHT_BRACKET", //[]

    "END_MARKER",
    "IMPORT",
    "\':\'", "\';\'", "\',\'",  //"COLON", "SEMICOLON", "COMMA"
    "\'(\'", "\')\'",  //( )

    //"LEFT_BRACE", "RIGHT_BRACE", // {}

    //"LITERAL_STRING",
    "\'vnldef\'", "\'msgdef\'","\'funcdef\'",     //def
    "INDENT",  "DEDENT",
    //"DOTTED_NAME",
    "IDENTIFIER",//"NAME",
    //"NUMBER",
    "CONST",
    "OPTIONAL",
    "FIXED",
    "MULTIPLE",
    "NOP",
    "IF",  "ELIF",  "ELSE",
    "FOR", "WHILE", "TRY_LOOP",
    "RETURN",
    "BREAK", "CONTINUE",
    "DEFAULT",

    //"ASSERT", "CHECK",
    "STRING",
    "ASSIGN (\'=\')",
    "LESS_THAN", "GREATER_THAN", "EQUAL", "NOT_EQUAL", "LESS_OR_EQUAL", "GREATER_OR_EQUAL",
    "INTERPRET","RUN_SWITCH",
    "INTERNAL_NAME",
    "MPL_BIG_ENDIAN",
    "MPL_LITTLE_ENDIAN",
};

const char* token2Name(Token token)
{
    if ((unsigned int)token < __countof(TokenName))
        return TokenName[token];
    else
        return TokenName[0];
}

const char* NodeTypeName[] =
{

    "NT_INVALID",
    "NT_IMPORT_STMT",
    "NT_STMT_SEQ",
    //"NT_SIMPLE_STMT",
    "NT_IF_STMT",
    "NT_WHILE_STMT",
    "NT_FOR_STMT",
    "NT_TRY_LOOP",
    "NT_INTERPRET_STMT",
    "NT_RUNSWITCH_STMT",
    "NT_ASSIGN_STMT",
    "NT_SUB_MSG_CALL",
    "NT_FUNC_CALL",
    //"NT_ASSERT_STMT",
    //"NT_CHECK_STMT",
    "NT_RETURN_STMT",
    "NT_BREAK_STMT",
    "NT_CONTINUE_STMT",
    "NT_OR_TEST",
    "NT_AND_TEST",
    "NT_CMP_EXP",
    "NT_ARITH_EXP",
    "NT_TERM_EXP",
    "NT_UNARY_EXP",
    "NT_VARIABLE",
    "NT_CONST",
    "NT_QUALIFIED_NAME",    // a.b", a[1].b", a.b[1]", at least one dot
    "NT_PURE_INDEXED_NAME", // a[]", b[][][]", no bot", at least one bracket pair
    "NT_NAME", //different from dotted name
    // special
    "NT_FIXED_SPECIFIER",
    "NT_OPTIONAL_SPECIFIER",
    "NT_MULTIPLE_SPECIFIER",
    "NT_VNL_DEF",
    "NT_MSG_DEF",
    "NT_FUNC_DEF",
    "NT_PARA_LIST",
};


std::ostream& operator << (std::ostream& o, GNode *p)
{
    std::stringstream ss;
    ss <<id2str(p->src_file_id)<<"("<<p->src_line_number + 1 << ")";
    if (p->parent)
        p->layer = p->parent->layer + 1;
    for (int tmp = 0; tmp < p->layer; tmp++)
    {
        ss << " | ";
    }

    //print name, if it's dotted name, print them all
    o << ss.str() << NodeTypeName[p->type] <<":";
    o << p->name;
    if (p->attr)
    {
    	o <<'(';
	if (p->attr & NA_HIDDEN)
	    o << 'H';
	if (p->attr & NA_NON_LOCAL)
	    o << 'N';
	o <<')';
    }

    if (p->type == NT_CONST)
        o <<":"<< p->value;

#if 0
    if (p->type == NT_QUALIFIED_NAME)
    {
        for (std::vector<std::string>::iterator i = p->qualified_name.begin();
	     i != p->qualified_name.end(); i++)
        {
            o <<"."<<*i;
        }
    }
#endif

    o <<std::endl;

    if (p->tokens.size())
    {
        o << ss.str() <<" +-"<< "tokens: ";
        for (std::vector<Token>::iterator i = p->tokens.begin(); i != p->tokens.end(); i++)
            o << token2Name(*i)<<",";
        o << std::endl;
    }

    /*
      if (p->stmts.size())
      {
      o << header <<" +-"<< "stmts: "<<std::endl;
      for (std::vector<GNode*>::iterator i = p->stmts.begin(); i != p->stmts.end(); i++)
      o << *i;
      } */

    if (p->children.size())
    {
        o << ss.str() <<" +-"<< "children: "<<std::endl;
        for (std::vector<GNode*>::iterator i = p->children.begin(); i != p->children.end(); i++)
            o << *i;
    }

    /*
      if (p->vnls.size())
      {
      o << ss.str() <<" +-"<<"value-name-lists:"<<std::endl;
      for (GNode::VNL_MAP::iterator i = p->vnls.begin(); i != p->vnls.end(); i++)
      {
      o<< (*i).second;
      }
      }
    */


    if (p->vnl.size())
    {
        o << ss.str() <<" +-"<<"value-name-pairs:"<<std::endl;
        for (GNode::VNL::iterator i = p->vnl.begin(); i != p->vnl.end(); i++)
        {
            o<< ss.str() << " | " << " +-"<<(*i).first<<":"<<(*i).second<<std::endl;
        }
    }

    if (p->vnl_default_handler)
        o<<p->vnl_default_handler;

    if (p->vsl.size())
    {
        o << ss.str() <<" +-"<<"value-statement-pairs:"<<std::endl;
        for (GNode::VSL::iterator i = p->vsl.begin(); i != p->vsl.end(); i++)
        {
            o<< ss.str() << " | " << " +-"<<(*i).first<<":";
	    o<<std::endl<<(*i).second;//<<std::endl;, (*i).second has already printed a \n
        }
    }

    if (p->vsl_default_handler)
        o<<p->vsl_default_handler;


    if (p->sub_defs.size())
    {
        o << ss.str() <<" +-"<<"sub_defs:"<<std::endl;
        for (GNode::MSG_MAP::iterator i = p->sub_defs.begin(); i != p->sub_defs.end(); i++)
        {
            o<< (*i).second;
        }
    }

    //o << ss.str() << "+- parent" << (int) p->parent<<std::endl;

    return o;
}

std::string GNode::get_target_name()
{
	std::vector<Token>::iterator i ;
    std::vector<GNode*>::iterator j;
    std::string ret;

    switch(type)
    {
    case NT_NAME:
        ret = name;
        break;
    case NT_QUALIFIED_NAME:    // a.b, a[1].b, a.b[1], at least one dot
    case NT_PURE_INDEXED_NAME: // a[], b[][][], no bot, at least one bracket pair
        ret = name;
        if (tokens.size())
        {
            for (i = tokens.begin(), j = children.begin();
				i != tokens.end(), j!=children.end(); i++,j++)
            {
                if (*i == DOT)
                {
                    ret = (*j)->name;
                }
                else if (*i == LEFT_BRACKET)
                {
                    ret = (*j)->name;
                }
            }
        }
        break;
	case NT_FUNC_CALL:
    case NT_SUB_MSG_CALL:
        if (IS_SPECIFIER(children[0]->type))
            ret = children[1]->get_target_name();
        else
            ret = children[0]->get_target_name();
        break;

    default:
        ret = name;
        break;
    }

    return ret;
}

std::string GNode::get_full_name()
{
    std::vector<Token>::iterator i ;
    std::vector<GNode*>::iterator j;
    std::string ret;

    switch(type)
    {
    case NT_QUALIFIED_NAME:    // a.b, a[1].b, a.b[1], at least one dot
    case NT_PURE_INDEXED_NAME: // a[], b[][][], no bot, at least one bracket pair
    case NT_NAME:
        ret = name;
        if (tokens.size())
        {
            for (i = tokens.begin(), j = children.begin();
				i != tokens.end(), j!=children.end(); i++,j++)
            {
                if (*i == DOT)
                {
                    ret += ".";
                    ret += (*j)->name;
                }
                else if (*i == LEFT_BRACKET)
                {
                    ret += "[";
                    ret += (*j)->name;
                    ret += "]";
                }
            }
        }
        break;

	case NT_FUNC_CALL:
    case NT_SUB_MSG_CALL:
        if (IS_SPECIFIER(children[0]->type))
            ret = children[1]->get_full_name();
        else
            ret = children[0]->get_full_name();
        break;
    default:
        ret = name;
        break;
    }

    return ret;
}


int GNode::add_node(GNode *p)
{
    MSG_MAP::iterator i;
    //char tmpbuf[16];
    std::string es;

    if (p == NULL)
    {
        return err_null_pointer;
    }

    if (p->parent && p->parent != this)
    {
	std::cerr<<"incorrent parent assignment found!"<<std::endl;
    }
    p->parent = this;

    switch (p->type)
    {
    case NT_MSG_DEF:
    case NT_VNL_DEF:
    case NT_FUNC_DEF:
	// check repetition
	i = sub_defs.find(p->name);
	if (i == sub_defs.end())
	{
	    // not found
	    sub_defs[p->name] = p;
	}
	else
	{
	    /*
	      std::stringstream ss;
	      ss<<"\tcurrently defined in "<<p->src_file_name<<":"<<p->src_line_number + 1<<std::endl;
	      ss<<"\tpreviously defined in "<<i->second->src_file_name<<":"<<i->second->src_line_number + 1<<std::endl;
	      std::string name = p->name;
	    */
	    delete p;

	    // the error info has already been emitted
	    //CompileError e(err_name_confliction, 0, 0, name, 0, ss.str());
	    //emit_compile_err_info(e);
	    //throw e;
	    //return err_name_confliction;
	}
	break;
    default:
	children.push_back(p);
	break;
    }

    return 0;
}



NameTokenPair reserved_words[] =
{
    {"if", IF},
    {"elif", ELIF},
    {"else", ELSE},
    {"optional", OPTIONAL},
    {"for", FOR},
    {"while", WHILE},
    {"try_loop", TRY_LOOP},
    {"and", AND},
    {"or", OR},
    {"not", NOT},
    {"vnldef", VNL_DEF},
    {"msgdef", MSG_DEF},
    {"funcdef", FUNC_DEF},
    {"interpret", INTERPRET},
    {"runswitch", RUN_SWITCH},
    {"optional", OPTIONAL},
    {"fixed", FIXED},
    {"multiple", MULTIPLE},
    {"return", RETURN},
    {"break", BREAK},
    {"continue", CONTINUE},
    {"default", DEFAULT},
    //{"assert", ASSERT},
    //{"check", CHECK},
    {"import", IMPORT},
    {"string", STRING},

    {"__name__", INTERNAL_NAME},
    {"__big_endian__", MPL_BIG_ENDIAN},
    {"__little_endian__", MPL_LITTLE_ENDIAN},

};

Token str2token(std::string name)
{
    for (unsigned int i = 0; i < __countof(reserved_words); i++)
    {
        if (name == reserved_words[i].name)
        {
            return reserved_words[i].token;
        }
    }
    return NAME;
}


GNode* GNode::locate_subdef_node_by_name(std::string name)
{
    GNode* p; //find in this node
    p = this;
    MSG_MAP::iterator i;

    i = p->sub_defs.find(name);

    if (i != p->sub_defs.end())
    {
        return i->second;
    }

    return NULL;
}
/*
  seach only name of submsg-node
*/
GNode* GNode::locate_subdef_node(GNode* g)
{
    GNode* p; //find in this node
    p = this;
    MSG_MAP::iterator i;

    while (p)
    {
        i = p->sub_defs.find(g->name);

        if (i != p->sub_defs.end())
        {
            p = i->second;
            break;
        }

        p = p->parent;
    }

    if (p == NULL)
    {
        return p;
    }

    for (std::vector<GNode*>::iterator i_name = g->children.begin();
	 i_name!= g->children.end(); i_name++)
    {
        i = p->sub_defs.find((*i_name)->name);

        if (i != p->sub_defs.end())
        {
            p = i->second;
        }
        else
        {
            p = NULL;
            break;
        }
    }



    return p;
}
