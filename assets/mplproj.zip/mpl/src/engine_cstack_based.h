#ifndef _MPL_STACK_BASED_ENGINE_H
#define _MPL_STACK_BASED_ENGINE_H

#include "engine.h"

class UnwindingStackHelper;
class InterpretHelper;

class CStackBasedEngine: public Engine
{
public:
    CStackBasedEngine(GNode* _grammar, IRawMemory *_mem, std::ostream &_out = std::cout, std::ostream &_err = std::cerr);
    int run(MsgNodePtr msg);
    virtual ~CStackBasedEngine(){}
    int get_warnings()const {return total_warnings;}



protected:
    //MsgNodePtr get_msg() {return &top_msg_node; }



    int runtime_assert(bool expr, GNode* g, MsgNodePtr msg, const std::string &info);
    int run_gnode(GNode* g, MsgNodePtr msg);
    int run_if_stmt(GNode* g, MsgNodePtr msg);
    int run_while_stmt(GNode *g, MsgNodePtr msg);
    int run_try_loop_stmt(GNode *g, MsgNodePtr msg);
    int run_assign_stmt(GNode* g, MsgNodePtr msg);
    int run_stmt_seq(GNode* g, MsgNodePtr msg);
    int run_interpret_stmt(GNode* g, MsgNodePtr msg);
    int run_runswitch_stmt(GNode* g, MsgNodePtr msg);
    int run_assert_stmt(GNode* g, MsgNodePtr msg);
    int run_check_stmt(GNode* g, MsgNodePtr msg);

    int build_msg_body(GNode* g, MsgNodePtr msg);
    int run_sub_msg_call(GNode* g, MsgNodePtr msg, MsgNodePtr * generated_msg);
    int run_optional_msg_call(GNode* g, MsgNodePtr msg, MsgNodePtr * generated_msg);
    int run_fixed_msg_call(MplValue spc_para, GNode* g, MsgNodePtr msg, MsgNodePtr * generated_msg);
    int run_multiple_msg_call(MplValue spc_para, GNode* g, MsgNodePtr msg, MsgNodePtr * generated_msg);
    int try_sub_msg_call(GNode* g, MsgNodePtr sub_msg);

    int run_return_stmt(GNode* g, MsgNodePtr msg);
	int run_break_stmt(GNode* g, MsgNodePtr msg);
	int run_continue_stmt(GNode* g, MsgNodePtr msg);

    int process_para_for_submsg_call(GNode* g, GNode* sub_msg_node, MsgNodePtr sub_msg);
    MplValue eval_func_call(GNode* g, MsgNodePtr msg);
    MplValue eval_internal_func_call(GNode* g, MsgNodePtr msg);
    MplValue eval_selfdefined_func_call(GNode* g, GNode *func_node, MsgNodePtr msg, MsgNodePtr  context);
	MplValue eval_vnl_def_func_call(GNode* g, GNode *vnl_node, MsgNodePtr msg, MsgNodePtr context);
	MplValue eval_vnl_interpret(GNode* g, GNode *vnl_node, MsgNodePtr msg, MsgNodePtr context);

    MplValue eval_expr(GNode* g, MsgNodePtr msg);
    MplValue eval_or_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_and_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_cmp_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_arith_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_term_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_unary_exp(GNode* g, MsgNodePtr msg);
    MplValue eval_qualified_name(GNode* g, MsgNodePtr msg);

    //helper funcs
    MsgNodePtr locate_msg_by_qualified_name(GNode* name, MsgNodePtr starting_msg);

    void print_call_stack(MsgNodePtr  start_msg);
    friend class InterpretHelper;
    friend class DefaultValueInterpretHelper;

    int interpret_msg(MsgNodePtr msg, GNode* stmt, GNode *vnlnode);
	int emit_runtime_warning(RuntimeError &e);

	std::string get_runtime_qualified_name_str(GNode *g, MsgNodePtr msg);
public:

private:
    const char* id2str(STR_ID id) {return get_str_manager()->get_str(id);}
private:
	int total_warnings;
};






//helper class
class InterpretHelper :public MsgNodeTraverser
{
public:
    InterpretHelper(GNode* stmt_, GNode* vnl_, CStackBasedEngine *e):stmt(stmt_),vnl(vnl_),engine(e){}
    void operator () (MsgNodePtr msg); // g is interpret statement
private:
    GNode *stmt;
    GNode *vnl; //vnl-node

    CStackBasedEngine *engine;
};

class DefaultValueInterpretHelper: public MsgNodeTraverser
{
public:
    //g is gnode corresponding to m
    DefaultValueInterpretHelper(GNode *stmt_, CStackBasedEngine *e) : stmt(stmt_), engine(e){}
    void operator()(MsgNodePtr msg);

private:
    GNode* stmt;
    CStackBasedEngine* engine;
};

class UnwindingStackHelper
{
public:
    UnwindingStackHelper(GNode* g_):g(g_){}
    ~UnwindingStackHelper(){std::cerr<<"called from "<<get_str_manager()->get_str(g->src_file_id)<<" line "<<g->src_line_number<<std::endl;}
private:
    GNode *g;
};

#endif

