/*
  05Mar2008, lie, added bit endian and byte endian processing
  24Jul2010, lie, multiple message parsing in one run
*/

#include <cstdlib>
#include <cstring>
#include <clocale>
#include <string>
#include <cstdio>
#include <list>
#include "raw_memory.h"
#include "code.h"
#include "value.h"
#include "global.h"
#include "error.h"
#include "engine_cstack_based.h"
#include "rt_msg_tree.h"
#include "flat_memory.h"
#include "settings.h"
#include "rt_msg_ui.h"

std::string read_source_from_stdin()
{
	fprintf(stdout, "mpl: no input source file, read from stdin, Ctrl+Z (for windows) or Ctrl+D (for linux) to end\n");
	fprintf(stdout, "(try 'mpl -h' or 'mpl --help' for more information)\n");
	char buf[1024];
	std::string ret;
	while(1)
	{
		if (NULL == fgets(buf, 1024, stdin))
		{
			fflush(stdin);
			break;
		}
		ret+=buf;
	}

	//printf("%s", ret.c_str());
	return ret;
}

IRawMemory* prepare_mem()
{
    FILE *in;

    //mem file specified
    if (get_global_settings()->mem_file_name != "")
    {
        const char* file_name = get_global_settings()->mem_file_name.c_str();
        in = fopen(file_name, "r");
        if (NULL == in)
        {
            perror(file_name);
            fprintf(stderr, "mpl: cannot open %s\n",file_name);
            return 0;
        }
        IRawMemory* ret = new FlatMemory(in, file_name);
        fclose(in);
        return ret;
    }
    else if (get_global_settings()->no_mem) //run without mem file
    {
        return new FlatMemory();
    }
    else  // read mem from stdin
    {
        fprintf(stdout, "mplmem> no raw stream data file input, read from stdin, Ctrl+Z (for windows) or Ctrl+D (for linux) to end:\n");
        return new FlatMemory(stdin,"<stdin>");
    }
}

// print undigested raw stream data
int print_mem_tail(IRawMemory* mem)
{
    int c;
    int tailsize = mem->size() - mem->get_current_pos().octet;

    if (tailsize == 0)
        return 0;

    fprintf(stdout, "mpl: %d bytes of raw stream data not digested (started at %d(0x%x)):",
            tailsize, mem->get_current_pos().octet, mem->get_current_pos().octet);

    //mem->enable_octet_alignment(); // enable octet alignment to make printing clean
    if (mem->get_current_bit_pos()!=0)
        mem->set_current_pos(MemPos(mem->get_current_pos().octet, 0));

    int addr_start = mem->get_current_pos().octet - mem->get_current_pos().octet % 16;
    int content_start = mem->get_current_pos().octet;
    for (int i = addr_start; i <mem->size(); i++)
    {
        if (i % 16 == 0)
            fprintf(stdout, "\nx%04x: ", i/16*16);
        else if (i % 8 == 0)
            fprintf(stdout, "  ");
        else if (i % 4 == 0)
            fprintf(stdout, " ");

        if ( i < content_start)
        {
            fprintf(stdout, ".. ");
        }
        else
        {
            mem->get_octets(1,&c);
            fprintf(stdout, "%02x ", c);
        }
    }
    fprintf(stdout, "\n");

    return 0;
}

int run()
{
    IRawMemory *mem = NULL;

    try
    {
        MplCode code;

        //GNodeAutoPtr g (code.parse(src_file, MplCode::INPUT_FILE));
        GNode* p=NULL;
        if (get_global_settings()->source_from_stdin)
	    {
	      std::string str = read_source_from_stdin();
	      p = code.parse(str.c_str(), MplCode::INPUT_STRING);
	    }
        else
	    {
	      p = code.parse(get_global_settings()->source_file_name.c_str(), MplCode::INPUT_FILE);
	    }

        // warnings can be ignored
	    std::cout<< "mpl: syntax checking finished, "<<code.get_errors()
	             <<" errors, "<<code.get_warnings()<<" warnings."<<std::endl;

        if (!p)
            return 1;

	    GNodeAutoPtr g(p);
        if (g.get())
        {
            if (get_global_settings()->print_grammar)
            {
                std::cout<<g.get();
            }

            if (get_global_settings()->only_check_grammar)
            {
                return 0;
            }

            mem = prepare_mem();

            if (!mem)
            {
                return 1; //error info already given
            }


            mem->reset_to_first_frame();
            int msg_count = 0;
            while (1)
            {
                msg_count++;

                fprintf(stdout, "mpl: ---- message %d ----\n", msg_count);

                mem->print_current_frame();
                mem->set_bits_endian(get_global_settings()->bit_endian);
                mem->set_bytes_endian(get_global_settings()->byte_endian);

                MsgNodePtr msg(new RtMsgNode(MNT_NODE, 0, STR_ID_STDIN, -1 ));
                CStackBasedEngine e(g.get(), mem);
                int ret = e.run(msg);
                if (get_global_settings()->hex)
                    std::cout<<std::hex;
                else
                    std::cout<<std::dec;
                print_msg_text_layout(std::cout, msg, mem);
                print_mem_tail(mem);
                fprintf(stdout, "mpl: message parsing finished, %d errors, %d warnings.\n", ret, e.get_warnings());
                fprintf(stdout, "\n");
                if (ret)
                    return ret;
                if (0 != mem->switch_to_next_frame())
                {
                    break;
                }

            }

            //if (msg_count > 1)
            //    fprintf(stdout, "----\nmpl: totally %d messages are parsed!\n", msg_count);
			//return ret; //errors as return value
        }
        else
        {
            return 1; //nonzero means error
        }

    }
    catch (MplError e)
    {
        fprintf(stderr, "fatal error (%d): %s\n", e.err_code, e.info.c_str());
    }
    catch (...)
    {
        perror("unknow fatal error");
    }

	if (mem) delete mem;
    return 0;
};

int main(int argc, char* argv[])
{
    int ret;
    setlocale(LC_CTYPE, "");

    ret = get_global_settings()->cmd_line_parse(argc, argv);

    if (ret != 0)
    {
        return ret;
    }

    ret = run();

    // check memory leak
    if (GNode::node_count != 0)
    {
        fprintf(stderr, "memory leak detected: GNode %d\n", GNode::node_count);
    }

    if (MsgNode::msg_count != 0)
    {
        fprintf(stderr, "memory leak detected: MsgNode %d\n", MsgNode::msg_count);
    }

    return ret;
}
