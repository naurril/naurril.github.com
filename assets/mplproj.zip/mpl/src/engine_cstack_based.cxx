/*
  20Sep2011, lie, default value-interpretation, automatically interpret values who has a name-identical vnl-def node companion in the same layer
   e.g.
      msgdef msg:
        value_a = bits(13)

        vnldef value_a:  //must has same name as the to-be-interpreted node
            1: "this is 1"
            defualt: "d...."

     the engine automatically interpret value_a with vnl-def-node 'value_a'
     you  don't have to write the following statement
        interpret value_a: value_a
     only value-node (leaf-node) is supported
*/

// 11Jul2012, optional, multiple assignment statements shall be supported
/*
   if __name__ == "__main__":
	T_AbiscrAccessChannelPacketInd

msgdef T_AbiscrAccessChannelPacketInd:
	tAccessChannelHeader
	msgdef tAccessChannelHeader:
		wSystemId = b(16)
		ucGroupId = b(8)
		ucCarrierCellId = b(8)
		wRoundTripDelay = b(16)
    wDataLength = b(16)
    aucAccessPacketHead
	msgdef aucAccessPacketHead:
		ucLength = b(8)
		wConfigToken = b(16)
		ucSecFormat = b(1)
		ucConnFormat = b(1)
		ucReserved = b(4)
		ucATIType = b(2)
		dwATI = b(32)
	multiple(10) aucAccessPacket = b(8)  // variable length message body
	#msgdef aucAccessPacket:
	#	ucBYTE = b(8)


*/
#include <sstream>
#include "global.h"
#include "engine_cstack_based.h"
#include "engine_intl_func.h"
#include "settings.h"


void InterpretHelper::operator () (MsgNodePtr msg)  //leaf-msg-to-be interpretted, g is the interpret statement
{
    engine->interpret_msg(msg, stmt, vnl);
    return;
}


void DefaultValueInterpretHelper::operator()(MsgNodePtr msg)
{
    if (msg->get_type() != MNT_VALUE)
        return; //interpret only value fields

    if (msg->has_info())
        return;

    GNode *vnl = stmt->locate_subdef_node_by_name(msg->get_name());
    if (vnl)
    {
        MplValue v;
        v = msg->get_value();
        if (!IS_INT_TYPE(v))
        {
            return;
        }

        engine->interpret_msg(msg, stmt, vnl);
    }
}


CStackBasedEngine::CStackBasedEngine(GNode* _grammar, IRawMemory *_mem, std::ostream &_out, std::ostream &_err):
        Engine(_grammar, _mem, _out, _err)
{
    //current_msg_node = NULL;
    total_warnings = 0;

}

int CStackBasedEngine::emit_runtime_warning(RuntimeError &e)
{
    o_err<<"mplengine> "<<e.info<<":"<<e.para_1+1<<" warning ("<<e.err_code<<"): ";
    //                     file         line                     err no
    switch (e.err_code)
    {
    case err_assert_failed:
        o_err<<"assertion failed: "<<e.extra_info<<std::endl;
        break;
    case err_length_guard_check_failed:
        o_err<<"length guard check failed."<<std::endl;
        break;
    case err_invalid_statement:
        o_err<<"invalid statement: "<<e.extra_info<<std::endl;
        break;
    case err_unexpected_specifier_for_func_call:
        o_err<<"specifier for function call ignored."<<e.extra_info<<std::endl;
        break;
    case err_unexpected_specifier_for_vnl_call:
        o_err<<"specifier for vnl call ignored."<<e.extra_info<<std::endl;
        break;
    case err_value_truncated:
        o_err<<"value truncated (input para too large to handle)"<<e.extra_info<<std::endl;
        break;
    case err_unknown_message_to_interpret:
        o_err<<"unknown message to interpret: "<< e.extra_info<<std::endl;
        break;

    default:
        o_err<<e.extra_info<<std::endl;
        break;
    }
    ++total_warnings;

    return 0;

}

int CStackBasedEngine::run(MsgNodePtr msg)
{
    try
    {
        int ret;
        GNode *g = get_grammar();

        //for top message definition, we must execute its children directly
        // otherwise, no statements will be executed

        //msg body
        msg->set_mem_pos_begin(mem->get_current_pos());
        build_msg_body(g, msg);
        msg->set_mem_pos_end(mem->get_current_pos());
        /*
        for (std::vector<GNode*>::iterator i = g->children.begin(); i != g->children.end(); i++)
        {
            ret = run_gnode(*i, msg);

            if (msg->stopped())
                break;
        }
        */


    }
    catch (RuntimeError e)
    {
        o_err<<"mplengine> "<<e.info<<":"<<e.para_1+1<<" error ("<<e.err_code<<"): ";

        switch (e.err_code)
        {
        case err_unknown_func_name:
            o_err<<"unknown function name("<<e.err_code<<"): "<<e.extra_info<<std::endl;
            break;
        case err_func_para_incompatible:
            o_err<<"function argument type mismatch, argument "<<(e.para_2>>16)+1<<" of '"<<e.extra_info
            <<"', expect "<<MplValue::get_type_name(ValueType((e.para_2&0xff00)>>8))
            <<", got "<<MplValue::get_type_name(ValueType(e.para_2&0xff))
            <<std::endl;
        case err_unexpected_return:
            o_err<<"unexpected \'return\' in non-function call("<<e.err_code<<")"<<std::endl;
            break;
        case err_unexpected_break:
            o_err<<"unexpected \'break\' in non-loop statement("<<e.err_code<<")"<<std::endl;
            break;
		case err_unexpected_continue:
            o_err<<"unexpected \'continue\' in non-loop statement("<<e.err_code<<")"<<std::endl;
            break;
        case err_unmatched_para_list:
            o_err<<"message/fuction called with incompatible parameter number, provided "
            <<e.para_2/0x10000<<", expected "<<e.para_2%0x10000<<"; "<<e.extra_info<<std::endl;
            break;
        case err_access_nonexisted_variable:
            o_err<<"try to access non-existed variable '"<<e.extra_info<<"'"<<std::endl;
            break;
		case err_access_half_constructed_msg:
			o_err<<"try to access half-constructed msg '"<<e.extra_info<<"'"<<std::endl;
			break;
        case err_unknown_message_name:
            o_err<<"unknown message name: "<<e.extra_info<<std::endl;
            break;
        case err_unexpected_end_of_input:
            o_err<<"unexpected end of input (check raw-memory data)."<<std::endl;
            break;
        case err_assert_failed:
            o_err<<"assertion failed: "<<e.extra_info<<std::endl;
            break;
        case err_invalid_value_type_of_specifier:
            o_err<<"invalid value type for specifier (expect INT): "<<e.extra_info<<std::endl;
            break;
        case err_invalid_length_guard_assertion:
            o_err<<"invalid length guard: "<<e.extra_info<<std::endl;
            break;
        case err_length_guard_assert_failed:
            o_err<<"length guard assertion failed"<<std::endl;
            break;
        case err_type_error_1:
            o_err<<"operand type error in expression: "
            << MplValue::get_type_name(ValueType(e.para_2)) <<std::endl;
            break;
        case err_type_error_2:
            o_err<<"operand type error in expression: "
            << MplValue::get_type_name(ValueType(e.para_2&0xffff)) <<" and "
            << MplValue::get_type_name(ValueType(e.para_2>>16))<<std::endl;
            break;
        case err_suspicious_dead_loop_detected:
            o_err<<"suspicious deadloop detected."<<std::endl;
            break;

        case err_assign_to_const_variable:
            o_err<<"cannot change the value of a constant variable."<<std::endl;
            break;
        case err_runtime_assertion_failed:
            o_err<<"runtime error: "<<e.extra_info<<std::endl;
            break;
        case err_divide_by_zero:
            o_err<<"divide by zero."<<e.extra_info<<std::endl;
            break;
        default:
            o_err<<"unknown error"<<e.extra_info<<std::endl;
            break;
        }

        if (e.para_3)
            print_call_stack((MsgNode* )(e.para_3));

        return 1;
    }
    catch (MplError e)
    {
        o_err<<"unknown runtime error: "<<e.err_code<<std::endl;
        return 1;
    }
    catch (...)
    {
        o_err<<"unknown runtime error?"<<std::endl;
        return 1;
    }

    return 0;
}


int CStackBasedEngine::runtime_assert(bool expr, GNode* g, MsgNodePtr msg, const std::string &info)
{
    if (!expr)
    {
        throw RuntimeError(err_runtime_assertion_failed,
                           g->src_line_number, 0,
                           get_str_manager()->get_str(g->src_file_id),
                           msg.get(), info);
    }

    return 0;
}

int CStackBasedEngine::run_gnode(GNode* g, MsgNodePtr msg)
{
    MplValue v;

    switch (g->type)
    {

    case NT_STMT_SEQ:
        return run_stmt_seq(g, msg);
        break;
    case NT_IF_STMT:
        return run_if_stmt(g, msg);
        break;
    case NT_WHILE_STMT:
        return run_while_stmt(g, msg);
        break;
    case NT_TRY_LOOP:
        return run_try_loop_stmt(g, msg);
        break;
    case NT_FOR_STMT:
        break;
    case NT_ASSIGN_STMT:
        return run_assign_stmt(g,msg);
        break;
    case NT_INTERPRET_STMT:
        return run_interpret_stmt(g, msg);
        break;
    case NT_RUNSWITCH_STMT:
        return run_runswitch_stmt(g, msg);
        break;
    case NT_SUB_MSG_CALL:
        return run_sub_msg_call(g, msg, NULL);
        break;
    case NT_RETURN_STMT:
        return run_return_stmt(g, msg);
        break;
    case NT_BREAK_STMT:
        return run_break_stmt(g, msg);
        break;
	case NT_CONTINUE_STMT:
        return run_continue_stmt(g, msg);
        break;
    case NT_FUNC_CALL:
    case NT_OR_TEST:
    case NT_AND_TEST:
    case NT_CMP_EXP:
    case NT_ARITH_EXP:
    case NT_TERM_EXP:
    case NT_VARIABLE:
    case NT_CONST:
    case NT_QUALIFIED_NAME:    // a.b: a[1].b: a.b[1]: at least one dot
    case NT_PURE_INDEXED_NAME: // a[]: b[][][]: no bot: at least one bracket pair
    case NT_NAME: //different from dotted name
        //run time warning
        eval_expr(g, msg);
        break;
    case NT_PARA_LIST:
        // para list is always the first node of msgdef or funcdef, don't run it
        break;

    case NT_VNL_DEF:
    case NT_MSG_DEF:
    case NT_INVALID:
    default:
    {
        RuntimeError e(err_invalid_statement, g->src_line_number, g->type,
                       get_str_manager()->get_str(g->src_file_id), msg.get(), NodeTypeName[g->type]);
        emit_runtime_warning(e);
    }
    break;
    }
    return 0;
}

/*
g - sbu-msg-call grammar node
sub_msg_node: grammar node which this sub-msg is defined. (msgdef node)
sub_msg: msg to be generated
*/
int CStackBasedEngine::process_para_for_submsg_call(GNode* g, GNode* sub_msg_node, MsgNodePtr sub_msg)
{
    GNode* input_para_list = NULL;
    int input_para_num = 0;
    GNode* msg_para_list   = NULL;
    int msg_para_num = 0;

    if (IS_SPECIFIER(g->children[0]->type))
    {
        if (g->children.size() >=3)
            input_para_list = g->children[2];
    }
    else
    {
        if (g->children.size() >=2)
            input_para_list = g->children[1];
    }

    if (input_para_list)
    {
        if (input_para_list->type != NT_PARA_LIST)
            input_para_list = NULL;
        else
            input_para_num = input_para_list->children.size();
    }

    //parameter list
    if (sub_msg_node->children[0]->type == NT_PARA_LIST)
    {
        msg_para_list = sub_msg_node->children[0];
        msg_para_num = msg_para_list->children.size();
    }

    if (input_para_num != msg_para_num)
    {
        std::stringstream ss;
        ss<<"message name \""<<sub_msg_node->get_full_name()<<"\", defined at "<<get_str_manager()->get_str(sub_msg_node->src_file_id)<<" line "<<sub_msg_node->src_line_number+1;
        throw RuntimeError(err_unmatched_para_list, g->src_line_number, input_para_num * 0x10000+ msg_para_num,
                           get_str_manager()->get_str(g->src_file_id), sub_msg.get(), ss.str());
    }

    // insert para into context

    if (msg_para_num == 0)
    {
        return 0;
    }

    MplValue v;
    std::vector<GNode*>::iterator i,j;
    for ( i = input_para_list->children.begin(),j = msg_para_list->children.begin();
            i != input_para_list->children.end() && j!=msg_para_list->children.end();
            i++,j++)
    {
        v = eval_expr(*i, sub_msg);  //must use msg, which carries information needed by eval_expr
        sub_msg->add_sub_item((*j)->name, v, MNA_HIDDEN, (*i)->src_file_id, (*i)->src_line_number);
    }


    return 0;
}



// g - msg definition tree
// msg- target msg
int CStackBasedEngine::build_msg_body(GNode* g, MsgNodePtr msg)
{
    int ret = 0;
    //msg body
    for (std::vector<GNode*>::iterator i = g->children.begin(); i != g->children.end(); i++)
    {
        ret = run_gnode(*i, msg);

        if (0 != ret)
        {
            break;
        }

        if (msg->stopped())
            break;
    }

    // default value-interpretation performed here
    // for each scalar-value field of msg, try to interpret them
    //  with vnldefs defined in the same scope as those fields
    DefaultValueInterpretHelper helper(g, this);
    msg->traverse_children(helper);

    return ret;
}

//helper function
// only try to run, return error if fails, add sub-msg into *msg if succeeds
// sub_msg is the message to be generated
// g is the sub-msg-call grammar node
int CStackBasedEngine::try_sub_msg_call(GNode* g, MsgNodePtr sub_msg)
{
    int ret = 0;
    GNode* sub_msg_node;
    GNode* sub_msg_name;

    // locate the grammar node
    if (IS_SPECIFIER(g->children[0]->type))
    {
        sub_msg_name = g->children[1];
    }
    else
    {
        sub_msg_name = g->children[0];
    }

    sub_msg_node = g->parent->locate_subdef_node(sub_msg_name);

    if (!sub_msg_node)
    {
        //o_err<<"mplengine> "<<id2str(sub_msg_name->src_file_id)<<" line "
        //	<<sub_msg_name->src_line_number + 1<<" warning ("<<err_unknown_message_name<<"): "
        //	<<"unknown message name \""<<sub_msg_name->str()<<"\""<<std::endl;

        throw RuntimeError(err_unknown_message_name, sub_msg_name->src_line_number, 0,
                           id2str(sub_msg_name->src_file_id), sub_msg.get(), sub_msg_name->get_full_name());
    }

    // run this node
    //try
    {
        EndianHelperClass  endian_helper(mem);
        MsgLenGuardHelperClass  length_guard_helper(mem);

        sub_msg->set_mem_pos_begin(mem->get_current_pos());
        //current_msg_node = sub_msg.get();

        process_para_for_submsg_call(g, sub_msg_node, sub_msg);


        // name for new generated msg
        if (IS_ARRAY_SPECIFIER(g->children[0]->type))
        {
            /*
            for fixed msg call, this subitem is already attached to parent, and the get_parent()->get_subitems_count is
            already be increated
            but for the optional part of a multiple msg call, it's not attached yet.
            it's difficult to solve this problem, we determine the child-order when it's created.
            */
            std::ostringstream temp_name;
            temp_name << "[";
            temp_name << sub_msg->get_self_order(); // added before evaluate, so -1
            temp_name << "]";
            //            temp_name += itoa(sub_msg->get_parent()->get_subitems_count(),tempbuf,sizeof(tempbuf));
            //          temp_name += "]";
            sub_msg->set_name(temp_name.str());

        }
        else
        {
            sub_msg->set_name(g->get_target_name());
        }

        //msg body
        build_msg_body(sub_msg_node, sub_msg);

        // add to parent msg tree after everything is OK
        // or imcomplete msg may get into the message tree
        sub_msg->set_mem_pos_end(mem->get_current_pos());



        return 0;
    }
    /*
    catch(RuntimeError e)
    {
        if (e.err_code == err_unexpected_end_of_input)
        {
            o_err<<"mplengine> "<<sub_msg_node->src_file_name<<" line "<<sub_msg_node->src_line_number + 1<<" warning ("<<e.err_code<<"): "
                <<"unexpected end of input while processing mssage \""<<sub_msg_node->str()<<"\""<<std::endl;

            return err_unexpected_end_of_input;
        }
        else
        {
            throw;
        }
    }
    */
}
int CStackBasedEngine::run_optional_msg_call(GNode* g, MsgNodePtr msg, MsgNodePtr *generated_msg)
{
    int ret;
    MemPos current_pos;

    // this new message may need be discarded automatically, need auto_ptr protection
    MsgNodePtr sub_msg(new RtMsgNode(MNT_NODE, msg.get(), g->src_file_id, g->src_line_number));

    current_pos = mem->get_current_pos();
    try
    {
        ret = try_sub_msg_call(g, sub_msg);
        if (ret == 0)
        {
            if (generated_msg)
            {
                *generated_msg = sub_msg;
            }

            msg->add_sub_item(sub_msg);
            sub_msg->set_ripe();
            return 0;
        }
        else // this shouldn't happen
        {
            // add it to parent so we can provide more debug information
            // for mpl writers to locate the exact problem
            msg->add_sub_item(sub_msg);

            //o_err<<"msg call failed:"<<g->name<<std::endl;
            throw RuntimeError(ret, g->src_line_number, 0, id2str(g->src_file_id), sub_msg.get(), "sub-msg-call failed!");
            //sub_msg.release();
            return ret;
        }

    }
    catch (RuntimeError e)
    {
        switch (e.err_code)
        {
        case err_assert_failed:
            mem->set_current_pos(current_pos);
            if (get_global_settings()->verbose)
            {
                o_err<<"mplengine> "<<e.info<<":"<<e.para_1+1<<" error ("<<e.err_code<<"): assertion failed: "<<e.extra_info<<std::endl;
                o_err<<"mplengine> "<<id2str(g->src_file_id)<<":"<<g->src_line_number + 1<<" warning ("<<e.err_code<<"): "
                     <<"optional message \""<<g->get_full_name()<<"\", previous error ignored!"<<std::endl;
            }

            return e.err_code;
            break;
        case err_unexpected_end_of_input:
            mem->set_current_pos(current_pos);
            if (get_global_settings()->verbose)
            {
                o_err<<"mplengine> "<<e.info<<":"<<e.para_1+1<<" error ("<<e.err_code<<"): "<<e.extra_info<<std::endl;
                o_err<<"mplengine> "<<id2str(g->src_file_id)<<":"<<g->src_line_number + 1<<" warning ("<<e.err_code<<"): "
                     <<"optional message \""<<g->get_full_name()<<"\", previous error ignored!"<<std::endl;
            }

            return e.err_code;
            break;
        case err_unknown_message_name:
            mem->set_current_pos(current_pos);
            //if (get_global_settings()->verbose)
            {
                o_err<<"mplengine> "<<e.info<<":"<<e.para_1<<" error ("<<e.err_code<<"): unknown message: "<<e.extra_info<<std::endl;
                o_err<<"mplengine> "<<id2str(g->src_file_id)<<":"<<g->src_line_number + 1<<" warning ("<<e.err_code<<"): "
                     <<"optional message \""<<g->get_full_name()<<"\", previous error ignored!"<<std::endl;
            }

            return e.err_code;
            break;
        case err_length_guard_assert_failed:
            mem->set_current_pos(current_pos);
            if (get_global_settings()->verbose)
            {
                o_err<<"mplengine> "<<e.info<<":"<<e.para_1<<" error ("<<e.err_code<<"): length guard assertion failed: "<<e.extra_info<<std::endl;
                o_err<<"mplengine> "<<id2str(g->src_file_id)<<":"<<g->src_line_number + 1<<" warning ("<<e.err_code<<"): "
                     <<"optional message \""<<g->get_full_name()<<"\", previous error ignored!"<<std::endl;
            }

            return e.err_code;
            break;
        default:
            // attach this half-finished msg, to provide debug information
            msg->add_sub_item(sub_msg);
            throw;
        }
    }

    return 0;
}


int CStackBasedEngine::run_fixed_msg_call(MplValue spc_para, GNode* g, MsgNodePtr msg, MsgNodePtr * generated_msg)
{
    int i;
    int ret;
    // create msg-list
    if (spc_para != 0)
    {
        // this new message is appended to its parent immediately after creation
        // so no auto_ptr protection is needed
        MsgNodePtr  si = new RtMsgNode(MNT_LIST, msg.get(), g->src_file_id, g->src_line_number);
        si->set_mem_pos_begin(mem->get_current_pos());
        si->set_name(g->get_target_name());
        if (g->attr & NA_HIDDEN)
        {
            si->set_hidden();
        }

        //msg->add_sub_item(si);
        MsgNode::AddSubitemHelper helper(msg, si);

        if (generated_msg)
            *generated_msg = si;

        //si->parent = msg;

        for (i = 0; i < spc_para.asint(); i++)
        {
            // this new message is appended to its parent immediately after creation
            // so no auto_ptr protection is needed
            MsgNodePtr  sub_msg = new RtMsgNode(MNT_NODE, si.get(), g->src_file_id, g->src_line_number);

            // add it to parent so we can provide more debug information
            // for mpl writers to locate the exact problem
            //si->add_sub_item(sub_msg);
            MsgNode::AddSubitemHelper helper(si, sub_msg);

            ret = try_sub_msg_call(g, sub_msg);

            if (ret != 0)
            {
                //o_err<<"fixed-number sub message call failed"<<g->name<<std::endl;
                throw RuntimeError(ret, g->src_line_number, 0, id2str(g->src_file_id), sub_msg.get());
                return ret;
            }

            sub_msg->set_ripe();
        }

        si->set_mem_pos_end(mem->get_current_pos());
        si->set_ripe();
    }
    return 0;
}

int CStackBasedEngine::run_multiple_msg_call(MplValue spc_para, GNode* g, MsgNodePtr msg, MsgNodePtr * generated_msg)
{
    int i = 0;
    int ret;
    MsgNodePtr  si = NULL;

    // create msg-list

    // this new message is appended to its parent immediately after creation
    // so no auto_ptr protection is needed
    si = new RtMsgNode(MNT_LIST, msg.get(), g->src_file_id, g->src_line_number);
    si->set_mem_pos_begin(mem->get_current_pos());
    si->set_name(g->get_target_name());
    if (g->attr & NA_HIDDEN)
    {
        si->set_hidden();
    }
    //msg->add_sub_item(si);
    //si->parent = msg;
    MsgNode::AddSubitemHelper helper(msg, si);

    if (generated_msg)
        *generated_msg = si;


    // fixed part
    if (spc_para != 0)
    {
        for (i = 0; i < spc_para.asint(); i++)
        {
            // this new message is appended to its parent immediately after creation
            // so no auto_ptr protection is needed
            MsgNodePtr  sub_msg = new RtMsgNode(MNT_NODE, si.get(), g->src_file_id, g->src_line_number);

            // add it to parent so we can provide more debug information
            // for mpl writers to locate the exact problem
            //si->add_sub_item(sub_msg);
            MsgNode::AddSubitemHelper helper(si, sub_msg);

            ret = try_sub_msg_call(g, sub_msg);

            if (ret != 0)
            {
                //o_err<<"fixed-number sub message call failed"<<g->name<<std::endl;
                throw RuntimeError(ret, g->src_line_number, 0, id2str(g->src_file_id), sub_msg.get());
                return ret;
            }

            sub_msg->set_ripe();
        }
    }

    while (1)
    {
        if (0 != run_optional_msg_call(g, si, NULL))
        {
            break;
        }
    }

    si->set_mem_pos_end(mem->get_current_pos());
	si->set_ripe();
    // if any exception thrown, the parsing finishes
    return 0;
}

/*
g: submsgcall grammar node
msg: parent of the target sub-msg
*/
int CStackBasedEngine::run_sub_msg_call(GNode* g, MsgNodePtr msg, MsgNodePtr * generated_msg)
{
    int ret;
    MemPos current_pos;
    NodeType spc_type;
    MplValue spc_para;

    if (IS_SPECIFIER(g->children[0]->type))
    {
        spc_type = g->children[0]->type;

        // spc exist
        switch (spc_type)
        {
        case NT_OPTIONAL_SPECIFIER:
            run_optional_msg_call(g, msg, generated_msg);
            break;

        case NT_FIXED_SPECIFIER:
            spc_para = eval_expr(g->children[0]->children[0], msg);
            if (spc_para.type != VT_INT)
            {
                throw RuntimeError(err_invalid_value_type_of_specifier, g->src_line_number, spc_para.type, id2str(g->src_file_id), msg.get(), MplValue::get_type_name(spc_para.type));
                return err_invalid_value_type_of_specifier;
            }
            run_fixed_msg_call(spc_para, g, msg, generated_msg);
            break;

        case NT_MULTIPLE_SPECIFIER:  // half fixed, and half optional
            spc_para = eval_expr(g->children[0]->children[0], msg);
            if (spc_para.type != VT_INT)
            {
                throw RuntimeError(err_invalid_value_type_of_specifier, g->src_line_number, spc_para.type, id2str(g->src_file_id), msg.get(), MplValue::get_type_name(spc_para.type));
                return err_invalid_value_type_of_specifier;
            }
            run_multiple_msg_call(spc_para, g, msg, generated_msg);
            break;
        default:
            break;
        }
    }
    else // spc doesn't exist
    {
        // this new message is appended to its parent immediately after creation
        // so no auto_ptr protection is needed
        MsgNodePtr  sub_msg = new RtMsgNode(MNT_NODE, msg.get(), g->src_file_id, g->src_line_number);


        // must add first, for this call here mustn't fail,
        // if it does, then all the parsing finishes
        //msg->add_sub_item(sub_msg);
        MsgNode::AddSubitemHelper helper(msg, sub_msg);

        if (g->attr & NA_HIDDEN)
        {
            sub_msg->set_hidden();
        }

        ret = try_sub_msg_call(g, sub_msg);  //throw exception if necessary

        if (generated_msg)
        {
            *generated_msg = sub_msg;
        }

        sub_msg->set_ripe();
    }

    return 0;
}


int CStackBasedEngine::run_break_stmt(GNode* g, MsgNodePtr msg)
{
    return err_break_encountered;
    return 0;
}

int CStackBasedEngine::run_continue_stmt(GNode* g, MsgNodePtr msg)
{
    return err_continue_encountered;
    return 0;
}

// in function, a return terminates function running
// in message definition, a return stops message parsing
// in vnl definition, it's invalid, which is assured by parser
int CStackBasedEngine::run_return_stmt(GNode* g, MsgNodePtr msg)
{
    MsgNodePtr p = msg;

    while ((p->get_type() != MNT_FUNC_CONTEXT) && (p->get_type() != MNT_NODE) && p)
    {
        p->toggle_stopped();
        p = p->get_parent();
    }

    if (!p)
    {
        //return statmens encountered in non-function context
        throw RuntimeError(err_unexpected_return, g->src_line_number, 0, id2str(g->src_file_id), msg.get());
        return 0;
    }

    p->toggle_stopped();

    if (g->children.size())
        p->set_ret_value(eval_expr(g->children[0], msg));

    return 0;
}

int CStackBasedEngine::run_check_stmt(GNode* g, MsgNodePtr msg)
{
    MplValue v = eval_expr(g->children[0], msg);

    if (v == 0)
    {
        return err_check_failed;
    }

    return 0;
}
int CStackBasedEngine::run_assert_stmt(GNode* g, MsgNodePtr msg)
{
    MplValue v = eval_expr(g->children[0], msg);

    if (v == 0)
    {
        MsgNodePtr p = msg;

        while (p && (p->get_type() != MNT_FUNC_CONTEXT) && (p->get_type() != MNT_NODE) )
        {
            p->toggle_stopped();
            p = p->get_parent();
        }

        if (p)
        {
            p->toggle_stopped();
        }

        //o_err<<"mplengine> "<<id2str(g->src_file_id)<<" line "<<g->src_line_number + 1<<" warning ("<< err_assert_failed <<"): "
        //        <<"assertion failed: "<<g->name<<std::endl;
        throw RuntimeError(err_assert_failed, g->src_line_number, 0, id2str(g->src_file_id), msg.get(), g->name);
    }

    return 0;
}


// only assignment statement with the form "name=expr" can has attribute NA_NON_LOCAL
// that means no speicifier, not qualified name
// grammar: e.g.    fixed(2) x = o(1)
//           child  0        1   2
int CStackBasedEngine::run_assign_stmt(GNode* g, MsgNodePtr msg)
{

    MplValue v;
    GNode *ne;
    GNode *ve;
    bool spc_exist = false;
    NodeType spc_type;
    MplValue spc_para;

    if (IS_SPECIFIER(g->children[0]->type))
    {
        spc_exist = true;
        spc_type = g->children[0]->type;
        if (NT_OPTIONAL_SPECIFIER != g->children[0]->type)
        {
            spc_para = eval_expr(g->children[0]->children[0], msg);

            if (spc_para.type != VT_INT)
            {
                throw RuntimeError(err_invalid_value_type_of_specifier, g->src_line_number, spc_para.type, id2str(g->src_file_id), msg.get(), MplValue::get_type_name(spc_para.type));
                return err_invalid_value_type_of_specifier;
            }
        }

        ne = g->children[1];
        ve = g->children[2];
    }
    else
    {
        ne = g->children[0];
        ve = g->children[1];
    }

    // 1) locate old msg
    MsgNodePtr existed_msg;
    if (ne->type == NT_NAME)
    {
        existed_msg = msg->find_sub_item(g->name);
        if (!existed_msg.get() && (g->attr & NA_NON_LOCAL))
        {
            existed_msg  = locate_msg_by_qualified_name(ne, msg);
            if (!existed_msg.get())
                throw RuntimeError(err_access_nonexisted_variable, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                                   get_runtime_qualified_name_str(ne, msg));
			if (!existed_msg->is_ripe())
				throw RuntimeError(err_access_half_constructed_msg, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                                   get_runtime_qualified_name_str(ne, msg));
        }
    }
    else  // qualified name
    {
        existed_msg = locate_msg_by_qualified_name(ne, msg);
        if (!existed_msg.get())
            throw RuntimeError(err_access_nonexisted_variable, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                               get_runtime_qualified_name_str(ne, msg));
		if (!existed_msg->is_ripe())
				throw RuntimeError(err_access_half_constructed_msg, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                                   get_runtime_qualified_name_str(ne, msg));
    }
    // check if the old msg is constant
    if (existed_msg.get() && existed_msg->is_const())
    {
        throw RuntimeError(err_assign_to_const_variable, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                           get_runtime_qualified_name_str(ne, msg));
        return 0;
    }

    //2) create new message
    MsgNodePtr new_msg;
    if (spc_exist)
    {
        if (spc_type == NT_FIXED_SPECIFIER)
        {
            new_msg = new RtMsgNode(MNT_LIST, msg.get(), g->src_file_id, g->src_line_number);
        }
        else
        {
            runtime_assert(false, g, msg, "unexpected 'optional' or 'multiple' specifier" );
            return 0;
        }
    }
    else
    {
        new_msg = new RtMsgNode(MNT_VALUE, msg.get(), g->src_file_id, g->src_line_number);
    }

	if (!existed_msg)
    {

    }


    // name and layer
    if (existed_msg)
    {
        new_msg->set_name(existed_msg->get_name());
        new_msg->set_layer(existed_msg->get_layer());
    }
    else
    {
        new_msg->set_name(ne->get_target_name());
    }

	// this helper will do the replacement or addition of the new msg
	MsgNode::ReplaceSubitemHelper helper(msg, existed_msg, new_msg);

    /*
    // here we have a problem
    // how if the old msg is used by the expression in the assignment rightside
    // so we cannot substitute now

    // for non-existed msg we have the same problem if the right-side-expression
    // references the new created variable
    if (!existed_msg)
    {
        msg->add_sub_item(protected_new_msg.release());
        new_msg->set_name(ne->get_target_name());
    }
    else
    {
    	//reset layer value, the parent of new_msg is incorrect by now, which may cause its layer and subitem's layer incorrect.
    	//we will reset its parent after it's really attached
    	new_msg->set_layer(existed_msg->get_layer());
    }
    */


    // 3 evaluate
    if (g->attr & NA_HIDDEN)
    {
        new_msg->set_hidden();
    }

    /* hidden still hidden? then how do we disable the hidden attribute?
    // old name hidden?
    if (existed_msg)
    {
        if (existed_msg->is_hidden())
        {
            new_msg->set_hidden();
        }
    }
    */

    // no exception here
    if (!spc_exist)
    {
        new_msg->set_mem_pos_begin(mem->get_current_pos());
        new_msg->set_bits_endian(mem->get_bits_endian());
        new_msg->set_bytes_endian(mem->get_bytes_endian());
        new_msg->set_value(eval_expr(ve, msg));
        new_msg->set_mem_pos_end(mem->get_current_pos());
    }
    else
    {
        if (spc_type == NT_FIXED_SPECIFIER)
        {
            new_msg->set_mem_pos_begin(mem->get_current_pos());

            for (int i = 0; MplValue(i) < spc_para; i++)
            {
                MsgNodePtr  ssi = new RtMsgNode(MNT_VALUE, new_msg.get(), g->src_file_id, g->src_line_number);
                //new_msg->add_sub_item(ssi);
                MsgNode::AddSubitemHelper helper(new_msg, ssi);
                ssi->set_mem_pos_begin(mem->get_current_pos());
                ssi->set_bits_endian(mem->get_bits_endian());
                ssi->set_bytes_endian(mem->get_bytes_endian());
                std::ostringstream temp_name;
                temp_name << "[" << i << "]";
                ssi->set_name(temp_name.str());
                //ssi->set_value(eval_expr(ve, new_msg));  // show we use new_msg as its parent?
                ssi->set_value(eval_expr(ve, msg));
                ssi->set_mem_pos_end(mem->get_current_pos());
                ssi->set_ripe();
            }

            new_msg->set_mem_pos_end(mem->get_current_pos());
        }
        else if (spc_type == NT_OPTIONAL_SPECIFIER)
        {
            // only submessages is allowed to be put in such expressions
            // because others (function call or just const at the right side of
            // the assignment) will cause dead-loop
            runtime_assert(false, g, msg, "unexpected 'optional' specifier");

        }
        else  //multiple
        {
            runtime_assert(false, g, msg, "unexpected 'multiple' specifier");
        }
    }


	new_msg->set_ripe();

    // substitution will be done by helper

    return 0;
}

int CStackBasedEngine::run_stmt_seq(GNode* g, MsgNodePtr msg)
{
    std::vector<GNode*>::iterator ig;

    for (ig = g->children.begin(); ig != g->children.end(); ig++)
    {
        int ret = run_gnode(*ig, msg);

        if (msg->stopped())
            break;

        if (err_break_encountered == ret)
            return ret;

		if (err_continue_encountered == ret)
			return ret;
    }

    return 0;
}

// msg - msg node to be interpreted
// stmt - interpret statement
// vnlnode - vnl gnode to be used to interpret msg
int CStackBasedEngine::interpret_msg(MsgNodePtr msg, GNode* stmt, GNode *vnlnode)
{
    switch (msg->get_type())
    {

    case MNT_VALUE:
    {
        MsgNodePtr  context = new RtMsgNode(MNT_NODE, msg->get_parent(), stmt->src_file_id, stmt->src_line_number);
        context->set_name(vnlnode->get_full_name()+"(debug-node)");
        msg->get_parent()->set_debug_node(context); // atach it to msg's parent, rather than msg (the current value)
        MplValue v = eval_vnl_interpret(stmt, vnlnode, msg, context);
        msg->set_info(v.value.s);
        break;
    }
    case MNT_LIST:
    case MNT_NODE:
    {
        // call eval_vnl_def_call for each subiems
        InterpretHelper helper(stmt, vnlnode, this);
        msg->traverse_children(helper);
        break;
    }
    case MNT_FUNC_CONTEXT:
    default:
        break;
    }

    return 0;
}

/*
//g example
NT_INTERPRET_STMT:a
 +-children:
 | NT_NAME:message-node-name
 | NT_NAME:vnl-list-name
NT_INTERPRET_STMT:a
 +-children:
 | NT_NAME:a
 | NT_FUNC_CALL:func1
 |  +-children:
 |  | NT_NAME:func1
 |  | NT_PARA_LIST:func1
 |  |  +-children:
 |  |  | NT_NAME:a
*/
int CStackBasedEngine::run_interpret_stmt(GNode* g, MsgNodePtr msg)
{
    // the next assert should never occur
    runtime_assert(g->children.size() == 2, g, msg, "interpret statement should have only 2 children");

    // compiling pass shall have already assured this
    runtime_assert(g->children[0]->type == NT_QUALIFIED_NAME
                   || g->children[0]->type == NT_NAME, g, msg, "interpret statement should have a qualified-name or name as the target");

    //runtime_assert(g->children[1]->type == NT_QUALIFIED_NAME
    //   || g->children[1]->type == NT_NAME, g, msg);

    MsgNodePtr m = locate_msg_by_qualified_name(g->children[0], msg);
    if (!m)
    {
        //o_err<<"mplengine> "<<id2str(g->src_file_id)<<" line "<<g->src_line_number + 1
        //    <<" warning(): unknown message to interpret: "<<g->name<<std::endl;
        //o_err<<"mplengine> "<<id2str(g->src_file_id)<<" line "<<g->src_line_number + 1
        //    <<" warning(): unknown message to interpret: "<<get_runtime_qualified_name_str(g->children[0],msg)<<std::endl;

        RuntimeError e(err_unknown_message_to_interpret, g->src_line_number, 0,
                       id2str(g->src_file_id), msg.get(), get_runtime_qualified_name_str(g->children[0],msg));
        emit_runtime_warning(e);

        return 0;
    }

    /* disable the following check, to implement self-interpretation
    if (!m->is_ripe())
		throw RuntimeError(err_access_half_constructed_msg, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                get_runtime_qualified_name_str(g, msg));
    */

    if (g->children[1]->type == NT_NAME || g->children[1]->type == NT_QUALIFIED_NAME)//qualified name
    {
        GNode* t = g->parent->locate_subdef_node(g->children[1]);

        if (t && t->type == NT_VNL_DEF)
        {
            // create a temp context, andd __vnl_value__into it
            // if vnldef has a paremeter specified, add it also
            interpret_msg(m,g,t);

            return 0;
        }
    }

    MplValue v = eval_expr(g->children[1], msg);
    m->set_info(v.value.s);

    return 0;
}


int CStackBasedEngine::run_runswitch_stmt(GNode* g, MsgNodePtr msg)
{
    // the next assert should never occur
    runtime_assert(g->children.size() == 2, g, msg, "interpret statement should have only 2 children");

    // compiling pass shall have already assured this
    runtime_assert(g->children[0]->type == NT_QUALIFIED_NAME
                   || g->children[0]->type == NT_NAME, g, msg, "interpret statement should have a qualified-name or name as the target");

    //runtime_assert(g->children[1]->type == NT_QUALIFIED_NAME
    //   || g->children[1]->type == NT_NAME, g, msg);

    MsgNodePtr  m = locate_msg_by_qualified_name(g->children[0], msg);
    if (!m)
    {
        o_err<<"mplengine> "<<id2str(g->src_file_id)<<" line "<<g->src_line_number + 1
        <<" warning(): unknown message to interpret: "<<g->name<<std::endl;
        return 0;
    }

    if (!m->is_ripe())
		throw RuntimeError(err_access_half_constructed_msg, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                get_runtime_qualified_name_str(g, msg));

    if (g->children[1]->type == NT_NAME || g->children[1]->type == NT_QUALIFIED_NAME)//qualified name
    {
        GNode* t = g->parent->locate_subdef_node(g->children[1]);

        if (t && t->type == NT_VNL_DEF)
        {
            // create a temp context, andd __vnl_value__into it
            // if vnldef has a paremeter specified, add it also
            //interpret_msg(m,g,t);
            if (m->get_type() == MNT_VALUE)
            {
                MplValue v = m->get_value();
                runtime_assert(IS_INT_TYPE(v), g, msg, "expect integer value");

                //evaluate vnldef
                if (t->vsl.find(v.value.i) != t->vsl.end())
                {
                    return run_gnode(t->vsl[v.value.i], msg);
                }
                else if (t->vsl_default_handler)
                {
                    //default handler
                    return run_gnode(t->vsl_default_handler, msg);
                }

                runtime_assert(false, g, msg, "value doesn't match any item of vnl-def");
                return 0;

            }
            else
            {
                //error, TBC
                runtime_assert(false, g, msg, "invalid statement.....");

            }


            return 0;
        }
    }

    // not vnldef, run as a normal statement
    run_gnode(g->children[1], msg);


    return 0;
}


int CStackBasedEngine::run_if_stmt(GNode* g, MsgNodePtr msg)
{
    std::vector<Token>::iterator it;
    std::vector<GNode*>::iterator ig;
    MplValue v;

    for (it = g->tokens.begin(), ig = g->children.begin();
            it != g->tokens.end() && ig != g->children.end();
            it++,ig++)
    {
        if (*it == IF || *it == ELIF)
        {
            v = eval_expr(*ig, msg);
            if (v != 0)
            {
                return run_gnode(*(ig+1), msg);
            }
        }

        if (*it == ELSE)
        {
            return run_gnode(*ig, msg);
        }
    }

    return 0;
}

int CStackBasedEngine::run_while_stmt(GNode *g, MsgNodePtr msg)
{

    while (1)
    {
        MplValue v = eval_expr(g->children[0], msg);

        if (v != 0)
        {
            int ret = run_gnode(g->children[1], msg);

            if (err_break_encountered == ret)
                break;
			//if (err_continue_encountered == ret)
			//	continue;
        }
        else
        {
            break;
        }
    }

    return 0;
}

int CStackBasedEngine::run_try_loop_stmt(GNode *g, MsgNodePtr msg)
{
    MemPos start;
    MemPos end;

    do
    {
        start = mem->get_current_pos();

        int ret = run_gnode(g->children[0], msg);
        if (err_break_encountered == ret)
            break;
		/*
		if (err_continue_encountered == ret)
			continue;
		*/
        end = mem->get_current_pos();
    }
    while (start != end);

    return 0;
}

MplValue CStackBasedEngine::eval_expr(GNode* g, MsgNodePtr msg)
{
    MplValue ret;
    // don't use parameter msg, use temp msg

    try
    {
        switch (g->type)
        {
        case NT_OR_TEST:
            ret = eval_or_exp(g, msg);
            break;
        case NT_AND_TEST:
            ret = eval_and_exp(g, msg);
            break;
        case NT_CMP_EXP:
            ret = eval_cmp_exp(g, msg);
            break;
        case NT_ARITH_EXP:
            ret = eval_arith_exp(g, msg);
            break;
        case NT_TERM_EXP:
            ret = eval_term_exp(g, msg);
            break;
        case NT_UNARY_EXP:
            ret = eval_unary_exp(g, msg);
            break;
        case NT_NAME:
        case NT_PURE_INDEXED_NAME:
        case NT_QUALIFIED_NAME:
            ret =  eval_qualified_name(g, msg);
            break; //TBC

        case NT_CONST:
            ret = g->value;
            break;
        case NT_FUNC_CALL:
            ret = eval_func_call(g, msg);
            break;
        default:
            runtime_assert(false, g, msg, "unrecognizable expression");
            break;
        }

        //o_out<<"expr eval: "<<ret<<std::endl;
        return ret;
    }
    catch (RuntimeError e)
    {
        if (e.err_code == err_type_error_from_mplvalue)
        {
            if (e.para_2 != VT_NON_TYPE)
                throw RuntimeError(err_type_error_2, g->src_line_number, (e.para_2 << 16) + e.para_1, id2str(g->src_file_id));
            else
                throw RuntimeError(err_type_error_1, g->src_line_number, e.para_1, id2str(g->src_file_id));

        }
        else
        {
            throw;
        }
    }
    // or - exp
}


MplValue CStackBasedEngine::eval_qualified_name(GNode* g, MsgNodePtr msg)
{
    /*
    if (g->type == NT_NAME && g->name == __VNL_VALUE__)
    {
        return msg->get_value();

    }
    */

    MsgNodePtr  m = locate_msg_by_qualified_name(g, msg);

    if (m && !m->is_ripe())
		throw RuntimeError(err_access_half_constructed_msg, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                get_runtime_qualified_name_str(g, msg));

    if (m)
    {
        switch (m->get_type())
        {
        case MNT_VALUE:
            return m->get_value();
        case MNT_NODE:
        case MNT_LIST:
            return MplValue(m);
        case MNT_FUNC_CONTEXT:
            break;
        }
    }

    throw RuntimeError(err_access_nonexisted_variable, g->src_line_number, 0, id2str(g->src_file_id), msg.get(),
                       get_runtime_qualified_name_str(g,msg));
    return 0;
}


std::string CStackBasedEngine::get_runtime_qualified_name_str(GNode *g, MsgNodePtr msg)
{
    std::stringstream ret;

    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator  t;
    // first get the root node
    MsgNodePtr m = msg->locate_name(g->name, true);
    ret << g->name;
    // then get leaf
    if (m)
    {
        for (i = g->children.begin(), t = g->tokens.begin();
                i != g->children.end(), t != g->tokens.end();
                i++,t++)
        {
            if (*t == DOT)
            {
                m = m->locate_name((*i)->name,false);
                ret << '.'<< (*i)->name;
            }
            else  // *t == LEFT_BRACE
            {
                MplValue v = eval_expr(*i, m);
                m = m->child_at(v.asint());
                ret << '[' << v.asint() <<']';
            }

            if (m.get() == NULL)
                break;
        }
    }

    return ret.str();

}

/*
  locate name such as  a.b.c[1].d.e
*/
MsgNodePtr CStackBasedEngine::locate_msg_by_qualified_name(GNode* name, MsgNodePtr starting_msg)
{
    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator  t;
    // first get the root node
    MsgNodePtr  m = starting_msg->locate_name(name->name, true);

    // then get leaf
    if (m)
    {

        for (i = name->children.begin(), t = name->tokens.begin();
                i != name->children.end() && t != name->tokens.end();
                i++,t++)
        {
            if (*t == DOT)
            {
                m = m->locate_name((*i)->name,false);
            }
            else  // *t == LEFT_BRACE
            {
                // m is the start node of msg under evaluating.
                // it may pointer to a up level message, this will bypass some message layers
                // and cause the following eval_expr fail
                //MplValue v = eval_expr(*i, m);
                MplValue v = eval_expr(*i, starting_msg);
                m = m->child_at(v.asint());
            }

            if (m.get() == NULL)
                break;
        }
    }

    return m;
}


MplValue CStackBasedEngine::eval_or_exp(GNode* g, MsgNodePtr msg)
{
    MplValue v;
    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator iop;
    if (g->children.size() == 1)
    {
        return eval_expr(g->children[0], msg);
        return 0;
    }

    for (i = g->children.begin(); i != g->children.end(); i++)
    {
        v = eval_expr(*i, msg);
        if (v != 0)
        {
            return 1; //true
        }

        //TBC: float type
    }

    return 0; //false
}
MplValue CStackBasedEngine::eval_and_exp(GNode* g, MsgNodePtr msg)
{
    MplValue v;
    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator iop;
    if (g->children.size() == 1)
    {
        return eval_expr(g->children[0], msg);
    }

    for (i = g->children.begin(); i != g->children.end(); i++)
    {
        v = eval_expr(*i, msg);
        if (v ==0)
        {
            return 0;
        }

        //TBC: float type
    }

    return 1;
}

MplValue CStackBasedEngine::eval_cmp_exp(GNode* g, MsgNodePtr msg)
{

    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator iop;

    MplValue vl = eval_expr(g->children[0], msg);

    if (g->children.size() == 1)
    {
        return vl;
    }

    MplValue vr = eval_expr(g->children[1], msg);

    switch (g->tokens[0])
    {
    case LESS_THAN:
        return (vl < vr);
    case GREATER_THAN:
        return vl > vr;
    case EQUAL:
        return vl == vr;
    case NOT_EQUAL:
        return vl != vr;
    case LESS_OR_EQUAL:
        return vl <= vr;
    case GREATER_OR_EQUAL:
        return vl >= vr;
    default:
        throw MplError(err_run_time_unknown_operator, g->tokens[0], 0, "unknown operator");
        break;
    }

    //never reach here
    return 0;
}
MplValue CStackBasedEngine::eval_arith_exp(GNode* g, MsgNodePtr msg)
{
    MplValue v;
    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator iop;
    v = eval_expr(g->children[0], msg);
    for (iop = g->tokens.begin(), i = g->children.begin()+1;
            iop != g->tokens.end()  && i != g->children.end();
            iop++, i++)
    {
        switch (*iop)
        {
        case ADD:
            v += eval_expr(*i, msg);
            break;
        case SUB:
            v -= eval_expr(*i, msg);
            break;
        default:
            //TBC
            break;
        }
    }
    return v;
}

MplValue CStackBasedEngine::eval_term_exp(GNode* g, MsgNodePtr msg)
{
    MplValue v;
    MplValue temp;
    std::vector<GNode*>::iterator i;
    std::vector<Token>::iterator iop;
    v = eval_expr(g->children[0], msg);
    for (iop = g->tokens.begin(), i = g->children.begin()+1;
            iop != g->tokens.end()  && i != g->children.end();
            iop++, i++)
    {
        switch (*iop)
        {
        case MUL:
            v *= eval_expr(*i, msg);
            break;
        case DIV:
            //we must handle divide bye zero exception
            temp = eval_expr(*i, msg);
            if (temp == 0)
            {
                throw RuntimeError(err_divide_by_zero,
                                   g->src_line_number,
                                   0,
                                   id2str(g->src_file_id), msg.get());

            }
            v /= temp;
            break;
        case MOD:
            v %= eval_expr(*i, msg);
        default:
            //TBC
            break;
        }
    }
    return v;
}

MplValue CStackBasedEngine::eval_unary_exp(GNode* g, MsgNodePtr msg)
{
    MplValue v = eval_expr(g->children[0], msg);

    if (g->tokens[0] == ADD)
        return +v;
    else if (g->tokens[0] == SUB)
        return -v;
    else if (g->tokens[0] == NOT)
        return !v;
    else
        return v;
}

MplValue CStackBasedEngine::eval_func_call(GNode* g, MsgNodePtr msg)
{
    MplValue v;
    GNode *def_node;
    if (IS_SPECIFIER(g->children[0]->type))
    {
        def_node = g->children[1];
    }
    else
    {
        def_node = g->children[0];
    }

    GNode* func_def_node = g->parent->locate_subdef_node(def_node);

    if (func_def_node) // self defined function
    {
        if (func_def_node->type == NT_FUNC_DEF)
        {
            MsgNodePtr  context = new RtMsgNode(MNT_NODE, msg.get(), g->src_file_id, g->src_line_number);
            context->set_name(def_node->get_full_name() + "(debug-node)");
            msg->set_debug_node(context);

            return eval_selfdefined_func_call(g, func_def_node, msg, context);
        }
        else if (func_def_node->type == NT_VNL_DEF)
        {
            MsgNodePtr  context = new RtMsgNode(MNT_NODE, msg.get(), g->src_file_id, g->src_line_number);
            context->set_name(def_node->get_full_name() + "(debug-node)");
            msg->set_debug_node(context);
            return eval_vnl_def_func_call(g, func_def_node, msg, context);
        }
        else // submsg call
        {
            MsgNodePtr generated_msg = NULL;
            run_sub_msg_call(g, msg, &generated_msg);

            return generated_msg;
        }
    }
    else
    {
        return eval_internal_func_call(g, msg);
    }

    return 0;
}
/*
g - grammar node who calls this function
func_node - the called function node
msg - msg node at which the function is called, used for evaluating inputed parameters
context -
*/
MplValue CStackBasedEngine::eval_selfdefined_func_call(GNode* g, GNode *func_node, MsgNodePtr msg, MsgNodePtr context)
{
    // create function context
    // prepare function parameters
    // generate temp MsgNode which is needed by all statements in function body
    // handle stopped value

    MplValue v;
    GNode *input_para_list;
    if (IS_SPECIFIER(g->children[0]->type))
    {
        RuntimeError e(err_unexpected_specifier_for_func_call, g->src_line_number, 0,
                       id2str(g->src_file_id), msg.get());
        emit_runtime_warning(e);
        //o_err<<"mplengine> "<<id2str(g->src_file_id)<<" line "<<g->src_line_number + 1
        //<<": specifier for function call ignored!!"<<std::endl;
        input_para_list = g->children[2];
    }
    else
    {
        input_para_list = g->children[1];
    }

    GNode *func_para_list = func_node->children[0];

    if (input_para_list->children.size() != func_para_list->children.size())
    {
        std::stringstream ss;
        ss<<"function name \""<<func_node->get_full_name()<<"\", defined at "<<id2str(func_node->src_file_id)<<" line "<<func_node->src_line_number+1;

        throw RuntimeError(err_unmatched_para_list,
                           g->src_line_number,
                           input_para_list->children.size() * 0x10000+ func_para_list->children.size(),
                           id2str(g->src_file_id), msg.get(), ss.str());
        return 0;
    }


    std::vector<GNode*>::iterator i,j;
    for ( i = input_para_list->children.begin(),j = func_para_list->children.begin();
            i != input_para_list->children.end() && j!=func_para_list->children.end();
            i++,j++)
    {
        v = eval_expr(*i, msg);  //must use msg, which carries information needed by eval_expr
        context->add_sub_item((*j)->name, v, MNA_NORMAL, (*i)->src_file_id, (*i)->src_line_number);
    }

    for ( i = func_node->children.begin(); i != func_node->children.end(); i++)
    {
        run_gnode(*i, context);
    }

    return context->get_ret_value();
}


// if it's called from interpret statments, __vnl_value__ is prepared by the caller
// if it's called from a function call, __vnl_value__ is generated from the inputted parameter
// if the vnldef declares an input parameter, make it availbe in the context
//
MplValue CStackBasedEngine::eval_vnl_def_func_call(GNode* g, GNode *vnl_node, MsgNodePtr msg, MsgNodePtr context)
{
    MplValue v;

    GNode *input_para_list;

    if (IS_SPECIFIER(g->children[0]->type))
    {
        RuntimeError e(err_unexpected_specifier_for_vnl_call, g->src_line_number, 0,
                       id2str(g->src_file_id), msg.get());
        emit_runtime_warning(e);
        //o_err<<"mplengine> "<<id2str(g->src_file_id)<<" line "<<g->src_line_number + 1
        //<<": specifier for function call ignored!!"<<std::endl;
        input_para_list = g->children[2];
    }
    else
    {
        input_para_list = g->children[1];
    }

    if (input_para_list->children.size() != 1)
    {
        std::stringstream ss;
        ss<<"vnl-node name \""<<vnl_node->get_full_name()<<"\", defined at "<<id2str(vnl_node->src_file_id)<<":"<<vnl_node->src_line_number+1;

        throw RuntimeError(err_unmatched_para_list,
                           g->src_line_number,
                           input_para_list->children.size() * 0x10000+ 1,
                           id2str(g->src_file_id), msg.get(), ss.str());
        return 0;
    }

    //evaluate input para
    v = eval_expr(input_para_list->children[0], msg);

    runtime_assert(VT_INT == v.type, g, msg, "unexpected data type (expect integar value)");
    //generate __vnl_value__
    context->add_sub_item(__MPL_VNL_VALUE__, v.value.i,
						  MNA_NORMAL,
                          input_para_list->children[0]->src_file_id,
                          input_para_list->children[0]->src_line_number);

    // prepare parameter
    if (vnl_node->children.size())
    {
        runtime_assert(vnl_node->children[0]->type == NT_PARA_LIST, g, msg, "expect parameter list");
        context->add_sub_item(vnl_node->children[0]->children[0]->get_target_name(), v.value.i,
							  MNA_NORMAL,
                              input_para_list->children[0]->src_file_id,
                              input_para_list->children[0]->src_line_number);
    }

    //evaluate vnldef
    if (vnl_node->vnl.find(v.value.i) != vnl_node->vnl.end())
    {
        return vnl_node->vnl[v.value.i];
    }
    else if (vnl_node->vnl_default_handler)
    {
        //default handler
        return eval_expr(vnl_node->vnl_default_handler, context);
    }

    return "** warning: failed to interpret!!";

}

/*
g - statement, only used to report runtime error (runtime_assert)
vnl-node -
msg- current msg to be interpreted
context?
*/
MplValue CStackBasedEngine::eval_vnl_interpret(GNode* g, GNode *vnl_node, MsgNodePtr msg, MsgNodePtr context)
// interpret statment
{
    //__vnl_value__ has been stored in the context
    // generate input parameter
    // prepare parameter
    MplValue v;

    //runtime_assert(m->get_type() == MNT_VALUE, g, msg);

    if (msg->get_type() == MNT_VALUE)
    {

        v = msg->get_value();
        runtime_assert(IS_INT_TYPE(v), g, msg, "expect integer value");
        context->add_sub_item(__MPL_VNL_VALUE__, v.value.i, MNA_NORMAL, STR_ID_NULL, 0);

        if (vnl_node->children.size())
        {
            runtime_assert(vnl_node->children[0]->type == NT_PARA_LIST, g, msg, "expect parameter list");
            context->add_sub_item(vnl_node->children[0]->children[0]->get_target_name(),
				v.value.i, MNA_NORMAL,  STR_ID_NULL, 0); // vnldef parameter
        }

        //evaluate vnldef
        if (vnl_node->vnl.find(v.value.i) != vnl_node->vnl.end())
        {
            return vnl_node->vnl[v.value.i];
        }
        else if (vnl_node->vnl_default_handler)
        {
            //default handler
            return eval_expr(vnl_node->vnl_default_handler, context);
        }

        return MplValue("** warning: failed to interpret!!");

    }

    return 0;

}


MplValue CStackBasedEngine::eval_internal_func_call(GNode* g, MsgNodePtr msg)
{

    GNode * func_name = g->children[0];
    GNode * para_list = g->children[1];

    // eval_internal_func_call
    MplValue para_0=0,para_1=0,para_2=0;

    if (para_list->children.size() >= 1)
        para_0 = eval_expr(para_list->children[0], msg);

    if (para_list->children.size() >= 2)
        para_1 = eval_expr(para_list->children[1], msg);

    if (para_list->children.size() >= 3)
        para_2 = eval_expr(para_list->children[2], msg);


    MplValue v;
    try
    {
        // use full name
        v = EngineIntlFunc(mem, g, msg, this)(func_name->get_full_name(), para_0, para_1, para_2);
    }
    catch (RuntimeError e)
    {
        switch (e.err_code)
        {
        case err_unknown_func_name:
            throw RuntimeError(e.err_code, g->src_line_number, 0, id2str(g->src_file_id), msg.get(), e.info);
        case err_func_para_incompatible:
            throw RuntimeError(e.err_code, g->src_line_number, e.para_1, id2str(g->src_file_id), msg.get(), e.info);
        case err_unexpected_end_of_input:
            throw RuntimeError(e.err_code, g->src_line_number, 0, id2str(g->src_file_id), msg.get(), e.info);
        case err_length_guard_assert_failed:
            throw RuntimeError(e.err_code, g->src_line_number, 0, id2str(g->src_file_id), msg.get(), e.info);
        case err_length_guard_check_failed:
            break;
            //case err_length_guard_assertion_failed:
            //    throw RuntimeError(e.err_code, g->src_line_number, 0, id2str(g->src_file_id), msg, e.info);
        default:
            throw;
            break;
        }
    }

    return v;
}


void CStackBasedEngine::print_call_stack(MsgNodePtr  start_msg)
{
    MsgNodePtr  msg = start_msg;
    while (msg)
    {
        o_err << "\t\tcalled from "<<msg->get_src_file_name()<<":"<<msg->get_src_line_number()+1<<";"<<std::endl;
        msg = msg->get_parent();
    }

}

