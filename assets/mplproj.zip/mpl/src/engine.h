#ifndef _MPL_ENGINE_H_
#define _MPL_ENGINE_H_

#include "raw_memory.h"
#include "value.h"
#include "grammar_node.h"
#include "rt_msg_tree.h"
#include "error.h"

class FuncContext
{

};

class Engine
{
public:
    Engine(GNode* _grammar, IRawMemory *_mem, std::ostream &_out = std::cout, std::ostream &_err = std::cerr);
    virtual int run(MsgNodePtr msg) = 0;
    virtual ~Engine(){}
	virtual int emit_runtime_warning(RuntimeError &e) = 0;

protected:
    void set_raw_mem(IRawMemory *_mem) {mem = _mem; }
    GNode *get_grammar() {return grammar;}

    //MsgNodePtr current_msg_node;
    //MsgNode top_msg_node;
    IRawMemory *mem;
    GNode *grammar;
    std::ostream &o_out;
    std::ostream &o_err;
};






#endif
