
#include <sstream>
#include "value.h"
#include "error.h"
#include "rt_msg_tree.h"
#include "settings.h"

// printing out value type will cause ugly warning info
std::ostream & operator << (std::ostream &o, MplValue v)
{
    char temp[16];
    char *str;
    switch (v.type)
    {
    case VT_A_INT:
    case VT_INT:
        o<<v.value.i;
        break;
    case VT_FLOAT:
        o << v.value.f;
        break;
    case VT_WCHAR:
        //if (get_global_settings()->verbose)
        //    o << "wchar ";
        sprintf(temp,"%lc",v.value.i);
        o<<temp;
        break;

    case VT_CHAR:
        //if (get_global_settings()->verbose)
        //    o << "char ";
        o << static_cast<char>(v.value.i);
        break;
    case VT_WSTRING:
        //if (get_global_settings()->verbose)
        //    o << "wstr ";
		str = new char[(v.value.ws.size() + 1)*8];
        sprintf(str,"%ls", v.value.ws.c_str());
        o<<str;
        delete[] str;
        break;
    case VT_STRING:
        //if (get_global_settings()->verbose)
        //    o << "str ";
        o <<v.value.s;
        break;
    case VT_MSG_REF:

        o << "-->" ;
        // for elements of a list, print out it's parent for clarity
        if (v.value.msg_ref->get_name()[0] == '[')
			o<<v.value.msg_ref->get_parent()->get_name();
		o << v.value.msg_ref->get_name();

        break;

    case VT_NON_TYPE:
        o << "unknown type!!";
        break;
    }
    return o;
}

/* c-language way of printing */
void print_value(FILE* fout, MplValue &v, bool hex)
{
    switch (v.type)
    {
    case VT_A_INT:
    case VT_INT:
        if (hex)
            fprintf(fout,"%x",v.value.i);
        else
            fprintf(fout,"%d",v.value.i);
        break;
    case VT_FLOAT:
        fprintf(fout,"%f",v.value.f);
        break;
    case VT_WCHAR:
        fprintf(fout,"%lc",v.value.i);
        break;

    case VT_CHAR:
        fprintf(fout,"%c",v.value.i);
        break;
    case VT_WSTRING:
        fprintf(fout,"%ls", v.value.ws.c_str());
        break;
    case VT_STRING:
        fprintf(fout,"%s", v.value.s.c_str());
        break;
    case VT_MSG_REF:
        fprintf(fout, "-->");

        // for elements of a list, print out it's parent for clarity
        if (v.value.msg_ref->get_name()[0] == '[')
			//o<<v.value.msg_ref->get_parent()->get_name();
			fprintf(fout, "%s", v.value.msg_ref->get_parent()->get_name().c_str());
		//o << v.value.msg_ref->get_name();
        fprintf(fout, "%s", v.value.msg_ref->get_name().c_str());
        break;

    case VT_NON_TYPE:
        fprintf(fout, "unknown type!!");
        break;
    }

}

std::string MplValue::value_type_name[] ={"int", "float", "char", "wchar", "string","wstring","a-int","msg-ref","non_type"};


int MplValue::asint()
{
    switch (type)
    {
    case VT_A_INT:
    case VT_INT:
    case VT_CHAR:
    case VT_WCHAR:
        return value.i;
    case VT_STRING:
    case VT_WSTRING:
    case VT_FLOAT:
    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }
    throw RuntimeError(err_type_error_from_mplvalue, type, VT_NON_TYPE, "type mismatch");
}

bool MplValue::operator == (const MplValue &v) const
{
    switch (type)
    {

    case VT_INT:
        if (v.type == VT_INT)
            return value.i == v.value.i;
        else if (v.type == VT_CHAR)
            return value.i == v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i == v.value.i;
        break;

    case VT_CHAR:
        if (v.type == VT_INT)
            return value.i == v.value.i;
        else if (v.type == VT_CHAR)
            return value.i == v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i == v.value.i;
        break;
    case VT_WCHAR:
        if (v.type == VT_INT)
            return value.i == v.value.i;
        else if (v.type == VT_CHAR)
            return value.i == v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i == v.value.i;
        break;

    case VT_FLOAT:
        if (v.type == VT_FLOAT)
            return value.f == v.value.f;
        break;

    case VT_STRING:
        if (v.type == VT_STRING)
            return value.s == v.value.s;
        break;
    case VT_WSTRING:
        if (v.type == VT_WSTRING)
            return value.ws == v.value.ws;
        break;
    case VT_MSG_REF:
        if (v.type == VT_MSG_REF)
            return value.msg_ref.get() == v.value.msg_ref.get();
        break;
    case VT_A_INT:
    case VT_NON_TYPE:

        break;
    }

    throw RuntimeError(err_type_error_from_mplvalue, type, v.type, "type mismatch");
    return true;
}

bool MplValue::operator >  (const MplValue &v) const
{
    switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        if (v.type == VT_INT)
            return value.i > v.value.i;
        else if (v.type == VT_CHAR)
            return value.i > v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i > v.value.i;
        break;

    case VT_FLOAT:
        if (v.type == VT_FLOAT)
            return value.f > v.value.f;
        break;

    case VT_WCHAR:
        if (v.type == VT_INT)
            return value.i > v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i > v.value.i;
        else if (v.type == VT_CHAR)
            return value.i > v.value.i;
    case VT_CHAR:
        if (v.type == VT_INT)
            return value.i > v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i > v.value.i;
        else if (v.type == VT_CHAR)
            return value.i > v.value.i;
        break;

    case VT_WSTRING:
        if (v.type == VT_WSTRING)
            return value.ws > v.value.ws;
        break;
    case VT_STRING:
        if (v.type == VT_STRING)
            return value.s > v.value.s;
        break;

    case VT_MSG_REF:
    case VT_NON_TYPE:
        throw RuntimeError(err_type_error_from_mplvalue, type, v.type, "unknown type");
        break;
    }

    //never reach here
    return true;
}

bool MplValue::operator <  (const MplValue &v) const
{
    return v > *this;
}

bool MplValue::operator >= (const MplValue &v) const
{
    return (*this > v) || (*this == v);
}

bool MplValue::operator <= (const MplValue &v) const
{
    return (*this < v) || (*this == v);
}

bool MplValue::operator != (const MplValue &v) const
{
    return !(*this == v);
}

MplValue MplValue::operator + (const MplValue &v)
{
    switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        if (v.type == VT_INT)
            return value.i + v.value.i;
        else if (v.type == VT_CHAR)
            return value.i + v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i + v.value.i;
        break;

    case VT_FLOAT:
        if (v.type == VT_FLOAT)
            return value.f + v.value.f;
        if (v.type == VT_INT)
            return value.f + v.value.i;
        break;

    case VT_CHAR:
        if (v.type == VT_INT)
            return value.i + v.value.i;
        else if (v.type == VT_CHAR)
            return value.i + v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i + v.value.i;
        break;
    case VT_WCHAR:
        if (v.type == VT_INT)
            return value.i + v.value.i;
        else if (v.type == VT_CHAR)
            return value.i + v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i + v.value.i;
        break;
    case VT_STRING:
		{
			std::stringstream ss;
			ss<<value.s<<v;
			return ss.str();
		}
        break;
    case VT_WSTRING:
        if (v.type == VT_WSTRING)
            return value.ws + v.value.ws;
        else if (v.type == VT_WCHAR)
            return value.ws + static_cast<wchar_t>(v.value.i);
        break;

    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }

    throw RuntimeError(err_type_error_from_mplvalue, type, v.type, "type mismatch");
    return 0;

}

MplValue MplValue::operator += (const MplValue &v)
{
    return *this = *this + v;
}
MplValue MplValue::operator - (const MplValue &v)
{
    switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        if (v.type == VT_INT)
            return value.i - v.value.i;
        else if (v.type == VT_CHAR)
            return value.i - v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i - v.value.i;
        break;

    case VT_FLOAT:
        if (v.type == VT_FLOAT)
            return value.f - v.value.f;
        if (v.type == VT_INT)
            return value.f - v.value.i;
        break;

    case VT_CHAR:
        if (v.type == VT_INT)
            return value.i - v.value.i;
        else if (v.type == VT_CHAR)
            return value.i - v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i - v.value.i;
        break;
    case VT_WCHAR:
        if (v.type == VT_INT)
            return value.i - v.value.i;
        else if (v.type == VT_CHAR)
            return value.i - v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i - v.value.i;
        break;

    case VT_STRING:
    case VT_WSTRING:
    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }
    throw RuntimeError(err_type_error_from_mplvalue, type, v.type, "undefined type");
    return 0;
}

MplValue MplValue::operator -= (const MplValue &v)
{
    return *this = *this - v;
}

MplValue MplValue::operator * (const MplValue &v)
{
    switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        if (v.type == VT_INT)
            return value.i * v.value.i;
        else if (v.type == VT_CHAR)
            return value.i * v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i * v.value.i;
        break;

    case VT_FLOAT:
        if (v.type == VT_FLOAT)
            return value.f * v.value.f;
        if (v.type == VT_INT)
            return value.f * v.value.i;
        break;

    case VT_CHAR:
        if (v.type == VT_INT)
            return value.i * v.value.i;
        else if (v.type == VT_CHAR)
            return value.i * v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i * v.value.i;

        break;

    case VT_WCHAR:
        if (v.type == VT_INT)
            return value.i * v.value.i;
        else if (v.type == VT_CHAR)
            return value.i * v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i * v.value.i;

        break;
    case VT_STRING:
    case VT_WSTRING:
    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }
    throw RuntimeError(err_type_error_from_mplvalue, type, v.type, "undefined type");
    return 0;
}

MplValue MplValue::operator *= (const MplValue &v)
{
    return *this = *this * v;
}


MplValue MplValue::operator / (const MplValue &v)
{
switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        if (v.type == VT_INT)
            return value.i / v.value.i;
        else if (v.type == VT_CHAR)
            return value.i / v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i / v.value.i;
        break;

    case VT_FLOAT:
        if (v.type == VT_FLOAT)
            return value.f / v.value.f;
        if (v.type == VT_INT)
            return value.f / v.value.i;
        break;

    case VT_CHAR:
        if (v.type == VT_INT)
            return value.i / v.value.i;
        else if (v.type == VT_CHAR)
            return value.i / v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i / v.value.i;
        break;
    case VT_WCHAR:
        if (v.type == VT_INT)
            return value.i / v.value.i;
        else if (v.type == VT_CHAR)
            return value.i / v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i / v.value.i;
        break;
    case VT_WSTRING:
    case VT_STRING:
    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }

    throw RuntimeError(err_type_error_from_mplvalue, type, v.type, "undefined type");
    return 0;
}

MplValue MplValue::operator /= (const MplValue &v)
{
    return *this = *this / v;
}

MplValue MplValue::operator % (const MplValue &v)
{
switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        if (v.type == VT_INT)
            return value.i % v.value.i;
        else if (v.type == VT_CHAR)
            return value.i % v.value.i;
        else if (v.type == VT_WCHAR)
            return value.i % v.value.i;
        break;

    case VT_CHAR:
        if (v.type == VT_INT)
            return value.i % v.value.i;
        else if (v.type == VT_CHAR)
            return value.i % v.value.i;
        else if (v.type == VT_CHAR)
            return value.i % v.value.i;
        break;
    case VT_WCHAR:
        if (v.type == VT_INT)
            return value.i % v.value.i;
        else if (v.type == VT_CHAR)
            return value.i % v.value.i;
        else if (v.type == VT_CHAR)
            return value.i % v.value.i;
        break;
    case VT_FLOAT:
    case VT_STRING:
    case VT_WSTRING:
    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }

    throw RuntimeError(err_type_error_from_mplvalue, type, v.type, "undefined type");
    return 0;

}
MplValue MplValue::operator %= (const MplValue &v)
{
    return *this = *this % v;
}

MplValue MplValue::operator - ()
{
    switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        return  -value.i;
        break;
    case VT_CHAR:
        return -value.i;
    case VT_WCHAR:
        return -value.i;
    case VT_FLOAT:
        return -value.f;
        break;
    case VT_STRING:
    case VT_WSTRING:
    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }

    throw RuntimeError(err_type_error_from_mplvalue, type, VT_NON_TYPE, "Undefined Type");
    return 0;

}
MplValue MplValue::operator + ()
{
    switch (type)
    {
    case VT_A_INT:
    case VT_INT:
        return  value.i;
        break;
    case VT_CHAR:
        return value.i;
    case VT_WCHAR:
        return value.i;
    case VT_FLOAT:
        return value.f;
        break;
    case VT_STRING:
    case VT_WSTRING:
    case VT_MSG_REF:
    case VT_NON_TYPE:
        break;
    }

    throw RuntimeError(err_type_error_from_mplvalue, type, VT_NON_TYPE, "Undefined Type");
    return 0;

}

MplValue MplValue::operator !()
{
    switch (type)
    {
    case VT_A_INT:
    case VT_CHAR:
    case VT_WCHAR:
    case VT_INT:
        return  !value.i;
        break;
    case VT_FLOAT:
        return !value.f;
        break;

    case VT_NON_TYPE:
    case VT_MSG_REF:
    case VT_STRING:
    case VT_WSTRING:
        break;
    }

    throw RuntimeError(err_type_error_from_mplvalue, type, VT_NON_TYPE, "improper operation");
	return 0;
}

