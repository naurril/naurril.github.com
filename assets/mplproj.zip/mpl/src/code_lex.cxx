#include <iostream>
#include <cstring>
#include <fstream>
#include <cctype>
#include <memory>
#include "code.h"
#include "rt_msg_tree.h"
#include "global.h"
#include "settings.h"


//int MplCode:: start(IRawMemory *mem)
//{
//    return 0;
//}

std::string& MplCode::file_2_path(std::string &name)
{
    int n1 = name.rfind("/");
    int n2 = name.rfind("\\");

    if (n1 == (int)std::string::npos && n2 == (int)std::string::npos)
    {
        name = ".";
    }
    else
    {
        name.erase(std::max(n1, n2));
    }
    return name;

}
int MplCode::set_src_codes(const char*src)
{

	if (input_file != NULL)
	{
		throw CompileError(err_src_file_already_set, 0, 0, id2str(this->file_id));
	}
	src_codes = src;
	src_codes_index = 0;

    this->file_id = get_str_manager()->store_new_str("<stdin>");
    this->path_id = get_str_manager()->store_new_str(".");
    this->module_name = __MPL_MAIN__;

    src_file_name_stack.push_back(this->file_id);

    if (get_global_settings()->verbose)
    {
        o_out<<"mplcode> source file: "<<id2str(this->file_id)<<" opened!"<<std::endl;
        //o_out<<" file path: "<<this->file_path<<std::endl;
    }
	next_line();
    return 0;
}
int MplCode::set_src_file(const char *filename)
{

	if (src_codes != NULL)
	{
		throw CompileError(err_src_codes_already_set, 0, 0, "");
	}

    std::string full_path_name = search_file(filename, ".");

    if (full_path_name == "")
    {
        //      o_err<<"mplcode> cannot file source file: "<<filename<<std::endl;
        throw CompileError(err_cannot_open_file, 0, 0, filename);
    }

    full_path_name = get_abs_file_path(full_path_name);

    input_file = fopen(full_path_name.c_str(),"r");

    if (NULL == input_file)
    {
        perror(filename);
        fprintf(stderr, "mplcode> failed to open source file '%s'!\n",filename);
        throw CompileError(err_cannot_open_file, 0, 0, filename);
    }

    this->file_id = get_str_manager()->store_new_str(full_path_name.c_str());
    this->path_id = get_str_manager()->store_new_str(file_2_path(full_path_name).c_str());
    this->module_name = __MPL_MAIN__;

    src_file_name_stack.push_back(this->file_id);

    if (get_global_settings()->verbose)
    {
        o_out<<"mplcode> source file: "<<id2str(this->file_id)<<" opened!"<<std::endl;
        //o_out<<" file path: "<<this->file_path<<std::endl;
    }

    next_line();
    return 0;
}


int MplCode::restore_last_file_pos()
{

    strcpy(line, src_file_context_stack.back().line.c_str());
    line_size = strlen(line);
    current_line = src_file_context_stack.back().current_line;
    current_column = src_file_context_stack.back().current_column;

    input_file = src_file_context_stack.back().in;
    file_id = src_file_context_stack.back().file_id;
    path_id = src_file_context_stack.back().path_id;
    module_name = src_file_context_stack.back().module_name;

    indent_stack = src_file_context_stack.back().indent_stack;
    pending_token = src_file_context_stack.back().pending_token;

    current_token = src_file_context_stack.back().current_token;
    current_token_str = src_file_context_stack.back().current_token_str;
    current_value = src_file_context_stack.back().current_value;
    end_of_file = src_file_context_stack.back().end_of_file;

    //o_out<<"restore "<< file_name<<std::endl;
    src_file_context_stack.pop_back();

    return 0;
}

int MplCode::save_current_file_pos()
{
    SrcFileContext p;
    p.line = line;
    p.current_line = current_line;
    p.current_column = current_column;
    p.in = input_file;
    p.file_id = file_id;
    p.path_id = path_id;
    p.module_name = module_name;
    p.indent_stack = indent_stack;
    p.pending_token = pending_token;

    p.current_token = current_token;
    p.current_token_str = current_token_str;
    p.current_value = current_value;
    p.end_of_file = end_of_file;

    //std::cout<<"save "<< file_name<<std::endl;
    src_file_context_stack.push_back(p);

    return 0;
}

// abstract readline from file or string
const char* MplCode::read_line_from_src(char* buf, size_t size)
{
	if (input_file)
	{
		return fgets(buf, size, input_file);
	}
	else if (src_codes)
	{
		// end of input
		if (src_codes[src_codes_index] == 0)
			return NULL;

		// get one line
		int i;
		for (i = 0; i < size-1; i++)
		{
			char c = src_codes[src_codes_index];

			if (c == 0)
			{
				break;
			}
			else if ( c== '\r')
			{
				src_codes_index++;
				if (src_codes[src_codes_index] == '\n')
					src_codes_index++;
				break;
			}
			else if (c == '\n')
			{
				src_codes_index++;
				if (src_codes[src_codes_index] == '\r')
					src_codes_index++;
				break;
			}
			else
			{
				buf[i] = c;
				src_codes_index++;
			}
		}

		buf[i] = 0; // line end mark
		return buf;
	}

	return NULL;
}

int MplCode::next_line()
{

    current_column = 0;
    current_indent = 0;

    // filter empty line
    do
    {
        if (NULL == read_line_from_src(line,  MAX_LINE_SIZE))
        {
            end_of_file = true;

            //all dedents generated
            while (indent_stack.size() > 1)
            {
                pending_token.push(DEDENT);
                indent_stack.pop();
                //std::cout<<file_name<<":"<<current_line<<":push dedent(end of file)"<<std::endl;
            }

            line[0]= 0;
            line_size = 0;

            if (get_global_settings()->verbose)
            {
                o_out<<"mplcode> source file: "<<id2str(this->file_id)<<" closed!"<<std::endl;
            }
            if (input_file) fclose(input_file);
            return -1;

        }
        else
        {
            current_line++;
            line_size = strlen(line);
        }

    }
    while (is_empty_line(line));

    // non-empty line

    char c;

    while (current_column < line_size)
    {
        c = line[current_column];
        if (c== ' ')
        {
            current_indent++;
        }
        else if (c == '\t')
        {
            current_indent += 4 - (current_indent % 4); // tab makes 4 characters alignment
        }
        else
            break;
        current_column++;
    }

    if (current_indent > indent_stack.top())
    {
        indent_stack.push(current_indent);
        //generate one INDENT
        pending_token.push(INDENT);
        //std::cout<<id2str(this->file_id)<<":"<<current_line<<":push indent "<<current_indent<<std::endl;
    }
    else if (current_indent < indent_stack.top())
    {
        //DEDENT
        while (current_indent < indent_stack.top())
        {
            indent_stack.pop();
            int top_old_indent = indent_stack.top();
            if (current_indent > top_old_indent)
            {
                CompileError e(err_invalid_dedent,0,0,"");
                emit_compile_err_info(e);
            }


            pending_token.push(DEDENT);
            //std::cout<<file_name<<":"<<current_line<<":push dedent"<<std::endl;
        }
    }

    //std::cout<<"src line["<<current_line + 1<<"] "<<line<<std::endl;
    return current_line;

}


bool MplCode::is_empty_line(const char* str)
{

    unsigned int col = 0;
    unsigned int size = strlen(str);
    while ((col < size)
            && ((str[col] == ' ') || (str[col] == '\t') || (str[col] == '\n') || (str[col] == '\r')))
    {
        col++;
    }

    if (col >= size)
        return true;
    if (str[col] == '#')
        return true;

    return false;
}



Token MplCode::lex_name()
{
    char c;
    std::string temp_str="";
    temp_str+=line[current_column];

    current_column++;

    while (current_column < line_size)
    {
        c = line[current_column];
        if (isalpha(c) || isdigit(c) || c == '_')
        {
            temp_str+=c;
            current_column++;
        }
        else
            break;
    }

    //now we get temp_str
    // a reserved word?

    current_token_str = temp_str;
    current_token = str2token(temp_str);

    switch (current_token)
    {
    case INTERNAL_NAME:
        current_token = CONST;
        current_value = this->module_name;
        break;
    case MPL_LITTLE_ENDIAN:
        current_token = CONST;
        current_value = ET_LITTLE_ENDIAN;
        break;
    case MPL_BIG_ENDIAN:
        current_token = CONST;
        current_value = ET_BIG_ENDIAN;
        break;
    default:
        break;
    }
    return current_token;
}


Token MplCode::lex_number()
{
    int v = 0;
    char c = line[current_column];

    if (c == '0')
    {
        current_column++;

        current_token_str ="0";
        c = line[current_column];

        if (c == 'x' || c == 'X')
        {
            current_column++;
            current_token_str += c; //x or X

            while (current_column < line_size)
            {
                c = line[current_column];


                if (c <= '9' && c >= '0')
                {
                    current_column++;
                    v = v * 16 + c - '0';
                }
                else if (c <= 'f' && c >='a')
                {
                    current_column++;
                    v = v * 16 + c - 'a' + 10;
                }
                else if (c <= 'F' && c >='A')
                {
                    current_column++;
                    v = v * 16 + c - 'A' + 10;
                }
                else
                {
                    break;
                }

                current_token_str += c;
            }
        }
        else  if ((c <= '7') && (c >= '0'))//octal
        {
            //octal number
            while (current_column < line_size)
            {
                c = line[current_column];
                if (c <= '7' && c >= '0')
                {
                    current_column++;
                    v = v * 8 + c - '0';
                    current_token_str += c;
                }
                else
                {
                    break;
                }
            }
        }
    }
    else  //decimal
    {

        current_token_str ="";

        while (current_column < line_size)
        {
            c = line[current_column];

            if (c <= '9' && c >= '0')
            {
                current_column++;
                current_token_str += c;
                v = v * 10 + c - '0';
            }
            else
            {
                break;
            }
        }
    }
    current_value = v;
    return current_token = CONST;

}


Token MplCode::lex_literal_string()
{
    char c;
    current_token_str = "";
    current_column++;  // "


    while (current_column < line_size)
    {
        c = line[current_column];
        if (c == '\\')
        {
            current_column++;

            if (current_column < line_size)
            {
                c = line[current_column];
                switch (c)
                {
                case '"':
                case '\\':
                case '\'':
                    current_column++;
                    current_token_str += c;
                    break;
                case 'r':
                    current_column++;
                    current_token_str += '\r';
                    break;

                case 'n':
                    current_column++;
                    current_token_str += '\n';
                    break;
                case 't':
                    current_column++;
                    current_token_str += '\t';
                    break;
                default:
                    current_column++;
                    current_token_str += c;
                    break;
                }
            }
            else
            {
                current_token_str += '\\';
                break;
            }
        }
        else if (c == '\"')
        {
            current_column++;
            current_token = CONST;
            current_value = current_token_str;
            return current_token;
            break;
        }
        else
        {
            current_column++;
            current_token_str += c;
        }

    }

    CompileError e(err_unexpected_end_of_line,0,0,"unterminated literal string");
    emit_compile_err_info(e);
    return current_token = CONST;
}

Token MplCode::lex_const_char()
{
    char c;
    current_column++;  // '
    current_value = 0;

    if (current_column >= line_size)
    {
        CompileError e(err_unexpected_end_of_line, 0, 0 ,"unterminated const character definition");
        emit_compile_err_info(e);
        return current_token = CONST;
    }

    c = line[current_column];
    if (c == '\\')
    {
        current_column++;

        if (current_column >= line_size)
        {
            CompileError e(err_unexpected_end_of_line, 0, 0 ,"unterminated const character definition");
            emit_compile_err_info(e);
            return current_token = CONST;
        }
        else
        {
            c = line[current_column];
            switch (c)
            {
            case '"':
            case '\'':
            case '\\':
                current_column++;
                current_value = c;
                break;
            case 'r':
                current_column++;
                current_value = '\r';
                break;
            case 'n':
                current_column++;
                current_value = '\n';
                break;
            case 't':
                current_column++;
                current_value = '\t';
                break;
            default:
                //TBC warning
            {
                //CompileError e(err_unknown_escape_character, c,0,"");
                //emit_compile_err_info(e);
                current_column++;
                current_value = c;
                break;
            }
            }
        }
    }
    else if (c == '\'')
    {
        //error, incomplete const char
        current_column++;
        CompileError e(err_incorrect_const_char_defined, 0,0,"");
        emit_compile_err_info(e);

        return current_token = CONST;
    }
    else
    {
        //ok
        current_column++;
        current_value = c;
    }

    if (current_column >= line_size)
    {
        CompileError e(err_unexpected_end_of_line, 0, 0 ,"unterminated const character definition");
        emit_compile_err_info(e);
        return current_token = CONST;
    }

    c = line[current_column];
    if (c != '\'')
    {
        //error, incomplete const char
        CompileError e(err_incorrect_const_char_defined, 0,0,"");
        emit_compile_err_info(e);
    }

    //ok
    current_column++;
    return current_token = CONST;

}


Token MplCode::next_token()
{
    Token t = next_token_internal();
    //std::cout<<token2Name(t)<<std::endl;
    return t;
}


Token MplCode::next_token_internal()
{
    char c;

    while (1)
    {
        if (pending_token.size() > 0)
        {
            current_token = pending_token.top();
            pending_token.pop();
            return current_token;
        }

        if (end_of_file)
        {
            if (src_file_context_stack.size() == 0)
                return current_token = END_MARKER;
            else
            {
                restore_last_file_pos();
                src_file_name_stack.pop_back();
                return current_token;
            }
        }

        c = line[current_column];

        switch (c)
        {
        case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
        case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n':
		case 'o': case 'p': case 'q': case 'r': case 's': case 't':
		case 'u': case 'v': case 'w': case 'x': case 'y': case 'z':
		case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G':
		case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N':
		case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T':
		case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z':
		case '_':
            return lex_name();

        case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
            return lex_number();
            break;
        case '#':
        case '\0':
        case '\n':
        case '\r':
            next_line();
            break;

        case ' ':
        case '\t':
            current_column++;
            break;

        case '\"':
            return lex_literal_string();
        case '\'':
            return lex_const_char();
        case '+':
            current_column++;
            return current_token = ADD;
        case '-':
            current_column++;
            return current_token = SUB;
        case '/':
            current_column++;
            return current_token = DIV;
        case '*':
            current_column++;
            return current_token = MUL;
        case '%':
            current_column++;
            return current_token = MOD;
        case '!':
            if ((current_column + 1 < line_size) && (line[current_column + 1] == '='))
            {
                current_column+=2;
                return current_token = NOT_EQUAL;
            }
            else
            {
                current_column++;
                return current_token = NOT;
            }

        case '=':
            current_column++;
            if ((current_column < line_size) && (line[current_column] == '='))
            {
                current_column++;
                return current_token = EQUAL;
            }
            return current_token = ASSIGN;

        case '>':
            current_column++;
            if ((current_column < line_size) && (line[current_column] == '='))
            {
                current_column++;
                return current_token = GREATER_OR_EQUAL;
            }

            return current_token = GREATER_THAN;

        case '<':
            current_column++;
            if ((current_column < line_size) && (line[current_column] == '='))
            {
                current_column++;
                return current_token = LESS_OR_EQUAL;
            }
            return current_token = LESS_THAN;
        case '&':
            current_column++;
            if (current_column < line_size && line[current_column] == '&')
            {
                current_column++;
                return current_token = AND;
            }
            else
                return current_token = BIT_AND;
        case '|':
            current_column++;
            if (current_column < line_size && line[current_column] == '|')
            {
                current_column++;
                return current_token = OR;
            }
            else
            {
                return current_token = BIT_OR;
            }
        case ':':
            current_column++;
            return current_token = COLON;
        case ',':
            current_column++;
            return current_token = COMMA;
        case ';':
            current_column++;
            return current_token = SEMICOLON;
        case '(':
            current_column++;
            return current_token = LEFT_PRNTH;
        case ')':
            current_column++;
            return current_token = RIGHT_PRNTH;
        case '.':
            current_column++;
            return current_token = DOT;
        case '@':
            current_column++;
            return current_token = AT;
        case '[':
            current_column++;
            return current_token = LEFT_BRACKET;
        case ']':
            current_column++;
            return current_token = RIGHT_BRACKET;
        default:
            current_column++;
            return current_token = UNKNOWN;
            break;
        }
    }

    // the program  never reach here
    return current_token = UNKNOWN;
}


/*
  1) establish index to all message, sub-message parse action
  2) parse all global constant definition, global v-n-list definition
  3) locate the first execution line
*/

int MplCode::match(Token token)
{
    if (current_token == token)
    {
        next_token();
    }
    /*
      else if ((current_token == END_MARKER) && (token == DEDENT))
      {
      //do nothing
      return 0;
      }
    */

    else
    {
        CompileError e(err_expect_token, token, current_token, "");

        if (current_token == END_MARKER)
        {
            throw e;
        }
        else
        {
            emit_compile_err_info(e);
            //next_line();
            next_token();
            //throw e;
        }
    }
    return 0;
}

