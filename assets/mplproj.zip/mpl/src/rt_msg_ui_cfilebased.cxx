#include <iostream>

#include <vector>
#include <string>
#include <memory>
#include "value.h"
#include "raw_memory.h"
#include "str_manager.h"
#include "msg_node.h"
#include "msg_node.h"
#include "settings.h"

// replace '_' with a space ' '
std::string beautify_name(std::string name)
{
    for (unsigned int i = 0; i < name.size(); i++)
    {
        if (name[i] == '_')
            name[i] = ' ';
    }

    return name;
}
///////////////////////////////////////////////////////////////////////////

int print_mem_little_endian(FILE* fout, IRawMemory *mem, MemPos start, MemPos end, int octets_per_line)
{

    // at most 4 octest per line, at least 1

    if (octets_per_line > 4)
        octets_per_line = 4;

    if (octets_per_line < 1)
        octets_per_line = 1;


    if (start == end)
    {
        int i;
        for (i=0; i < octets_per_line; i++)
            fprintf(fout, "........ ");
        return 0;
    }

    // calculate bytes range to be printed
    MemPos p = start;
    if ((p.octet % octets_per_line) > 0) p.octet -= p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_start = p;

    p = end;
    if (p.bit != 0)
    {
        p.octet++;
        p.bit=0;
    }
    if ((p.octet % octets_per_line) > 0 ) p.octet += octets_per_line - p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_end = p;

    // one type a time
    p = p_start;
    while (p.octet < p_end.octet)
    {
        char str_buf[] = "........";

        for (int j = 0; j < 8; j++)
        {
            MemPos temp_pos(p.octet, j);
            if (temp_pos < start)
            {
            }
            else if (temp_pos < end)
            {
                str_buf[7-j] = '0'+mem->bit_at(temp_pos, ET_LITTLE_ENDIAN);
            }
            else
            {
            }
        }

        fprintf(fout, "%s ", str_buf);
        p.octet++;

        //print seperator
        if (p < p_end)
        {
            if (p.octet % octets_per_line == 0)
                fprintf(fout, "\n\t\t");

        }

    }

    return 0;
}


int print_mem_big_endian(FILE *fout, IRawMemory *mem, MemPos start, MemPos end, int octets_per_line)
{
    if (octets_per_line > 4)
        octets_per_line = 4;

    if (octets_per_line < 1)
        octets_per_line = 1;


    if (end < start || start == end)
    {
        int i;
        //      for (i=0; i < octets_per_line; i++)
        //	printf("-- ");

        // printf(" ");

        for (i=0; i < octets_per_line; i++)
            fprintf(fout, "........ ");
        // printf(" ");

        return 0;
    }


    // calculate bytes range to be printed
    MemPos p = start;
    if ((p.octet % octets_per_line) > 0) p.octet -= p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_start = p;

    p = end;
    if (p.bit != 0)
    {
        p.octet++;
        p.bit=0;
    }
    if ((p.octet % octets_per_line) > 0 ) p.octet += octets_per_line - p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_end = p;

    p = p_start;
    while (p < p_end)
    {
        //	printf("%02x ",mem->octet_at(p));

        for (;p.bit < 8; p.bit++)
        {
            if (p < start)
                fprintf(fout, ".");
            else if (p < end)
                fprintf(fout, "%d", int(mem->bit_at(p, ET_BIG_ENDIAN)));
            else
                fprintf(fout, ".");
        }
        fprintf(fout, " ");
        {
            p.bit = 0;
            p.octet+=1;

            if (p < p_end)
            {
                if (p.octet % octets_per_line == 0)
                    fprintf(fout, " \n\t\t");
            }
            else
            {
                break;
            }
        }
    }
    return 0;
}


int print_msg_text_layout(FILE* fout, MsgNodePtr  msg, IRawMemory *mem, int layer);

class MsgNodeTraverser_Print_FileBased: public MsgNodeTraverser
{
public:
    MsgNodeTraverser_Print_FileBased(FILE *fout_, IRawMemory *mem_, int layer_):
            fout(fout_), mem(mem_), layer(layer_)
    {
    }

    void operator()(MsgNodePtr  msg)
    {
        print_msg_text_layout(fout, msg, mem, layer);
    }
private:
    FILE *fout;
    IRawMemory *mem;
    int layer;
};




int print_msg_text_layout(FILE* fout, MsgNodePtr  msg, IRawMemory *mem, int layer)
{

    std::string header="";
    MplValue v;

    for (int tmp = 1; tmp < layer; tmp++)
    {
        header += " |";
    }

    if (msg->is_hidden() && !get_global_settings()->disable_hidden)
    {
        return 0; //dont show hidden variables
    }


    // don't print the fist layer message, which is always empty except annoying '|'
    if (layer)
    {
        // show mem
        if (!get_global_settings()->show_msg_only)
        {
            fprintf(fout, "%4d:%d-%4d:%d\t",
                msg->get_mem_pos_begin().octet, msg->get_mem_pos_begin().bit,
                msg->get_mem_pos_end().octet, msg->get_mem_pos_end().bit);

            if (msg->get_type() == MNT_VALUE)
            {
                if (msg->get_bits_endian() == ET_LITTLE_ENDIAN)
                    print_mem_little_endian(fout, mem, msg->get_mem_pos_begin(), msg->get_mem_pos_end(),get_global_settings()->octets_per_line);
                else
                    print_mem_big_endian(fout, mem, msg->get_mem_pos_begin(), msg->get_mem_pos_end(),get_global_settings()->octets_per_line);
            }
            else
            {
                for (int i = 0; i < get_global_settings()->octets_per_line; i++)
                    fprintf(fout, "         ");
            }
        }

        // show header
        fprintf(fout, "%s +-", header.c_str());

		if (layer > get_global_settings()->max_msg_level)
		{
			fprintf(fout, " ... (too much levels to print! give up.)\n");
			return 0;
		}

        if (get_global_settings()->remove_underscore)
            fprintf(fout, "%s", beautify_name(msg->get_name()).c_str());
        else
            fprintf(fout, "%s", msg->get_name().c_str());

		//parent for debug
		//o << "(p="<<(int)(msg->get_parent())<<")";

        fprintf(fout, msg->is_hidden()?"(i)":"");

        if (get_global_settings()->verbose)
        {
            fprintf(fout, msg->is_const()?"(c)":"");
            fprintf(fout, "(%c%c)",
                (msg->get_bytes_endian() == ET_BIG_ENDIAN ?'B':'L'),
                (msg->get_bits_endian() == ET_BIG_ENDIAN?'b':'l' ));
        }

        // show content
        switch (msg->get_type())
        {
        case MNT_FUNC_CONTEXT:
        case MNT_NODE:
        case MNT_LIST:
            if (msg->has_info())
                fprintf(fout, ": %s", msg->get_info().c_str());
            break;
        case MNT_VALUE:
            fprintf(fout, ": ");
            v = msg->get_value();
            if (get_global_settings()->verbose)
                fprintf(fout, "(%s)", MplValue::get_type_name(v.type).c_str());

            if (v.type == VT_INT)
            {
                if (get_global_settings()->hex)
                {
                    fprintf(fout, "0x");
                    print_value(fout, v, true);
                }
                else
                {
                    print_value(fout, v, false);
                }
            }
            else if (v.type == VT_CHAR || v.type == VT_WCHAR)
            {
                fprintf(fout, "'");
                print_value(fout, v);
                fprintf(fout, "'");
                //o <<"'"<<v<<"'";
            }
            else if (v.type == VT_STRING || v.type == VT_WSTRING)
            {
                fprintf(fout, "\"");
                print_value(fout, v);
                fprintf(fout, "\"");
                //o <<"'"<<v<<"'";
            }
            else if (v.type == VT_MSG_REF)
            {
                print_value(fout, v);
                if (!get_global_settings()->hide_msg_ref)
                    msg=v.value.msg_ref;
            }
            else
            {
                print_value(fout, v);
            }

            if (msg->has_info())
                fprintf(fout, ": %s", msg->get_info().c_str());
            break;
        }
        fprintf(fout, "\n");
    }


    // show sub msgs
    MsgNodeTraverser_Print_FileBased mt(fout, mem, layer+1);
    msg->traverse_children(mt);

    //show debug msg node
    if (msg->get_debug_node() && get_global_settings()->print_func_context)
    {
        print_msg_text_layout(fout, msg->get_debug_node(), mem, layer+1);
    }

    if (msg->get_assist_node() && get_global_settings()->print_func_context)
    {
        print_msg_text_layout(fout, msg->get_assist_node(), mem, layer+1);
    }


    return 0;
}



