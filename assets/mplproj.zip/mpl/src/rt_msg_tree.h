

#ifndef _RT_MSG_TREE_H_
#define _RT_MSG_TREE_H_
#include <vector>
#include <string>
#include <memory>
#include "value.h"
#include "raw_memory.h"
#include "str_manager.h"
#include "msg_node.h"


class RtMsgNode: public MsgNode
{
public:

    RtMsgNode(MsgNodeType _type, MsgNode* _parent,STR_ID id, int line=0);

    virtual ~RtMsgNode();

    MsgNodeType get_type() const {return type;}
    void set_mem_pos_begin(const MemPos &pos) {mem_pos_begin = pos;}
    MemPos get_mem_pos_begin()const{return mem_pos_begin; }

    void set_mem_pos_end(const MemPos &pos){mem_pos_end = pos;}
    MemPos get_mem_pos_end()const{return mem_pos_end;}

    void set_bits_endian(EndianType t){bits_endian = t;}
    EndianType get_bits_endian()const { return bits_endian;}

    void set_bytes_endian(EndianType t){bytes_endian = t;}
    EndianType get_bytes_endian()const { return bytes_endian;}

    void set_name(const std::string &str) {name = str;}
    std::string get_name()const {return name;}

    void set_info(const std::string &str){info = str; info_set = true;}
    bool has_info()const {return info_set;}
    std::string get_info()const {return info;}

    void set_value(const MplValue &v){value = v;}
    const MplValue& get_value()const {return value;}

    void set_hidden()      {attr |= MNA_HIDDEN; }
    bool is_hidden()const {return (attr & MNA_HIDDEN) != 0;}

    void set_const()      {attr |= MNA_CONST; }
    bool is_const()const  {return (attr & MNA_CONST) != 0; }
    void set_attr(MsgAttr _attr) {attr = _attr;}

    MsgNode* get_parent()const {return parent;}
    void set_parent(MsgNode* p) {parent = p;}

    int get_layer()const{return layer;}
    void set_layer(int l){layer = l;}

    void add_sub_item(MsgNodePtr msg);
    void add_sub_item(std::string name, MplValue v, MsgAttr mna=MNA_NORMAL,  STR_ID file_id=STR_ID_NULL, int line_no=0);
    void replace_sub_item(MsgNodePtr from, MsgNodePtr to);

    MsgNodePtr locate_name(std::string name, bool search_parent);
    MsgNodePtr child_at(unsigned int index);

    MsgNodePtr find_sub_item(std::string name);
    //int show_msg_content(std::ostream &o, IRawMemory *mem);
    void traverse_children(MsgNodeTraverser& traverser);
    int get_subitems_count()const {return sub_items_index;}
    int get_self_order()const {return self_order;}; // order in brothers

    MplValue get_ret_value()const;
    void set_ret_value(const MplValue &v);
    bool stopped()const   {return _returned;}
    void toggle_stopped() {_returned = true;}

    // debug part
    void set_src_code_info(STR_ID id, int line) {gnode_file_id = id, gnode_line_number = line;}
    std::string get_src_file_name()const {return get_str_manager()->get_str(gnode_file_id);}
    int get_src_line_number()const {return gnode_line_number;}
    //void set_debug_node(MsgNodePtr  msg) {if(debug_msg) delete debug_msg; debug_msg = msg;}
    void set_debug_node(MsgNodePtr msg) {debug_msg = msg; debug_msg->set_ripe();}
    MsgNodePtr get_debug_node()const{return debug_msg;}
    MsgNodePtr get_assist_node()const{return assist_msg;}
    // length guard
    LengthGuardType get_length_guard(int *limit);
    int set_length_guard(LengthGuardType lgt, int limit);
	void set_ripe() {ripe = true;} // mark as ripe
	bool is_ripe() {return ripe;}

	bool is_last_in_siblings()
	{
	    if (!get_parent())
            return true;
	    if ((get_self_order()+1) == get_parent()->get_subitems_count())
            return true;
        return false;
    }

public:
	int add_ref()
	{
		//std::cout<<"rtmsgnode add ref "<<name<<" "<<ref_count<<std::endl;
		return ++ref_count;
	}
	int release()
	{
		//std::cout<<"rtmsgnode rel ref "<<name<<" "<<ref_count<<std::endl;
		if (ref_count <=0)
			std::cerr<<"error on release rtmsgnode!!"<<std::endl;

		return --ref_count;
	}
	int get_ref() { return ref_count;}
private:
    MsgNodeType type;
    MemPos mem_pos_begin;  // start memory position of this whole message, including sub-items
    MemPos mem_pos_end;    // end memroy position

    // only mnt_value has true bits endian and bytes endian type
    EndianType bits_endian;  // default bits endian type for this message (subitems may have their own endian type)
    EndianType bytes_endian;  // default bytes endian type for this message (subitems may have their own endian type)

    std::string name; // message name
    bool info_set;
    std::string info; // extra information, for interpretatoin
    MplValue value;
    int sub_items_index; // index for sub-items, helper variable when generating set-objectes
    int self_order;      // order in brothers, the parent's sub_itmes_index when it's created
    MsgNode* parent; //parent cannot use smart-pointers, or the whole tree cannot be release automatically
                     //because of the loop-containment
    int layer;          // help printing stuctural msg tree

    // functions, sub-messages, vnldefs
    //typedef std::vector <MsgNodePtr > SubItemContainer;
    typedef std::vector <MsgNodePtr> SubItemContainer;
    SubItemContainer sub_items;

    MsgAttr attr;

private: //debug
    //MsgNodePtr  assist_msg; // for internal-info retrieving
	MsgNodePtr assist_msg;

    MplValue ret;       // for return -statement, for func call
    bool _returned;

    //debug info, the source file information who generates this message node.
    STR_ID gnode_file_id; // grammar node's file name
    int gnode_line_number;       // grammar node's line number

    //MsgNodePtr  debug_msg;
    MsgNodePtr debug_msg;

    LengthGuardType length_guard_type;
    int length_guard_value;

    bool ripe; // only ripe message is accessable

private:
	int ref_count;

};

/*
17Oct2009, changed the design of message length guard implementation.
*/
class MsgLenGuardHelperClass
{
public:
    MsgLenGuardHelperClass(IRawMemory *mem_):mem(mem_)
    {
        lgt = mem->get_length_guard(&lgv);
    }

    ~MsgLenGuardHelperClass()
    {
        mem->set_length_guard(lgt, lgv);
    }

private:
    IRawMemory *mem;
    LengthGuardType lgt; //lengtu guard type
    int lgv; //length guard value
};

/*
class MsgLenGuardHelper
{
public:
    MsgLenGuardHelper(MsgNodePtr msg_, IRawMemory *mem_):msg(msg_), mem(mem_)     {    }

    ~MsgLenGuardHelper()
    {
        LengthGuardType length_guard_type;
        int length_guard_value = 0;

        if (msg)
            length_guard_type = msg->get_length_guard(&length_guard_value);
		else
		{
			return; //do nothing TBC?
		}

        if (mem)
            mem->set_length_guard(length_guard_type, length_guard_value);
    }

private:
    MsgNodePtr msg;
    IRawMemory *mem;
};
*/

std::ostream & operator << (std::ostream &o, MsgNodePtr n);
#endif

