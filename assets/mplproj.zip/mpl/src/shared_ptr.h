
#if !defined _MPL_SHARED_PTR_
#define _MPL_SHARED_PTR_

// t should have 2 public methods: release, add_ref, both of them return reference count
template <class T>
class SharedPtr
{
public:
	virtual ~SharedPtr()
	{
		if (_p && (_p->release() == 0))
		{
			delete _p;
			_p = 0;
		}
	}

	SharedPtr()
	{
		_p = 0;
	}

	SharedPtr(T *p):_p(p)
	{
		if (_p) _p->add_ref();
	}

	SharedPtr(const SharedPtr<T> &p):_p(p._p)
	{
		if (_p) _p->add_ref();
	}

	SharedPtr<T> operator =(const SharedPtr<T> &p)
	{
		if (_p && (0 == _p->release()))
		{
			delete _p;
		}

		_p = p._p;
		if (_p)
			_p->add_ref();
		return *this;
	}
	SharedPtr<T> operator =(T *p)
	{
		if (_p && (0 == _p->release()))
		{
			delete _p;
		}

		_p = p;
		if (_p)
		    _p->add_ref();

		return *this;
	}

	bool operator == (const SharedPtr<T> &p)
	{
		return _p == p._p;
	}

	operator bool() {return _p!=0; }
	T* operator->() {return _p;}

	// methods to emulate auto_ptr<T>
	T* get()const {return _p;}
	T* release() { T *ret = _p; _p = 0; if (ret) ret->release(); return ret;}
private:
	T *_p;

};
#endif //_MPL_SHARED_PTR_
