#include <iostream>

#include <vector>
#include <string>
#include <memory>
#include "value.h"
#include "raw_memory.h"
#include "str_manager.h"
#include "msg_node.h"
#include "msg_node.h"
#include "settings.h"

extern std::string beautify_name(std::string name);

int print_mem_little_endian(std::ostream &o, IRawMemory *mem, MemPos start, MemPos end, int octets_per_line, int mem_pos_width, std::string &header)
{

    // at most 4 octest per line, at least 1

    if (octets_per_line > 4)
        octets_per_line = 4;

    if (octets_per_line < 1)
        octets_per_line = 1;


    if (start == end)
    {
        int i;
        for (i=0; i < octets_per_line; i++)
            o << "........ ";
        return 0;
    }

    // calculate bytes range to be printed
    MemPos p = start;
    if ((p.octet % octets_per_line) > 0) p.octet -= p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_start = p;

    p = end;
    if (p.bit != 0)
    {
        p.octet++;
        p.bit=0;
    }
    if ((p.octet % octets_per_line) > 0 ) p.octet += octets_per_line - p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_end = p;

    // one type a time
    p = p_start;
    while (p.octet < p_end.octet)
    {
        char str_buf[] = "........";

        for (int j = 0; j < 8; j++)
        {
            MemPos temp_pos(p.octet, j);
            if (temp_pos < start)
            {
            }
            else if (temp_pos < end)
            {
                str_buf[7-j] = '0'+mem->bit_at(temp_pos, ET_LITTLE_ENDIAN);
            }
            else
            {
            }
        }

        o <<str_buf;
        o <<" ";
        p.octet++;

        //print seperator
        if (p < p_end)
        {
            if (p.octet % octets_per_line == 0)
            {
                //o<<std::endl;
                o<<header<<" |"<<std::endl;
                for (int i = 0; i < mem_pos_width; i++)
                    o<<" ";
            }
        }

    }

    return 0;
}


int print_mem_big_endian(std::ostream &o, IRawMemory *mem, MemPos start, MemPos end, int octets_per_line, int mem_pos_width, std::string &header)
{
    if (octets_per_line > 4)
        octets_per_line = 4;

    if (octets_per_line < 1)
        octets_per_line = 1;


    if (end < start || start == end)
    {
        int i;
        //      for (i=0; i < octets_per_line; i++)
        //	printf("-- ");

        // printf(" ");

        for (i=0; i < octets_per_line; i++)
            o << "........ ";
        // printf(" ");

        return 0;
    }


    // calculate bytes range to be printed
    MemPos p = start;
    if ((p.octet % octets_per_line) > 0) p.octet -= p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_start = p;

    p = end;
    if (p.bit != 0)
    {
        p.octet++;
        p.bit=0;
    }
    if ((p.octet % octets_per_line) > 0 ) p.octet += octets_per_line - p.octet % octets_per_line;
    p.bit = 0;
    MemPos p_end = p;

    p = p_start;
    while (p < p_end)
    {
        //	printf("%02x ",mem->octet_at(p));

        for (;p.bit < 8; p.bit++)
        {
            if (p < start)
                o<<'.';
            else if (p < end)
                o<<int(mem->bit_at(p, ET_BIG_ENDIAN));
            else
                o<<'.';
        }
        o<<" ";
        {
            p.bit = 0;
            p.octet+=1;

            if (p < p_end)
            {
                if (p.octet % octets_per_line == 0)
                {
                    //o<<" "<<std::endl;
                    o<<header<<" |"<<std::endl;
                    for (int i = 0; i < mem_pos_width; i++)
                        o<<" ";
                }

            }
            else
            {
                break;
            }
        }
    }
    return 0;
}

int print_msg_text_layout_with_layer(std::ostream &o, MsgNodePtr  msg, IRawMemory *mem, int layer, std::string header, const char* mem_pos_fmt, int mem_pos_width);

class MsgNodeTraverser_Print_StreamBased: public MsgNodeTraverser
{
public:
    MsgNodeTraverser_Print_StreamBased(std::ostream &o_, IRawMemory *mem_, int layer_, std::string header_, const char* mem_pos_fmt_, int mem_pos_width_):
            o(o_), mem(mem_), layer(layer_), header(header_), mem_pos_fmt(mem_pos_fmt_), mem_pos_width(mem_pos_width_)
    {
    }

    void operator()(MsgNodePtr  msg)
    {
        print_msg_text_layout_with_layer(o, msg, mem, layer, header, mem_pos_fmt, mem_pos_width);
    }
private:
    std::ostream &o;
    std::string header;
    IRawMemory *mem;
    int layer;
    const char* mem_pos_fmt;
    int mem_pos_width;
};



int print_msg_text_layout_with_layer(std::ostream &o, MsgNodePtr  msg, IRawMemory *mem, int layer, std::string header, const char* mem_pos_fmt, int mem_pos_width)
{

    //std::string header="";
    MplValue v;

    for (int tmp = 1; tmp < layer; tmp++)
    {
        //header += " |";
    }

    if (msg->is_hidden() && !get_global_settings()->disable_hidden)
    {
        return 0; //dont show hidden variables
    }


    // don't print the fist layer message, which is always empty except annoying '|'
    if (layer)
    {
        // show mem
        if (!get_global_settings()->show_msg_only)
        {
            char mem_pos_str[32];
            snprintf(mem_pos_str, 32, mem_pos_fmt,
                     msg->get_mem_pos_begin().octet, msg->get_mem_pos_begin().bit,
                     msg->get_mem_pos_end().octet, msg->get_mem_pos_end().bit);
            o << mem_pos_str;

            if (msg->get_type() == MNT_VALUE)
            {
                if (msg->get_bits_endian() == ET_LITTLE_ENDIAN)
                    print_mem_little_endian(o, mem, msg->get_mem_pos_begin(), msg->get_mem_pos_end(),get_global_settings()->octets_per_line, mem_pos_width, header);
                else
                    print_mem_big_endian(o, mem, msg->get_mem_pos_begin(), msg->get_mem_pos_end(),get_global_settings()->octets_per_line, mem_pos_width, header);
            }
            else
            {
                for (int i = 0; i < get_global_settings()->octets_per_line; i++)
                    o << "         ";
                //		o << ;
            }
        }

        // show header
        o <<header<< " +-";

		if (layer > get_global_settings()->max_msg_level)
		{
			o<<" ... (too much levels to print! give up.)"<<std::endl;
			return 0;
		}

        if (get_global_settings()->remove_underscore)
            o << beautify_name(msg->get_name());
        else
            o<<msg->get_name();

		//parent for debug
		//o << "(p="<<(int)(msg->get_parent())<<")";

        o << (msg->is_hidden()?"(i)":"");

        if (get_global_settings()->verbose)
        {
            o << (msg->is_const()?"(c)":"");
            o << "(" << (msg->get_bytes_endian() == ET_BIG_ENDIAN ?'B':'L');
            o << (msg->get_bits_endian() == ET_BIG_ENDIAN?'b':'l' ) <<")";

        }

        // show content
        switch (msg->get_type())
        {
        case MNT_FUNC_CONTEXT:
        case MNT_NODE:
        case MNT_LIST:
            if (msg->has_info())
                o <<": " <<msg->get_info();
            break;
        case MNT_VALUE:
            o <<": ";
            v = msg->get_value();
            if (get_global_settings()->verbose)
                o<<"("<<MplValue::get_type_name(v.type) <<")";

            if ((v.type == VT_INT) && get_global_settings()->hex)
                o<<"0x";
            if (v.type == VT_CHAR || v.type == VT_WCHAR)
                o <<"'"<<v<<"'";
            else if (v.type == VT_STRING || v.type == VT_WSTRING)
                o<<'"'<<v<<'"';
            else if (v.type == VT_MSG_REF)
				{
					o<<v;
					if (!get_global_settings()->hide_msg_ref)
						msg=v.value.msg_ref;
				}
            else
                o<<v;

            if (msg->has_info())
                o <<": " << msg->get_info();
            break;
        }
        o<<std::endl;
    }



    // show sub msgs
    if (layer)
    {
        if (msg->is_last_in_siblings())
            header += "  ";
        else
            header += " |";
    }

    MsgNodeTraverser_Print_StreamBased mt(o, mem, layer+1, header, mem_pos_fmt, mem_pos_width);
    msg->traverse_children(mt);


    //show debug msg node
    if (msg->get_debug_node() && get_global_settings()->print_func_context)
    {
        print_msg_text_layout_with_layer(o, msg->get_debug_node(), mem, layer+1, header, mem_pos_fmt, mem_pos_width);
    }

    if (msg->get_assist_node() && get_global_settings()->print_func_context)
    {
        print_msg_text_layout_with_layer(o, msg->get_assist_node(), mem, layer+1, header, mem_pos_fmt, mem_pos_width);
    }


    return 0;
}


int print_msg_text_layout(std::ostream &o, MsgNodePtr  msg, IRawMemory *mem)
{
    int mem_pos_width;
    int last_pos = mem->size();//msg->get_mem_pos_end().octet;

    if (last_pos < 10)
        mem_pos_width = 1;
    else if (last_pos < 100)
        mem_pos_width = 2;
    else if (last_pos < 1000)
        mem_pos_width = 3;
    else if (last_pos < 10000)
        mem_pos_width = 4;
    else
        mem_pos_width = 5;


    char mem_pos_fmt[32];

    snprintf(mem_pos_fmt, 32, "%%%dd:%%d-%%%dd:%%d  ",mem_pos_width, mem_pos_width);

    return print_msg_text_layout_with_layer(o, msg, mem, 0, "", mem_pos_fmt, (mem_pos_width+2)*2+1+2);
}

