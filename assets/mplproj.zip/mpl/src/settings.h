

#ifndef _mpl_setting_h_
#define _mpl_setting_h_

#include "raw_memory.h"
#include <list>
#include <string>

/*
steps to all new options:
1. add help info
2. add definition
3. add initialization
4. add option anaylzing
*/

class GlobalSetting
{
private:

    GlobalSetting();
    ~GlobalSetting();
public:
	void reset();
	bool source_from_stdin;
    bool only_check_grammar;
    bool print_grammar;
    bool verbose;
    bool help;
    bool version;
    bool disable_hidden ;
    bool print_func_context ;
    bool show_msg_only;
    bool debug;
    bool hex;
    bool no_mem;  //run without raw stream data
    bool remove_underscore;
    bool hide_msg_ref; //hide msg_ref, don't extend them when outputting
    bool no_0x; // raw stream data don't have prefix '0x', which means all numbers are hex
    int octets_per_line; // control message printing
    int max_msg_level;

    EndianType bit_endian;
    EndianType byte_endian;

    std::string source_file_name;
    std::string mem_file_name;
    std::list<std::string> search_path_list;

    int cmd_line_parse(int argc, const char* const argv[]);
    static GlobalSetting* get_object();
private:
    bool s_ready ;
private:
    int print_help();
    int print_help_ind();
    int print_version();

private:
    static GlobalSetting obj;
};

GlobalSetting* get_global_settings();

#endif //_mpl_setting_h_
