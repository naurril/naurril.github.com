#ifndef _MPL_GRAMMAR_H_
#define _MPL_GRAMMAR_H_

#include <memory>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <deque>

#include "value.h"
#include "shared_ptr.h"
#include "str_manager.h"
//reserved internal variables


#define  __MPL_MAIN__           "__main__"
#define  __MPL_NAME__           "__name__"
#define  __MPL_BIG_ENDIAN__     "__big_endian__"
#define  __MPL_LITTLE_ENDIAN__  "__little_endian__"

#define  __MPL_VNL_VALUE__      "__vnl_value__"
#define  __MPL_INFO__           "__info__"
#define  __MPL_SIZE__           "__size__"


typedef enum
{
    NT_INVALID = 0,
    NT_IMPORT_STMT,
    NT_STMT_SEQ,
    //NT_SIMPLE_STMT,
    NT_IF_STMT,
    NT_WHILE_STMT,
    NT_FOR_STMT,
    NT_TRY_LOOP,
    NT_INTERPRET_STMT,
    NT_RUNSWITCH_STMT,
    NT_ASSIGN_STMT,
    NT_SUB_MSG_CALL,
    NT_FUNC_CALL,
    //NT_ASSERT_STMT,
    //NT_CHECK_STMT,
    NT_RETURN_STMT,
    NT_BREAK_STMT,
    NT_CONTINUE_STMT,
    NT_OR_TEST,
    NT_AND_TEST,
    NT_CMP_EXP,
    NT_ARITH_EXP,
    NT_TERM_EXP,
    NT_UNARY_EXP,
    NT_VARIABLE,
    NT_CONST,
    NT_QUALIFIED_NAME,    // a.b, a[1].b, a.b[1], at least one dot
    NT_PURE_INDEXED_NAME, // a[], b[][][], no bot, at least one bracket pair
    NT_NAME, //different from dotted name
    // special
    NT_FIXED_SPECIFIER,
    NT_OPTIONAL_SPECIFIER,
    NT_MULTIPLE_SPECIFIER,
    NT_VNL_DEF,
    NT_MSG_DEF,
    NT_FUNC_DEF,
    NT_PARA_LIST,
    NT_END_OF_ENUM

}NodeType;

#define IS_SPECIFIER(n) (((n)== NT_FIXED_SPECIFIER) ||((n)== NT_OPTIONAL_SPECIFIER) ||((n)== NT_MULTIPLE_SPECIFIER))
#define IS_ARRAY_SPECIFIER(n) (((n)== NT_FIXED_SPECIFIER) ||((n)== NT_MULTIPLE_SPECIFIER))

#define IS_EXPR_NODE(n) (  (n) == NTNT_ARITH_EXP \
                        || (n) == NT_TERM_EXP\
                        || (n) == NT_VARIABLE\
                        || (n) == NT_NUMBER\
                        || (n) == NT_QUALIFIED_NAME\
                        || (n) == NT_NAME\
                        )

#define IS_LOOP_CONTEXT_STMT(n)  (   (n) == NT_WHILE_STMT \
									||(n) == NT_FOR_STMT \
									||(n) == NT_TRY_LOOP)
enum Token
{
    UNKNOWN,
    PHONY_STUB,
    ADD, SUB,
    MUL, DIV, MOD,
    AND, OR, NOT,
    BIT_OR, BIT_AND, BIT_XOR,
    DOT,AT,
    LEFT_BRACKET, RIGHT_BRACKET, //[]
    END_MARKER,
    IMPORT,
    COLON, SEMICOLON, COMMA,
    LEFT_PRNTH, RIGHT_PRNTH,  //( )


    //LEFT_BRACE, RIGHT_BRACE, // {}

    //LITERAL_STRING,
    VNL_DEF, MSG_DEF, FUNC_DEF,    //def
    INDENT,  DEDENT,
    //DOTTED_NAME,
    NAME,
    //NUMBER,
    CONST,
    OPTIONAL,
    FIXED,
    MULTIPLE,
    NOP,
    IF,  ELIF,  ELSE,
    FOR, WHILE, TRY_LOOP,
    RETURN,
    BREAK, CONTINUE,
    DEFAULT,

	//ASSERT, CHECK,
	STRING,

    ASSIGN,
    LESS_THAN, GREATER_THAN, EQUAL, NOT_EQUAL, LESS_OR_EQUAL, GREATER_OR_EQUAL,
    INTERPRET,RUN_SWITCH,
    INTERNAL_NAME,
    MPL_BIG_ENDIAN,
    MPL_LITTLE_ENDIAN,
};

typedef struct _TokenName
{
    const char* name;
    Token token;
}NameTokenPair;


// node attributes definitoin
#define NA_HIDDEN        0x00000001
#define NA_NON_LOCAL    0x00000002

//char* token2Name(Token token);
extern const char* NodeTypeName[NT_END_OF_ENUM];


// one gnode represents a msg definition
// the statements in it direct the msg parsing
// so general speaking, a source file without explicitly defining a messasge actually
//  defined an un-named message, in this case ,we should give it a default global name.
class GNode
{
public:
    //GNode():parent(NULL), type(NT_INVALID) {}
    GNode(NodeType _type, std::string _name, STR_ID src_file_id, int _src_line, GNode* _p=NULL);
    virtual ~GNode();
    int add_node(GNode* p);
    GNode* locate_subdef_node(GNode* g); //search sub-msg,sub-vnl
    GNode* locate_subdef_node_by_name(std::string name);
    void set_position(STR_ID file_id, int _src_line);
    std::string get_full_name(); //generate qualified name
    std::string get_target_name(); //get the most significant name, for a.b.c, we get only c

	// methods to support SharedPtr
	int add_ref(){ return  ++ref_count;}
	int release(){ return  --ref_count;}
public:
    NodeType  type;
    std::string name;

    //std::string src_file_name;
    STR_ID  src_file_id;
    int src_line_number;

    // remember imported file list, to detect repeated import. 22Jul2010, lie
    typedef std::deque<STR_ID> IMPORTED_FILE_ID_STACK; // file name stack
    IMPORTED_FILE_ID_STACK imported_file_stack;

    //std::vector<GNode*>  stmts;  //statement sequence
    typedef std::map<std::string, GNode*> MSG_MAP;
    MSG_MAP sub_defs;    //sub messages
    //std::map<std::string, int> consts; //const definition

    // value-name list
    typedef std::map<int, std::string> VNL; //value-name list
    VNL vnl;                     //value-name-list, for vnl node itself
    GNode *vnl_default_handler;  //name, qualified-name, or literal-string

    // value-statements list
    typedef std::map<int, GNode*> VSL; //value-statement list
    VSL vsl;                     // value-statement list, for runswitch
    GNode *vsl_default_handler;  //default statements

    // integrate vnls into sub_msgs
    // typedef std::map<std::string, GNode*> VNL_MAP;
    // VNL_MAP vnls;             //list of value-name-list

    std::vector<Token> tokens;  //for expression
    GNode *parent;                          //parent
    //int para;                        //for const declaration
    std::vector<GNode*> children;
    //std::vector<std::string> dotted_name;
    MplValue  value;  // for number node;



    int layer; // for dump format, helper variable

    unsigned long attr;
    static int node_count;
    int ref_count; //support SharedPtr
};

//typedef std::auto_ptr<GNode> GNodeAutoPtr;
typedef SharedPtr<GNode> GNodeAutoPtr;
std::ostream& operator << (std::ostream& o, GNode *p);
Token str2token(std::string name);
const char* token2Name(Token token);

#endif
