

#if !defined _MPL_STR_MANAGER_H_
#define _MPL_STR_MANAGER_H_
#include <vector>
#include <string>

typedef int STR_ID;

#define STR_ID_NULL   0
#define STR_ID_STDIN  1

class StringManager
{
private:
    StringManager()  { store_new_str("");store_new_str("stdin");}
    ~StringManager() { if (str_manager) delete str_manager; }

public:
    STR_ID store_new_str(const char* str); // file name, or path name, any string.
    const char* get_str(STR_ID str_id);
    static StringManager* get_manager();
private:
    std::vector<std::string> str_store;

    static StringManager *str_manager;
};


StringManager* get_str_manager();
const char* id2str(STR_ID);

#endif /* _MPL_STR_MANAGER_H_ */
