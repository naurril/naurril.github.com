#ifndef _MPL_CODE_
#define _MPL_CODE_


#include <iostream>
#include <stack>
#include <fstream>
#include <vector>
#include <string>
#include <map>


#include "raw_memory.h"
#include "rt_msg_tree.h"
#include "value.h"
#include "grammar_node.h"
#include "error.h"
#include "str_manager.h"

typedef struct LexContext
{
    int current_line;
    int current_column;
    int current_indent;

    Token current_token;
    std::string current_token_str;
    MplValue current_value;
    int err_code;
    bool end_of_file;
}LexContext;

typedef struct PendingToken
{
	Token type;
	int number;
	PendingToken() {number = 0;}
	Token push(Token t)
	{
		if (number!=0 && type !=t)
		{
			std::cerr<<"pending token misuse!!!!"<<std::endl;
			throw 12345678;
		}

		type = t; number++;
		return t;
	}
	void pop(){number--;}
	Token top(){return type;}
	int size() {return number; }
	void clean() {number = 0; }
}PendingToken;

typedef struct SrcFileContext
{
    STR_ID  file_id;
    STR_ID  path_id;

    std::string module_name;

    FILE* in;
    std::string line;
    int current_column;
    int current_line;
    bool end_of_file;

    std::stack<int> indent_stack;
    PendingToken pending_token;

    Token current_token;
    std::string current_token_str;
    MplValue current_value;

}SrcFileContext;


class MplCode
{
public:
    MplCode(std::ostream &_out = std::cout, std::ostream &_err = std::cerr);
    //int start(IRawMemory *mem);
    //int read_src_file(char *fileName);
	enum InputType {INPUT_FILE, INPUT_STRING};
    GNode* parse(const char* src, InputType type);
    int get_errors()const {return total_errors;}
    int get_warnings()const {return total_warnings;}

    //GNode *get_grammar() {return &top_grammar_node;}
    //std::string &get_line(int n)  {return lines[n];}


private:
    int set_src_file(const char* filename);
    int set_src_codes(const char*src);
    Token next_token();
    Token next_token_internal();
    bool is_empty_line(const char *str);
    int next_line();
    int match(Token token);


    GNode* mpl();
    GNode* stmt(GNode* p);
    GNode* stmt_seq(GNode* p);
    GNode* simple_stmt(GNode* p);
    GNode* simple_stmt_with_specifier(GNode* specifier, GNode* p);
    //GNode* compound_stmt();
    //GNode* small_stmt();
    GNode* expr_stmt();
    GNode* or_test();
    GNode* and_test();
    GNode* cmp_exp();
    GNode* arith_exp();
    GNode* term_exp();
    GNode* factor();
    GNode* unary_exp();

    GNode* func_call(GNode* func_name, GNode* specifier = 0);
    GNode* import_stmt(GNode* p);
    GNode* if_stmt(GNode* p);
    GNode* while_stmt(GNode* p);
    GNode* try_loop_stmt(GNode *p);
    GNode* for_stmt(GNode* p);
    GNode* interpret_stmt();
    GNode* runswitch_stmt();
    GNode* vnl_def(GNode* p);
    GNode* msg_def(GNode* p);
    GNode* func_def(GNode* p);
    GNode* qualified_name(std::string fist_name);
    GNode* specifier();
	GNode* check_stmt();
	GNode* assert_stmt();
	GNode* return_stmt(GNode* p);
	GNode* break_stmt(GNode* p);
	GNode* continue_stmt(GNode* p);
	//GNode* special_assignment();
	void drain_semicolon();
	int check_def_repetition(GNode *parent, GNode *def);
	bool is_loop_context_stmt(GNode* g);
    // helper funcs
    void print_in_file_stack();
    int emit_compile_err_info(CompileError &e, bool throwable=true);
    int emit_compile_warning_info(CompileError &e);
private:
    void print_current_spot(std::ostream &out);
    std::string search_file(const char* file_name, const char* first_path) const;
    std::string get_abs_file_path(const std::string &relative_path);




    //typedef std::vector<std::string> Lines;

    int save_current_file_pos();
    int restore_last_file_pos();
    //Lines lines;

    //helper funcs
    GNode* create_new_gnode(NodeType type, std::string name, GNode* p=NULL);
    void record_node_position(GNode* g);
    void record_node_position(GNode* g, int line_number);
    const char* id2str(STR_ID id) {return get_str_manager()->get_str(id);}
    std::string & file_2_path(std::string &name);

private:
	const char* read_line_from_src(char* buf, size_t size); //abstract readline from file or string

    //lex
    Token lex_name();
    Token lex_number();
    Token lex_literal_string();
    Token lex_const_char();
    int filter_comments();
private:

    int current_indent;
    std::stack<int> indent_stack;
    PendingToken pending_token;
    Token current_token;
    std::string current_token_str;
    MplValue current_value;

    int current_line;
    unsigned int current_column;

    //std::string line;        // current line string
    #define MAX_LINE_SIZE 1024
    char line[MAX_LINE_SIZE];
    unsigned int line_size;
    //std::string file_name;   // current file name (absolute file path name)
    STR_ID  file_id;
    STR_ID  path_id;

    std::string module_name; //
    //std::string file_path;   // path which contains the current file


    typedef std::deque<SrcFileContext> SRC_FILE_CONTEXT_STACK;
    SRC_FILE_CONTEXT_STACK src_file_context_stack;

    typedef std::deque<STR_ID> SRC_FILE_ID_STACK; // file name stack
    SRC_FILE_ID_STACK src_file_name_stack;


    //std::ifstream* in;
    FILE *input_file;
    const char* src_codes;
    int src_codes_index;

    //int err_code;
    bool end_of_file;

    int total_errors;
    int total_warnings;

private:
    std::ostream &o_out;
    std::ostream &o_err;
};


#endif
