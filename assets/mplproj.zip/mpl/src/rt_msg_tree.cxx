#include <iostream>
#include <algorithm>
#include "rt_msg_tree.h"
#include "settings.h"
#include "grammar_node.h"
#include "raw_memory.h"

int MsgNode::msg_count = 0;


RtMsgNode::RtMsgNode(MsgNodeType _type, MsgNode*  _parent ,STR_ID file_id, int line):
        type(_type),
        parent(_parent),
        gnode_file_id(file_id),
        gnode_line_number(line),
        debug_msg(NULL)
{
    //value = 0; don't initialize value so its type keeps as NT_NON_TYPE

    mem_pos_begin.octet = 0;
    mem_pos_begin.bit = 0;
    mem_pos_end = mem_pos_begin;
    sub_items_index = 0;
    _returned = false;
    attr = 0;

    assist_msg = NULL;
    info_set = false;
    ripe = false;

    bytes_endian  = bits_endian = ET_BIG_ENDIAN;


    length_guard_type = GUARD_NONE;
    length_guard_value = 0;

	// layer is used to detect deadloop msg invoking.
	// so it must be assigned at creation time
	layer = 0;
    if (parent)
        layer = parent->get_layer()+1;
    //else
    //    layer = 0;
    ref_count = 0;

    if (layer > get_global_settings()->max_msg_level)
    {
        //delete this;
        throw RuntimeError(err_suspicious_dead_loop_detected, line, 0, id2str(file_id));
    }

    if (parent)
        self_order = parent->get_subitems_count();
    else
        self_order = 0;

    msg_count++;
}

RtMsgNode::~RtMsgNode()
{
    /*
    for (std::vector<MsgNodePtr>::iterator i = sub_items.begin();
        i != sub_items.end(); i++)
    {
        delete *i;
    }
    */

    //if (debug_msg) delete debug_msg;
    msg_count--;

    //if (assist_msg) delete assist_msg;

    //std::cout<<"rtmsgnode deleted!"<<std::endl;
}

/*
std::ostream & operator << (std::ostream &o, RtMsgNodePtr n)
{

    std::string header;
    if (n->parent)
        n->layer = n->parent->layer + 1;
    for (int tmp = 0; tmp < n->layer; tmp++)
    {
        header += " | ";
    }

    if (n->type == MNT_NODE || n->type == MNT_LIST)
        o << n->name<<std::endl;
    else
        o <<n->name <<":"<<n->value<<":"<<n->info<<std::endl;
    for (std::vector<RtMsgNodePtr >::iterator i = n->sub_items.begin();
        i != n->sub_items.end(); i++)
    {
        o << (*i)->mem_pos.octet<<':'<<(*i)->mem_pos.bit<<":" <<header<< " +-" << *i;
    }

    return o;
}
*/


class cmp_pred_helper
{
public:
    cmp_pred_helper(std::string _name): name(_name){}
    bool operator() (MsgNodePtr  msg)
    {
        return name == msg->get_name();
    }
private:
    std::string name;
};

MsgNodePtr RtMsgNode::find_sub_item(std::string name)
{
    std::vector<MsgNodePtr>::iterator i
    = find_if(sub_items.begin(), sub_items.end(), cmp_pred_helper(name));
    if (i != sub_items.end())
    {
        return *i;
    }
    else
    {
        return 0;
    }
}

// locate msg name from the current msg node
// 1) find in sub-items
// 2) check if it's finding itself if search_parent
// 3) go up to the parent level, and repeat 1) and 2)
MsgNodePtr  RtMsgNode::locate_name(std::string name, bool search_parent)
{

    //special case for __info__ and __size__
    // assist_msg shouldn't have such internal variables
    if ((this->parent) && (this != this->parent->get_assist_node().get()))
    {
        if (name == __MPL_INFO__)
        {
            if (!this->assist_msg)
                this->assist_msg = new RtMsgNode(MNT_VALUE, this, STR_ID_NULL);
            this->assist_msg->set_value(this->info);
            this->assist_msg->set_const();
            this->assist_msg->set_name(name+"(assist-node)");
            this->assist_msg->set_ripe();
            return this->assist_msg;
        }

        if (name == __MPL_SIZE__)
        {
            if (!this->assist_msg)
                this->assist_msg = new RtMsgNode(MNT_VALUE, this, STR_ID_NULL);
            int size;

            if (this->get_type() == MNT_VALUE && get_value().type == VT_STRING)
            {
                size = get_value().value.s.size();
            }
            else
            {
                size = this->sub_items.size();
            }

            this->assist_msg->set_value(size);
            this->assist_msg->set_const();
            this->assist_msg->set_name(name+"(assist-node)");
            this->assist_msg->set_ripe();
            return this->assist_msg;
        }
    }

    MsgNodePtr  p = this;

    while (p)
    {

        MsgNodePtr  n = p->find_sub_item(name);

        if (n)
        {
            p = n;
            break;
        }



        if (search_parent)
        {
        	//is this necessary?
			if (p->get_name() == name)
				break;
			else
			    p = p->get_parent();
        }
        else
        {
            p = NULL;
            break;
        }
    }

    // handle msg reference
    if (p)
    {
        if (p->get_type() == MNT_VALUE && p->get_value().type == VT_MSG_REF)
        {
            p = p->get_value().value.msg_ref;
        }
    }

    return p;
}

MsgNodePtr  RtMsgNode::child_at(unsigned int index)
{
    MsgNodePtr  p = NULL;

    if (sub_items.size() > index)
    {
        p = sub_items[index];
    }

    // handle msg reference
    if (p)
    {
        if (p->get_type() == MNT_VALUE && p->get_value().type == VT_MSG_REF)
        {
            p = p->get_value().value.msg_ref;
        }
    }

    // consider a string as an array of chars
    if (!p)
    {
        if (this->get_type() == MNT_VALUE)
        {
            MplValue v = this->get_value();

            if (v.type == VT_STRING)
            {
                if (index < v.value.s.size())
                {
                    if (!this->assist_msg)
                        this->assist_msg = new RtMsgNode(MNT_VALUE, this, STR_ID_NULL);
                    this->assist_msg->set_value(v.value.s[index]);
                    this->assist_msg->set_const();
                    this->assist_msg->set_name(name+"(assist-node)");
                    this->assist_msg->set_ripe();
                    p = assist_msg;
                }
            }
        }
    }

    return p;
}


void RtMsgNode::add_sub_item(MsgNodePtr msg)
{
    msg->set_parent(this);
    sub_items.push_back(msg);
    sub_items_index++;
}


void RtMsgNode::add_sub_item(std::string name, MplValue v, MsgAttr mna, STR_ID file_id, int line_no)
{
    MsgNodePtr  m = new RtMsgNode(MNT_VALUE, this, file_id, line_no);
    m->set_name(name);
    m->set_value(v);
    m->set_attr(mna);
    sub_items.push_back(m);
    sub_items_index++;
    m->set_ripe();

}


void RtMsgNode::replace_sub_item(MsgNodePtr  from, MsgNodePtr  to)
{
    unsigned int i;
    for (i = 0; i < sub_items.size(); i++)
    {
        if (sub_items[i] == from)
        {
            //delete from;
            sub_items[i] = to;
            to->set_parent(this);
            //adjust layer value
            to->set_layer(this->get_layer()+1);
            break;
        }
    }
}


void RtMsgNode::traverse_children(MsgNodeTraverser& traverser)
{
    for (SubItemContainer::iterator i = sub_items.begin();
            i != sub_items.end(); i++)
    {
        traverser(*i);
    }
}

MplValue RtMsgNode::get_ret_value()const
{
    return ret;
}

void RtMsgNode::set_ret_value(const MplValue &v)
{
    ret = v;
}

LengthGuardType RtMsgNode::get_length_guard(int *limit)
{
    if ((length_guard_type != GUARD_ASSERT) && parent)
    {
        return parent->get_length_guard(limit);
    }

    *limit = length_guard_value;
    return length_guard_type;
}

int RtMsgNode::set_length_guard(LengthGuardType lgt, int limit)
{
    length_guard_type = lgt; length_guard_value = limit;
    return 0;
}

