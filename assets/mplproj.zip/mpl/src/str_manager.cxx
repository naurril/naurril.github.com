#include "str_manager.h"
//#include <iostream>

StringManager* StringManager::str_manager = NULL;


StringManager*  StringManager::get_manager()
{
    if (!str_manager)
        return str_manager = new StringManager;
    else
        return str_manager;
};

STR_ID StringManager::store_new_str(const char* str)
{
    str_store.push_back(str);
    //std::cout<<"str stored: "<<str_store.back()<<" with id: "<<str_store.size()-1<<std::endl;
    return str_store.size() - 1;
}


const char* StringManager::get_str(STR_ID id)
{
    //std::cout<<"str get: id = "<<id<<std::endl;
    return str_store[id].c_str();
}

const char* id2str(STR_ID id)
{
    return get_str_manager()->get_str(id);
}


StringManager* get_str_manager()
{
    return StringManager::get_manager();
}
