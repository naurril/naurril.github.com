
#ifndef _MPL_ERROR_H_
#define _MPL_ERROR_H_

//err code
enum ErrorCode
{
err_null_pointer            = 1,
err_unexpected_end_of_line,
err_unexpected_end_of_file,
err_expect_token,
err_unexpected_token,
err_name_confliction,
err_unmatched_para_list,
err_loop_import_detected,
err_repeated_import_detected,
err_unknown_escape_character,
err_incorrect_const_char_defined,
err_non_int_value_in_vnldef,
err_non_string_in_vnldef,
err_invalid_dedent,
err_src_codes_already_set,
err_src_file_already_set,
err_too_many_errors  =99,

err_run_time_unknown_operator= 101,
err_unknown_func_name         ,//102
err_unknown_message_name      ,//103
err_assert_failed             ,//104
err_check_failed              ,//105

err_type_error_from_mplvalue            ,//106
err_type_error_1            ,//107
err_type_error_2            ,//108
err_unknown_type              ,//109
err_improper_operation        ,//110

err_unexpected_end_of_input   ,//111
err_cannot_open_file          ,//112
err_unexpected_return         ,//113

err_access_nonexisted_variable      ,//114
err_invalid_value_type_of_specifier ,//115
err_unexpected_break                ,//116
err_unexpected_continue                ,
err_runtime_assertion_failed        ,

err_length_guard_assert_failed  ,// 118
err_length_guard_check_failed       ,//119
err_invalid_length_guard_assertion  ,//120
err_suspicious_dead_loop_detected,     //121
err_func_para_incompatible,
err_assign_to_const_variable,
err_unexpected_specifier_for_func_call,
err_unexpected_specifier_for_vnl_call,
err_invalid_statement,
err_divide_by_zero,
err_access_half_constructed_msg,
err_value_truncated,
err_unknown_message_to_interpret,
err_break_encountered  = 1000             ,//1000
err_continue_encountered  = 1001             ,//1001
};

class MplError
{
    public:
        MplError(int e, int p1, int p2, std::string s, void* p3=0, std::string es = ""):err_code(e),
                                              para_1(p1),
                                              para_2(p2),
                                              info(s),
                                              para_3(p3),
                                              extra_info(es)
                                              {}
        virtual ~MplError(){}
        int err_code;
        int para_1;
        int para_2;
        std::string info;
        void* para_3;  //for backtrace when exception happens
        std::string extra_info;
};

class CompileError: public MplError
{
public:
    CompileError(int e, int p1, int p2, const std::string s, void* p3=0, const std::string es=""):MplError(e, p1, p2, s, p3, es) {}
};

class RuntimeError: public MplError
{
public:
    RuntimeError(int e, int p1, int p2, const std::string s, void* p3=0, const std::string es=""):MplError(e, p1, p2, s, p3, es) {}

};

#endif
