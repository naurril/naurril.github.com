#ifndef _RAW_MEMORY_
#define _RAW_MEMORY_

#include <fstream>
#include <iostream>
#include "error.h"

typedef struct MemPos
{
    int octet;
    int bit;
    MemPos() {octet = 0; bit = 0;}
    MemPos(int o, int b): octet(o), bit(b) {}
    int operator - (MemPos p)
    {
        return (octet-p.octet)*8 + (bit - p.bit);
    }

    bool operator < (MemPos p)
    {
        if (octet < p.octet) return true;
        if (octet > p.octet) return false;
        if (bit < p.bit) return true;
        return false;
    }

    bool operator == (MemPos p)
    {
        return octet==p.octet && bit == p.bit;
    }

    bool operator != (MemPos p)
    {
    	return octet != p.octet || bit != p.bit;
    }

}MemPos;

typedef enum EndianType
{
    ET_BIG_ENDIAN = 0,
    ET_LITTLE_ENDIAN = 1,
}EndianType;

enum LengthGuardType
{
	GUARD_NONE=0,
	GUARD_ASSERT=2,
	GUARD_CHECK =3
};

class IRawMemory
{
public:
    IRawMemory(){}
    virtual ~IRawMemory(){}

	// return standards for the following functions
	// 0 -ok
	// 1 - end of input
	// 2 - length guard assert failed
	// 3 - length guard check failed, but done with what is needed

    virtual int get_octets(int len, int *rv)=0;
    virtual int get_bits(int len, int *rv)=0;
    //virtual int peep_octets(int len, int *rv)const =0;
    //virtual int peep_bits(int len, int *rv)const = 0;
    virtual MemPos get_current_pos()=0;
    virtual MemPos set_current_pos(MemPos _pos)=0;
    virtual int get_current_bit_pos() = 0;
    virtual int get_string(int len, int bits, std::string *rv)= 0;
    virtual int get_wstring(int len, int bits, std::wstring *rv)= 0;
    virtual bool end_of_input()const=0; //end of memory
    virtual unsigned char bit_at(MemPos pos, EndianType bit_e)const = 0;
    virtual unsigned char octet_at(MemPos pos)const = 0;
    virtual EndianType get_bits_endian()const = 0; //return old endian type
    virtual EndianType get_bytes_endian()const = 0; //return old endian type
    virtual EndianType set_bits_endian(EndianType et) = 0; //return old endian type
    virtual EndianType set_bytes_endian(EndianType et) = 0; //return old endian type


    virtual int set_length_guard(LengthGuardType guard_type, int len) = 0;
    virtual LengthGuardType get_length_guard(int *len) = 0;
    virtual int switch_to_next_frame() = 0; // it's the first frame by default.
    virtual int reset_to_first_frame() = 0;
    virtual int print_current_frame() = 0;
    virtual int size() const=0;

private:

};

class EndianHelperClass
{
public:
    EndianHelperClass(IRawMemory *mem_)
    {
        mem = mem_;
        if (mem)
        {
            bits_endian = mem->get_bits_endian();
            bytes_endian = mem->get_bytes_endian();
        }
    }

    virtual ~EndianHelperClass()
    {
        if (mem)
        {
            mem->set_bits_endian(bits_endian);
            mem->set_bytes_endian(bytes_endian);
        }
    }
private:
    IRawMemory *mem;
    EndianType bits_endian;
    EndianType bytes_endian;
};


#endif
