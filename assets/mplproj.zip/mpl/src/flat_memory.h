#ifndef _FLAT_MEMORY_H_
#define _FLAT_MEMORY_H_



class FlatMemory: public IRawMemory
{
public:
    FlatMemory();
    FlatMemory(char *mem_addr, int len_); // raw memory
    FlatMemory(FILE *in, const char *file_name);
    FlatMemory(const char* str);  //string as input

    ~FlatMemory();


    EndianType get_bits_endian()const
    {
        return cf->bits_endian;
    }

    EndianType get_bytes_endian()const
    {
        return cf->bytes_endian;
    }

    EndianType set_bits_endian(EndianType et) //return old endian type
    {
        EndianType old = cf->bits_endian;
        cf->bits_endian = et;
        return old;
    }

    EndianType set_bytes_endian(EndianType et) //return old endian type
    {
        EndianType old = cf->bytes_endian;
        cf->bytes_endian = et;
        return old;
    }


    unsigned char octet_at(MemPos pos)const
    {
        return cf->mem[pos.octet];
    }

    unsigned char bit_at(MemPos pos, EndianType bit_e)const  //input bits endian
    {
        if (ET_BIG_ENDIAN == bit_e)
            return (cf->mem[pos.octet] >> (7 - pos.bit)) & 0x01;
        else
            return (cf->mem[pos.octet] >> (pos.bit)) & 0x01;
    }

    bool end_of_input()const {return cf->cur_pos.octet >= cf->mem_len; }

    int get_octets(int len, int *rv);
    //int peep_octets(int len, int *rv)const;
    int get_bits(int len, int *rv);
    //int peep_bits(int len, int *rv)const;
    int get_string(int len, int bits, std::string *rv);
    int get_wstring(int len, int bits, std::wstring *rv);


    MemPos get_current_pos() { return cf->cur_pos; }
    MemPos set_current_pos(MemPos _pos) {return cf->cur_pos = _pos;}
    int get_current_bit_pos() {return cf->cur_pos.bit; }

	int set_length_guard(LengthGuardType guard_type, int len)
	{
		cf->length_guard_type = guard_type;
		if (guard_type != GUARD_NONE)
			cf->length_guard_value = len;
        //std::cout<<"mem> length guard ("<<guard_type<<") = "<<len<<" set"<<std::endl;
		return 0;
	}

	LengthGuardType get_length_guard(int *len)
	{
		*len = cf->length_guard_value;
		return cf->length_guard_type;
	}

	int size()const  { 	  return cf->mem_len; 	}

	void enable_octet_alignment() {cf->align_octet = true;}
	void disable_octet_alignment() {cf->align_octet = false;}

    int switch_to_next_frame(); // it's the first frame by default.
    int reset_to_first_frame();
    int print_current_frame();
private:
    int get_bits_little_endian(int len, int *rv);
    int get_bits_big_endian(int len, int *rv);
    int parse_line(const char *str, int line_no, const char* file_name);
    int parse_line_all_formatted_number(const char *str, int line_no, const char* file_name);
    int parse_line_hex_without_0x(const char *str, int line_no, const char* file_name);
    void reset_parse_mode();
    int parse_line_mini_command(const char *str, size_t size, int offset, const char* file_name, int line_no);
private:
    // current frame
    //int add_mem(int value);
    //MemPos cur_pos;
    //char* mem;
    //int   mem_len;
    //int mem_buf_size;

    // create new frame
    // support multiple parsing in one run, 23Jul2010
    struct MemFrame
    {
        ~MemFrame();
        MemFrame();
        int add_mem(int value);
        MemPos cur_pos;

        char* mem;
        int   mem_len;
        int mem_buf_size;

        //control status
        LengthGuardType length_guard_type;
        int length_guard_value;

        EndianType bits_endian;
        EndianType bytes_endian;

        bool align_octet;

        int frame_id;
        MemFrame *next_frame;

    };

    MemFrame *cf; // current frame
    MemFrame *frames;
    int start_new_mem_frame(const char* file, int line);
    int print_frame(MemFrame *f);
    int print_all_frames();

    enum ParseMode {PARSE_HEX_NO_0X, PARSE_NORMAL_FORMAT,};
    ParseMode  parse_mode;
};


#endif

