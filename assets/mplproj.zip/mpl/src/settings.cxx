#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <list>
#include "settings.h"

#define VERSION_NUMBER "0.1.00"
#define BUILD_DATE    __DATE__
#define BUILD_TIME    __TIME__

GlobalSetting* get_global_settings()
{
    return GlobalSetting::get_object();
}

GlobalSetting GlobalSetting::obj;

GlobalSetting::GlobalSetting()
{
	reset();
}

void GlobalSetting::reset()
{

    s_ready = false;
    source_from_stdin = false;
    only_check_grammar = false;
    print_grammar = false;
    verbose = false;
    help = false;
    version = false;

    verbose = false;
    disable_hidden = false;
    print_func_context = false;
    show_msg_only = false;
    debug = false;
    hex = false;
    no_mem = false;
    remove_underscore = false;
    hide_msg_ref = false;
    no_0x = false;
    octets_per_line = 2;
    max_msg_level = 128;

    bit_endian = ET_BIG_ENDIAN;
    byte_endian = ET_BIG_ENDIAN;
}

GlobalSetting::~GlobalSetting()
{

}

GlobalSetting* GlobalSetting::get_object()
{
    return &obj;
}

int GlobalSetting::print_help_ind()
{
    fprintf(stdout, "Try 'mpl -h' or 'mpl --help' for more information.\n");
    return 0;
}

int GlobalSetting::print_help()
{
    fprintf(stdout, "Usage: mpl SOURCE-FILE [options]\n");
    fprintf(stdout, "Options:\n");
    fprintf(stdout, "  -s SOURCE-FILE, --src-file SOURCE-FILE\n");
    fprintf(stdout, "                      Specify MPL source file\n");
    //fprintf(stdout, "  -r, --read-stdin    Read source code from stdin\n");
    fprintf(stdout, "  -m FILE, --mem-file FILE\n");
    fprintf(stdout, "                      Specify raw stream data file\n");
    fprintf(stdout, "  -n, --no-mem-file   Run without raw stream data\n");
    fprintf(stdout, "  -c, --check-only    Only check syntax\n");
    fprintf(stdout, "  -b ENDIAN, --bits-endian ENDIAN\n");
    fprintf(stdout, "                      Specify default bits endian\n");
    fprintf(stdout, "                        big - most significant bit lowest bit number\n");
    fprintf(stdout, "                        little - most significant bit highest bit number\n");
    fprintf(stdout, "  -B ENDIAN, --bytes-endian ENDIAN\n");
    fprintf(stdout, "                      Specify default bytes endian\n");
    fprintf(stdout, "                        big - most significant byte lowest byte number\n");
    fprintf(stdout, "                        little - most significant byte highest byte number\n");
    fprintf(stdout, "  -i DIR              Extra search path, multiple -i options are permitted\n");
    fprintf(stdout, "  -u, --remove-underscore\n");
    fprintf(stdout, "                      Replace underscores in message name with spaces\n");
    fprintf(stdout, "  -x, --hex           Show values in hex mode\n");
    fprintf(stdout, "  -v, --version       Output version information and exit\n");
    fprintf(stdout, "  -h, --help          Output this help information and exit\n");
    fprintf(stdout, "  -d, --debug         Print out much more information, same as combination of\n");
    fprintf(stdout, "                        --verbose, --disable-hidden, --print-func-context\n");
    fprintf(stdout, "      --no-0x         All input numbers are considered hex without 0x-prefix\n");
    fprintf(stdout, "      --print-msg-only\n");
    fprintf(stdout, "                      Show message tree only\n");
    fprintf(stdout, "      --verbose       Print more information when parsing\n");
    fprintf(stdout, "      --disable-hidden\n");
    fprintf(stdout, "                      Show all hidden (invisible) variables, thus make all\n");
    fprintf(stdout, "                        invisible variables visible\n");
    fprintf(stdout, "      --hide-msg-ref  Don't extend msg-reference\n");
    fprintf(stdout, "      --print-func-context\n");
    fprintf(stdout, "                      Show function calling context (debug)\n");
    //fprintf(stdout, "      --print-grammar Print out syntax tree (debug)\n");
    fprintf(stdout, "      --max-msg-level N\n");
    fprintf(stdout, "                      Message level limit, to prevent dead-loop, \n");
    fprintf(stdout, "                        the default value is 128\n");
    fprintf(stdout, "      --octets-per-line N\n");
    fprintf(stdout, "                      Number of raw stream octets per line when printing\n");
    fprintf(stdout, "                        messages, the default value is 2\n");
    fprintf(stdout, "\n");
    fprintf(stdout, "If no '-s' or '--src-file' option is given, the first unknown-option argument\n");
    fprintf(stdout, "is taken as the MPL source file to interpret. If no MPL source file is specified,\n");
    fprintf(stdout, "mpl reads MPL source codes from stdin.\n");
    fprintf(stdout, "\n");
    fprintf(stdout, "If no '-m', '--mem-file', '-n', '--no-mem-file', '-c' or '--check-only' option\n");
    fprintf(stdout, "is given, mpl reads raw stream data from stdin.\n");
    fprintf(stdout, "\n");
    fprintf(stdout, "Report bugs to Li E (kylinlix@hotmail.com)\n");
    return 0;
}

int GlobalSetting::print_version()
{
    fprintf(stdout, "mpl, an MPL(Message Parsing Language) interpreter.\n");
    fprintf(stdout, "Version %s, Built on %s %s.\n",VERSION_NUMBER, BUILD_DATE, BUILD_TIME);
    fprintf(stdout, "Copyright (C) 2008 Li E (kylinlix@hotmail.com).\n");
    fprintf(stdout, "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/license/gpl.html>.\n");
    fprintf(stdout, "This is a free software: you are free to change and redistribute it.\n");
    fprintf(stdout, "There is NO WARRANTY, to the extent permitted by law.\n");
    return 0;
}

// return 0 - go ahead
// return others - stop

int GlobalSetting::cmd_line_parse(int argc, const char* const argv[])
{
    int i = 1;
    while (i < argc)
    {
        if (argv[i][0] == '\0')
        {
            i++;
        }
        else if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i],"--help") == 0)
        {
            print_help();
            return 1;
        }
        else if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i],"--version") == 0)
        {
            print_version();
            return 1;
        }
        else if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i],"--src-file") == 0)
        {
            if (!s_ready && !source_from_stdin)
            {
                if (i+1 < argc)
                {
                    source_file_name = argv[i+1];
                    s_ready = true;
                    i += 2;
                }
                else
                {
                    fprintf(stdout, "mpl: optoin '-s' needs an argument.\n");
                    print_help_ind();
                    return 1;
                }
            }
            else
            {
                fprintf(stdout, "mpl: source mpl file is already specified\n");
                print_help_ind();
                return 1;
            }
        }
        else if (strcmp(argv[i], "-m") == 0 || strcmp(argv[i],"--mem-file")== 0)
        {
            if (i+1 < argc)
            {
                mem_file_name = argv[i+1];
                //m_ready = true;
                i += 2;
            }
            else
            {
                fprintf(stdout, "mpl: optoin '-m' needs an argument.\n");
                print_help_ind();
                return 1;
            }
        }

        else if (strcmp(argv[i], "-n") == 0 || strcmp(argv[i], "--no-mem-file")== 0)
        {
            no_mem = true;
            i++;
        }
        /*
        else if (strcmp(argv[i], "-r") == 0 || strcmp(argv[i], "--read-stdin")== 0)
        {
        	if(!s_ready)
        	{
				source_from_stdin = true;
				i++;
        	}
        	else
        	{
        		fprintf(stdout, "mpl: optoin '-r' or '--read-stdin' conflicts with '-s' and '--src-file',\n");
        		fprintf(stdout, "     or source file provided before '-r' or '--read-stdin'.\n");
                print_help_ind();
                return 1;
        	}
        }*/
        else if (strcmp(argv[i], "-b") == 0 || strcmp(argv[i], "--bits-endian") == 0)
        {
            if (i+1 < argc)
            {
                if (strcmp(argv[i+1], "little") == 0)
                {
                    bit_endian = ET_LITTLE_ENDIAN;
                }
                else if (strcmp(argv[i+1], "big") == 0)
                {
                    bit_endian = ET_BIG_ENDIAN;
                }
                else
                {
                    fprintf(stdout, "mpl: unrecognized bits endian type ('big' or 'little').\n");
                    print_help_ind();
                    return 1;
                }
                i += 2;
            }
            else
            {
                fprintf(stdout, "mpl: optoin '-e' needs an argument.\n");
                print_help_ind();
                return 1;
            }
        }
        else if (strcmp(argv[i], "-B") == 0 || strcmp(argv[i], "--bytes-endian") == 0)
        {
            if (i+1 < argc)
            {
                if (strcmp(argv[i+1], "little") == 0)
                {
                    byte_endian = ET_LITTLE_ENDIAN;
                }
                else if (strcmp(argv[i+1], "big") == 0)
                {
                    byte_endian = ET_BIG_ENDIAN;
                }
                else
                {
                    fprintf(stdout, "mpl: unrecognized bytes endian type ('big' or 'little').\n");
                    print_help_ind();
                    return 1;
                }
                i += 2;
            }
            else
            {
                fprintf(stdout, "mpl: optoin '-b' needs an argument.\n");
                print_help_ind();
                return 1;
            }

        }
        else if ((strcmp(argv[i], "-c") == 0) || (strcmp(argv[i], "--check-only") == 0))
        {
            only_check_grammar = true;
            i++;
        }
        else if (strcmp(argv[i], "--print-grammar")==0)
        {
            print_grammar = true;
            i++;
        }
        else if (strcmp(argv[i], "-i") == 0)
        {
            if (i+1 < argc)
            {
                std::string path = argv[i+1];
                // path cannot be empry string
                char c = path[path.size()-1];
                if (c != '/' && c != '\\')
                {
                    path += '/';
                }
                search_path_list.push_back(path);
                i += 2;
            }
            else
            {
                fprintf(stdout, "mpl: optoin '-i' needs an argument.\n");
                print_help_ind();
                return 1;
            }
        }
        else if (strcmp(argv[i], "--max-msg-level") == 0)
        {
            if (i+1 < argc)
            {
                // path cannot be empry string
                int v = atol(argv[i+1]);
                if (v <= max_msg_level && !debug)
                {
                    fprintf(stdout, "mpl: max-msg-level %d is too little, it should be larger than the default value.\n", v);
                    print_help_ind();
                    return 1;
                }
                else
                {
                    max_msg_level = v;
                }
                i += 2;
            }
            else
            {
                fprintf(stdout, "mpl: optoin '--max-msg-level' needs an argument.\n");
                print_help_ind();
                return 1;
            }
        }
        else if (strcmp(argv[i], "--octets-per-line") == 0)
        {
            if (i+1 < argc)
            {
                // path cannot be empry string
                int v = atol(argv[i+1]);
                if (v < 1 || v > 4)
                {
                    fprintf(stdout, "mpl: octets-per-line %d should be in range [1..4]\n", v);
                    print_help_ind();
                    return 1;
                }
                else
                {
                    octets_per_line = v;
                }
                i += 2;
            }
            else
            {
                fprintf(stdout, "mpl: optoin '--max-msg-level' needs an argument.\n");
                print_help_ind();
                return 1;
            }
        }
        else if (strcmp(argv[i], "--verbose") == 0)
        {
            verbose = true;
            i++;
        }
        else if (strcmp(argv[i], "--hex") == 0 || strcmp(argv[i], "-x") == 0)
        {
            hex = true;
            i++;
        }
        else if (strcmp(argv[i], "--disable-hidden") == 0)
        {
            disable_hidden = true;
            i++;
        }
        else if (strcmp(argv[i], "--hide-msg-ref") == 0)
        {
            i++;
            hide_msg_ref = true;
        }
        else if (strcmp(argv[i], "--no-0x") == 0)
        {
            i++;
            no_0x = true;
        }
        else if (strcmp(argv[i], "--print-func-context") == 0)
        {
            print_func_context = true;
            i++;
        }
        else if (strcmp(argv[i], "--print-msg-only") == 0)
        {
            show_msg_only = true;
            i++;
        }
        else if (strcmp(argv[i], "--remove-underscore") == 0 || strcmp(argv[i], "-u") == 0)
        {
            i++;
            remove_underscore = true;
        }
        else if (strcmp(argv[i], "--debug") == 0 || strcmp(argv[i], "-d") == 0)
        {
            verbose = true;
            disable_hidden = true;
            print_func_context = true;
            //print_grammar = true;
            debug = true;
            i++;
        }
        else
        {
            // the first argument which is not any known option is considered as the source mpl file name
            if (!s_ready && !source_from_stdin)
            {
                source_file_name = argv[i];
                s_ready = true;
                i ++;
            }
            else
            {
                fprintf(stdout, "mpl: invalid option '%s'\n", argv[i]);
                print_help_ind();
                return 1;
            }
        }
    }

	/*
    if (!s_ready && !source_from_stdin)
    {
        fprintf(stdout, "mpl: no input source file.\n");
        print_help_ind();
        return 1;
    }
    */

	if (!s_ready)
	{
		 source_from_stdin = true;
	}
    return 0;

}
