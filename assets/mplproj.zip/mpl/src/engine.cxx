
#include <iostream>
#include <fstream>
#include <cctype>
#include "rt_msg_tree.h"
#include "raw_memory.h"
#include "global.h"
#include "engine.h"

// for expression evaluation, the second parameter *msg is useless.
//


Engine::Engine(GNode* _grammar,
            IRawMemory *_mem,
            std::ostream &_out,
            std::ostream &_err):
            mem(_mem), grammar(_grammar), o_out(_out), o_err(_err)
{
}
