
#if !defined _MPL_MSG_NODE_H_
#define _MPL_MSG_NODE_H_

#include "str_manager.h"
#include "shared_ptr.h"
#include "raw_memory.h"
enum MsgNodeType
{
    MNT_NODE,
    MNT_VALUE,
    MNT_LIST, //ARRAY
    MNT_FUNC_CONTEXT,
};

// msg node attributes
typedef unsigned int MsgAttr;
#define MNA_NORMAL 0x00000000
#define MNA_HIDDEN  0x00000001
#define MNA_CONST   0x00000002

class MplValue;
class MsgNode;
class GNode;
class MsgNode;

//typedef  std::auto_ptr<MsgNode> MsgNodeAutoPtr;
typedef  SharedPtr<MsgNode> MsgNodeAutoPtr;
typedef  SharedPtr<MsgNode> MsgNodePtr;

class MsgNodeTraverser
{
public:
    virtual void operator()(MsgNodePtr m)=0;
};

class MsgNode
{
public:
    MsgNode(){}
    virtual ~MsgNode(){}
    virtual MsgNodeType get_type() const=0;
    virtual void set_mem_pos_begin(const MemPos &pos)=0;
    virtual MemPos get_mem_pos_begin()const=0;

    virtual void set_mem_pos_end(const MemPos &pos)=0;
    virtual MemPos get_mem_pos_end()const=0;

    virtual void set_bits_endian(EndianType t)=0;
    virtual EndianType get_bits_endian()const=0;
    virtual void set_bytes_endian(EndianType t)=0;
    virtual EndianType get_bytes_endian()const=0;

    virtual void set_name(const std::string &str)=0;
    virtual std::string get_name()const=0;

    virtual bool has_info()const = 0;
    virtual void set_info(const std::string &str)=0;
    virtual std::string get_info()const=0;

    virtual void set_value(const MplValue &value)=0;
    virtual const MplValue& get_value()const=0;

    virtual void set_hidden()=0;
    virtual bool is_hidden()const=0;

    virtual void set_const() = 0;
    virtual bool is_const()const = 0;
	virtual void set_attr(MsgAttr _attr) = 0;
    virtual void add_sub_item(MsgNodePtr msg)=0;
    virtual void add_sub_item(std::string name, MplValue v, MsgAttr mna=MNA_NORMAL,  STR_ID file_id=STR_ID_NULL, int line_no=0)=0;
    virtual void replace_sub_item(MsgNodePtr from, MsgNodePtr to)=0;
    virtual MsgNodePtr locate_name(std::string name, bool search_parent)=0;

    virtual MsgNode* get_parent()const=0;
    virtual void set_parent(MsgNode* p)=0;
    virtual int get_layer()const=0;
    virtual void set_layer(int l)=0;
    virtual MsgNodePtr find_sub_item(std::string name)=0;
    virtual void traverse_children(MsgNodeTraverser& traverser)=0;
    virtual int get_subitems_count()const = 0;
    virtual int get_self_order()const = 0; // order in brothers
    virtual MsgNodePtr child_at(unsigned int index) = 0;
    // for function context only
    virtual MplValue get_ret_value()const=0;
    virtual void set_ret_value(const MplValue &v) =0;
    virtual bool stopped()const=0;
    virtual void toggle_stopped()=0;

    //
    //virtual int show_msg_content(std::ostream &o, IRawMemory *mem)=0;



    // for debug unwinding
    virtual std::string get_src_file_name()const = 0;
    virtual int get_src_line_number()const = 0;
    virtual void set_src_code_info(STR_ID id, int line)=0;
    virtual void set_debug_node(MsgNodePtr msg)= 0;
    virtual MsgNodePtr get_debug_node()const = 0;
	virtual MsgNodePtr get_assist_node()const = 0;
    // for lenght guard
    virtual LengthGuardType get_length_guard(int *limit) = 0;
    virtual int set_length_guard(LengthGuardType lgt, int limit) = 0;

    virtual void set_ripe() = 0; // mark as ripe
    virtual bool is_ripe() = 0;
    virtual bool is_last_in_siblings() = 0;

 public:
	virtual int add_ref() = 0;
	virtual int release() = 0;
	virtual int get_ref() = 0;
 public:
    static int msg_count;


public:
	class AddSubitemHelper
	{
	public:
		AddSubitemHelper(MsgNodePtr parent, MsgNodePtr subitem):_parent(parent), _subitem(subitem){}
		~AddSubitemHelper(){if (_parent.get()) _parent->add_sub_item(_subitem);}
	private:
		MsgNodePtr _parent;
		MsgNodePtr _subitem;
	};

	class ReplaceSubitemHelper
	{
	public:
		ReplaceSubitemHelper(MsgNodePtr parent, MsgNodePtr old_msg, MsgNodePtr new_msg)
			:_parent(parent), _old_msg(old_msg), _new_msg(new_msg){}
		~ReplaceSubitemHelper()
		{
			if (_old_msg.get())
			{
				_old_msg->get_parent()->replace_sub_item(_old_msg, _new_msg);
			}
			else if (_parent.get())
			{
				_parent->add_sub_item(_new_msg);
			}
		}
	private:
		MsgNodePtr _parent, _old_msg, _new_msg;
	};
};



#endif /* _MPL_MSG_NODE_H_ */
