
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int parse(FILE *in)
{
    char str[1024];
    int line = 0;
    int v;
    int digit_count;
    char c;
    int hex_counter = 0;

    while (!feof(in))
    {
	str[0] = 0;
	if (NULL == fgets(str, 1023, in))
	{
	    //end of line
	    break;
	}

	//std::cout<<std::endl<<"input:"<<str<<std::endl;
	++line;



	unsigned int i = 0;
	unsigned int size = strlen(str);

	while( i < size)
	{
	    if (str[i++] =='0')
	    {
		c = str[i++];
		if ((i < size) && (c == 'x'|| c == 'X'))
		{
		    v = 0;
		    digit_count = 0;

		    while (i < size)
		    {
			c = str[i++];

			if (c <= '9' && c >= '0')
			{
			    v = v * 16 + c - '0';
			    ++digit_count;
			}
			else if (c <= 'f' && c >= 'a')
			{
			    v = v * 16 + c - 'a' + 10;
			    ++digit_count;
			}
			else if (c <= 'F' && c >= 'A')
			{
			    v = v * 16 + c - 'A' + 10;
			    ++digit_count;
			}
			else
			{
			    break;
			}
		    }

		    if ((digit_count == 0) || (digit_count > 2))
		    {
			fprintf(stderr, "warning(line %d): suspicious hex number (digit count not correct for a byte), ignored!", line);
		    }
		    else
		    {

			

			if (hex_counter % 8 == 0)
			    fprintf(stdout, "\n");
			else if (hex_counter % 4 == 0)
			    fprintf(stdout, " ");
			fprintf(stdout, "0x%02x ",v);
			hex_counter++;

		    }
		}
	    }
	}
    }


    return hex_counter;
}


int main(int argc, char* argv[])
{
    if (argc < 2)
    {
	fprintf(stdout, "Usage: extrhex input-filename [comments] \n");
	fprintf(stdout, "  extract all hex numbers in the input-file (0x-or-0X-started 8-bits numbers)\n");
	fprintf(stdout, "  option 'comments', if present, will be written to output unchanged\n");
	return 0;
    }


    FILE *in;

    in = fopen(argv[1], "r");
    if (in==NULL)
    {
	perror(argv[1]);
	return 0;
    }

 
    fprintf(stdout, "#mpl raw stream file\n");
    fprintf(stdout, "#original file name %s\n",argv[1]);
    if (argc > 2)
    {
	fprintf(stdout, "#comments:");
	for ( int i = 2; i<argc; i++)
	    fprintf(stdout, " %s", argv[i]);
    }

    int bytes = parse(in);

    fprintf(stdout, "\n\n#end, %d bytes.\n",bytes);

    fclose(in);

    return 0;
}
