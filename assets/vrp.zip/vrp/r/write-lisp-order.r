library(chron)
library(plyr)
setwd("d:/vrp/vrp/r")
sites <- read.csv("1.csv", stringsAsFactors=FALSE, header=FALSE)
names(sites) <- c("Site_id","Lng","Lat")
get.site.addr <- function(id) sites[sites$Site_id==id,2:3]


spots <- read.csv("2.csv", stringsAsFactors=FALSE, header=FALSE)
get.spot.addr <- function(id) spots[spots$Spot_id==id,2:3]
names(spots) <- c("Spot_id","Lng","Lat")

shops <- read.csv("3.csv", stringsAsFactors=FALSE, header=FALSE)
get.shop.addr <- function(id) shops[shops$Shop_id==id,2:3]
names(shops) <- c("Shop_id","Lng","Lat")

orders <-read.csv("4.csv", stringsAsFactors=FALSE, header=FALSE)
names(orders) <- c("Order_id","Spot_id","Site_id","num")
orders.o2o <-read.csv("5.csv", stringsAsFactors=FALSE, header=FALSE)
names(orders.o2o) <- c("Order_id","Spot_id","Shop_id","Pickup_time","Delivery_time","num")
carriers <-read.csv("6.csv", stringsAsFactors=FALSE)



orders.details <- orders #join(join(orders, sites, by=c("Site_id")), spots, by=c("Spot_id"))

orders.o2o$ptime <- times(paste0(orders.o2o$Pickup_time, ":00"))
orders.o2o$pminutes <- (hours(orders.o2o$ptime)-8)*60 + minutes(orders.o2o$ptime)

orders.o2o$dtime <- times(paste0(orders.o2o$Delivery_time, ":00"))
orders.o2o$dminutes <- (hours(orders.o2o$dtime)-8)*60 + minutes(orders.o2o$dtime)
orders.o2o.details <- orders.o2o #join(join(orders.o2o, shops, by=c("Shop_id")), spots, by=c("Spot_id"))

# to lisp object
orders.lisp<-data.frame(orders.details[, c(1,3,2,4)], "nil", 720, 720)
orders.o2o.lisp <- data.frame(orders.o2o.details[,c(1,3,2,6)], "T", orders.o2o.details[,c(8, 10)])


##################################
# wrtie lisp file 
order.to.lisp.file <- function(ord, fout, var.name){
  cat(paste("(defparameter", var.name,  "#(\n"), file=fout)
  
  for (i in seq(nrow(ord))){
    o <- ord[i,]
    cat(paste("  #(", 
              paste0("\"",o[,1],"\" \"",o[,2],"\" \"",o[,3],"\""), o[,4], o[,5], o[,6], o[,7], 
              ")\n"),
        file=fout)
  }
  cat("))\n", file=fout)
}

fout <- file("../orders.lisp", 'w')
cat("(in-package :open-vrp)\n", file=fout)
order.to.lisp.file(orders.lisp, fout, "*orders*")
order.to.lisp.file(orders.o2o.lisp, fout, "*orders_o2o*")
cat("\n", file=fout)
close(fout)

# end

### entities

# site, spot, shops
entities.to.lisp.file <- function(entities, entity.type, fout){
  
  
  for (i in seq(nrow(entities))){
    e <- entities[i,]
    cat(paste("  #(", 
              paste0("\"",e[,1],"\" "), entity.type, e[,2], e[,3],
              ")\n"),
        file=fout)
  }
}

fout <- file("../entities.lisp", 'w')
cat("(in-package :open-vrp)\n", file=fout)
cat(paste("(defparameter *entities* #(\n"), file=fout)
cat(";;; for easy of implementation, put sites in order, and before any other entities.\n", file=fout)
cat(";;; because site id are also cluster id\n", file=fout)

entities.to.lisp.file(sites[order(sites$Site_id),], 0, fout)
entities.to.lisp.file(shops, 1, fout)
entities.to.lisp.file(spots[order(spots$Spot_id),], 2, fout)

cat("))\n", file=fout)
close(fout)

#######################



distance <- function(a.lng, a.lat, b.lng, b.lat){
  R <- 6378137
  #pi <- 3.1415926535897932
  delta.lat  = (a.lat - b.lat)/2
  delta.long = (a.lng - b.lng)/2
  dis.m <- 2*R*asin(sqrt( sin(pi/180*delta.lat) * sin(pi/180*delta.lat) +
                            cos(pi/180*a.lat) * cos(pi/180*b.lat) *sin(pi/180*delta.long) * sin(pi/180*delta.long)))
  #print(dis.m)
  round(dis.m/15000*60)
}

osites <- sites[order(sites$Site_id),]
oshops <- shops
ospots <- spots[order(spots$Spot_id),]
# distance matrix
wholeaddr <-t(as.matrix(data.frame(t(as.matrix(osites[,2:3])),
                                   t(as.matrix(oshops[,2:3])),
                                   t(as.matrix(ospots[,2:3]))), 
                        nrow=2))

len <- nrow(wholeaddr)

m<-matrix(0, nrow=len, ncol=len)
for (i in seq(len-1)){
  m[i,i]<- 0
  
  for (j in (i+1):len){
    m[i,j] <- distance(wholeaddr[i,1],wholeaddr[i,2], wholeaddr[j,1], wholeaddr[j,2])
    m[j,i] <- m[i,j]
  }
}

### lisp file
fout <- file("../dist_array.lisp", 'w')
cat("(in-package :open-vrp)\n", file=fout)
cat(paste("(defparameter *dist-array* #2A(\n"), file=fout)
cat(";;; the order shall be same as entities.lisp.\n", file=fout)


for (i in 1:len){
  cat("(", file=fout)
  cat(paste(m[i,]), file=fout)
  cat(")\n", file=fout)
}

cat("))\n", file=fout)
close(fout)